"""MCP tool handler for chat memory search.

Uses SQLite FTS5 for keyword search — all operations run in-process.
No subprocess, no onnxruntime, no ChromaDB.

Logging goes to ~/.dcp/chat-memory/dcp-chat.log.
"""

import logging
from pathlib import Path
from typing import Any

from mcp.types import TextContent

LOG_DIR = Path.home() / ".dcp" / "chat-memory"
LOG_FILE = LOG_DIR / "dcp-chat.log"


def _setup_file_logger() -> logging.Logger:
    """Set up a file logger for chat memory operations."""
    logger = logging.getLogger("dcp.chat_memory")
    if logger.handlers:
        return logger
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(str(LOG_FILE), encoding="utf-8")
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s: %(message)s"
    ))
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    return logger


logger = _setup_file_logger()


async def handle_search_chats(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle search_chats tool call using FTS5 keyword search."""
    query = arguments.get("query", "")
    if not query:
        return [TextContent(type="text", text="error: query parameter is required")]

    workspace_path = arguments.get("workspace_path")
    n_results = arguments.get("n_results", 5)

    logger.info("search_chats query=%r n_results=%s workspace=%s", query, n_results, workspace_path)

    try:
        import asyncio
        from dcp.chat_memory.searcher import search_chats

        loop = asyncio.get_event_loop()
        results = await loop.run_in_executor(
            None, lambda: search_chats(query, workspace_path, n_results),
        )

        _trigger_background_index()

        index_status = _get_index_status()
        logger.info("search_chats OK results=%d indexed=%s", len(results), index_status.get("total_indexed", "?"))
        return [TextContent(type="text", text=_format_chat_results(results, index_status))]

    except Exception as e:
        logger.error("search_chats CRASHED: %s", e, exc_info=True)
        return [TextContent(type="text", text=f"error: {type(e).__name__}: {e}")]


def _trigger_background_index() -> None:
    """Start background indexing if not already running."""
    try:
        from dcp.chat_memory.indexer import ChatMemoryIndexer
        indexer = ChatMemoryIndexer()
        indexer.ensure_indexing_started()
    except Exception as e:
        logger.warning("Background indexer failed to start: %s", e)


def _get_index_status() -> dict:
    """Get current index status without triggering indexing."""
    try:
        from dcp.chat_memory.indexer import ChatMemoryIndexer
        return ChatMemoryIndexer().get_progress()
    except Exception:
        return {"status": "unknown", "total_indexed": 0}


def _format_chat_results(results: list[dict], index_status: dict) -> str:
    """Format chat search results as plain text."""
    lines = []
    lines.append(f"result_count: {len(results)}")
    lines.append(f"index_status: {index_status.get('status', 'unknown')}, total_indexed={index_status.get('total_indexed', 0)}")

    if not results:
        lines.append("results: none")
        return "\n".join(lines)

    for i, r in enumerate(results, 1):
        lines.append(f"\n--- result {i} ---")
        lines.append(f"conversation: {r.get('conversation_name', '?')}")
        lines.append(f"composer_id: {r.get('composer_id', '?')}")
        lines.append(f"workspace: {r.get('workspace_path', '?')}")
        lines.append(f"mode: {r.get('mode', '?')}")
        lines.append(f"relevance: {r.get('relevance_score', 0)}")
        for msg in r.get("messages", []):
            role = msg.get("role", "?")
            text = msg.get("text", "")
            lines.append(f"  {role}: {text}")

    return "\n".join(lines)
