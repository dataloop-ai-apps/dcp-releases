"""MCP server setup for Dev Control Plane (DCP).

This server provides:
- Tools: 6 tools for memory management, guideline search, documentation, and chat history
- Prompts: Reusable prompt templates for each mode (5 modes + bootstrap)
- Resources: dcp://guidance for interaction style directives and mode metadata
"""

import json
from typing import Any

from pydantic import AnyUrl
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    Prompt,
    PromptMessage,
    PromptArgument,
    GetPromptResult,
    Resource,
)

from dcp.tools.guideline_tools import handle_search_guidelines
from dcp.tools.memory_tools import (
    handle_read_memory,
    handle_update_memory,
    handle_init_repo,
    handle_save_doc,
)
from dcp.tools.chat_memory_tools import handle_search_chats
from dcp.modes.loader import load_builtin_modes
from dcp.modes.manager import get_interaction_style, get_style_directives


# =============================================================================
# TOOLS (6 total)
# =============================================================================

ALL_TOOLS = [
    Tool(
        name="read_memory",
        description=(
            "Read repo memory (architecture, stack, conventions, learnings). "
            "Returns full memory or a specific section."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {
                    "type": "string",
                    "description": "Path to the repository",
                },
                "section": {
                    "type": "string",
                    "enum": ["architecture", "stack", "conventions", "context", "learnings", "docs", "metadata"],
                    "description": "Optional: return only this section (omit for full memory)",
                },
            },
            "required": ["repo_path"],
        },
    ),
    Tool(
        name="search_guidelines",
        description="Search coding guidelines with language and framework filtering",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural language search query"},
                "languages": {"type": "array", "items": {"type": "string"}, "description": "Filter by languages"},
                "frameworks": {"type": "array", "items": {"type": "string"}, "description": "Filter by frameworks"},
                "categories": {"type": "array", "items": {"type": "string"}, "description": "Filter by categories"},
                "limit": {"type": "integer", "description": "Maximum results (default: 5)"},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="init_repo",
        description=(
            "Initialize a repo with memory and cursor rules. "
            "Auto-detects tech stack and git patterns. "
            "If memory already exists, pass force=true to overwrite."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {"type": "string", "description": "Path to the repository"},
                "repo_name": {"type": "string", "description": "Name for the repo (default: directory name)"},
                "scan_repo": {"type": "boolean", "description": "Auto-detect tech stack (default: true)"},
                "scan_git": {"type": "boolean", "description": "Analyze git history (default: true)"},
                "copy_cursor_rules": {"type": "boolean", "description": "Copy .cursor/rules/ files (default: true)"},
                "copy_skills": {"type": "boolean", "description": "Copy .cursor/skills/ files (default: true)"},
                "force": {"type": "boolean", "description": "Overwrite existing memory (default: false)"},
            },
            "required": ["repo_path"],
        },
    ),
    Tool(
        name="save_doc",
        description=(
            "Save a documentation file to .dcp/docs/ and register it in memory. "
            "Use for operational docs: release flows, local dev setup, running tests, "
            "deployment guides, runbooks, etc. If a doc with the same ID exists, it is updated."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {
                    "type": "string",
                    "description": "Path to the repository",
                },
                "title": {
                    "type": "string",
                    "description": "Document title (e.g., 'Release Flow', 'Local Development Setup')",
                },
                "content": {
                    "type": "string",
                    "description": "Full markdown content of the document",
                },
                "description": {
                    "type": "string",
                    "description": "Brief description for the memory reference (1-2 sentences)",
                },
                "category": {
                    "type": "string",
                    "enum": ["flow", "setup", "guide", "runbook", "reference"],
                    "description": (
                        "Document category. "
                        "flow=process/workflow, setup=environment/install, "
                        "guide=how-to, runbook=operational procedure, "
                        "reference=API/config reference. Default: guide"
                    ),
                },
                "doc_id": {
                    "type": "string",
                    "description": "Custom document ID (auto-generated from title if omitted)",
                },
            },
            "required": ["repo_path", "title", "content", "description"],
        },
    ),
    Tool(
        name="update_memory",
        description=(
            "Update any section of repo memory. "
            "Sections: architecture, stack, conventions, context, learnings, docs. "
            "For learnings, use operation='append' with a dict containing "
            "summary and category -- id, date, and confidence are auto-generated. "
            "For docs, use save_doc tool to add/update docs, or operation='set'/'remove' here."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {
                    "type": "string",
                    "description": "Path to the repository",
                },
                "section": {
                    "type": "string",
                    "enum": ["architecture", "stack", "conventions", "context", "learnings", "docs"],
                    "description": "Section to update",
                },
                "content": {
                    "description": (
                        "Content to write. For 'architecture': a string. "
                        "For 'stack': a dict with keys like languages, frameworks, etc. "
                        "For 'conventions': a list of strings. "
                        "For 'context': a dict with 'notes' list. "
                        "For 'learnings' with append: a dict with 'summary' and 'category'."
                    ),
                },
                "operation": {
                    "type": "string",
                    "enum": ["set", "append"],
                    "description": (
                        "How to apply the update (default: set). "
                        "'set' replaces the entire section. "
                        "'append' adds items to a list (conventions, context.notes, learnings)."
                    ),
                },
            },
            "required": ["repo_path", "section", "content"],
        },
    ),
    Tool(
        name="search_chats",
        description=(
            "Search past Cursor chat conversations by keyword. "
            "Returns relevant conversation snippets grouped by conversation, "
            "plus index status. Background indexing is opt-in via DCP_CHAT_INDEX_ENABLED."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural language search query",
                },
                "workspace_path": {
                    "type": "string",
                    "description": "Filter results to a specific workspace path",
                },
                "n_results": {
                    "type": "integer",
                    "description": "Max conversations to return (default: 5)",
                },
            },
            "required": ["query"],
        },
    ),
]

TOOL_HANDLERS = {
    "read_memory": handle_read_memory,
    "search_guidelines": handle_search_guidelines,
    "init_repo": handle_init_repo,
    "update_memory": handle_update_memory,
    "save_doc": handle_save_doc,
    "search_chats": handle_search_chats,
}


# =============================================================================
# RESOURCES - dcp://guidance
# =============================================================================

def build_guidance_content() -> str:
    """Build the guidance resource content based on current interaction style."""
    style = get_interaction_style()
    directives = get_style_directives(style)
    modes = load_builtin_modes()

    lines = [
        f"interaction_style: {style}",
        "",
        "directives: |",
    ]
    for directive_line in directives.strip().splitlines():
        lines.append(f"  {directive_line}")

    lines.append("")
    lines.append("available_modes:")
    for mode in modes.values():
        lines.append(f"  - id: {mode.id}")
        lines.append(f"    name: {mode.name}")
        lines.append(f"    description: {mode.description}")

    return "\n".join(lines)


GUIDANCE_RESOURCE = Resource(
    name="guidance",
    uri=AnyUrl("dcp://guidance"),
    description="Interaction style directives and available mode metadata",
    mimeType="text/yaml",
)


# =============================================================================
# PROMPTS - Mode templates (5 modes + bootstrap)
# =============================================================================

def get_all_prompts() -> list[Prompt]:
    """Get all available prompts."""
    modes = load_builtin_modes()
    prompts = []

    for mode_id, mode in modes.items():
        prompts.append(Prompt(
            name=f"{mode_id}-mode",
            description=f"{mode.name}: {mode.description}",
            arguments=[
                PromptArgument(
                    name="context",
                    description="Optional context about the current task",
                    required=False,
                ),
                PromptArgument(
                    name="repo_path",
                    description="Path to the repository for loading memory",
                    required=False,
                ),
            ],
        ))

    prompts.append(Prompt(
        name="bootstrap",
        description="Initialize Dev Control Plane with memory and auto-select mode",
        arguments=[
            PromptArgument(
                name="repo_path",
                description="Path to the repository",
                required=True,
            ),
            PromptArgument(
                name="user_request",
                description="The user's initial request (for auto-mode selection)",
                required=False,
            ),
        ],
    ))

    return prompts


async def get_prompt(name: str, arguments: dict[str, str] | None) -> GetPromptResult:
    """Get a prompt by name with arguments."""
    args = arguments or {}
    context = args.get("context", "")

    if name == "bootstrap":
        user_request = args.get("user_request", "")

        instructions = """# Dev Control Plane Bootstrap

You are now using the Dev Control Plane (DCP) for intelligent development assistance.

## Available Tools
- `read_memory` -- Load repo context (architecture, stack, conventions, learnings, docs)
- `search_guidelines` -- Search coding guidelines before making decisions
- `update_memory` -- Record learnings and update any memory section
- `save_doc` -- Save operational docs (flows, setup guides, runbooks) to .dcp/docs/ with memory reference
- `init_repo` -- Initialize a new repo with memory and cursor rules
- `search_chats` -- Search past Cursor chat conversations by meaning (auto-indexes in background)

## Available Role Prompts
- `planner-mode`: Planner - requirements gathering + technical design
- `developer-mode`: Developer - implementation + code review + PR workflows
- `tester-mode`: Test Engineer - test planning + writing + execution
- `debugger-mode`: Debugger - troubleshooting
- `documenter-mode`: Technical Writer - documentation

## Your Tasks
1. Call `read_memory` to load repo context
2. Based on the user's request, use the appropriate mode prompt
3. Follow the mode's instructions and checklist
4. Search guidelines before making architectural decisions
5. Record learnings via `update_memory` (section: learnings, operation: append)

## Confidence Levels for Learnings
- 80+ = enforced guideline (high confidence)
- 50-79 = recommended practice (medium)
- 20-49 = informational note (low)
- 0-19 = experimental / untested
"""

        if user_request:
            instructions += f"\n## User's Request\n{user_request}\n"

        return GetPromptResult(
            description="Bootstrap Dev Control Plane",
            messages=[
                PromptMessage(
                    role="user",
                    content=TextContent(type="text", text=instructions),
                )
            ],
        )

    if name.endswith("-mode"):
        mode_id = name.replace("-mode", "")
        modes = load_builtin_modes()

        if mode_id not in modes:
            return GetPromptResult(
                description=f"Unknown mode: {mode_id}",
                messages=[
                    PromptMessage(
                        role="user",
                        content=TextContent(type="text", text=f"Error: Mode '{mode_id}' not found."),
                    )
                ],
            )

        mode = modes[mode_id]

        resolved_prompt = mode.system_prompt + "\n" + get_style_directives()

        prompt_content = f"""# {mode.name}

{resolved_prompt}

## Available Tools
{chr(10).join(f"- {tool}" for tool in mode.tools_enabled) if mode.tools_enabled else "All tools available"}

## Checklist
"""
        if mode.checklist:
            for phase, items in mode.checklist.items():
                prompt_content += f"\n### {phase.replace('_', ' ').title()}\n"
                for item in items:
                    prompt_content += f"- [ ] {item}\n"

        if context:
            prompt_content += f"\n## Context\n{context}\n"

        if mode.related_modes:
            prompt_content += f"\n## Related Modes\nConsider switching to: {', '.join(mode.related_modes)}\n"

        return GetPromptResult(
            description=f"{mode.name}: {mode.description}",
            messages=[
                PromptMessage(
                    role="user",
                    content=TextContent(type="text", text=prompt_content),
                )
            ],
        )

    return GetPromptResult(
        description="Unknown prompt",
        messages=[
            PromptMessage(
                role="user",
                content=TextContent(type="text", text=f"Unknown prompt: {name}"),
            )
        ],
    )


# =============================================================================
# SERVER SETUP
# =============================================================================

def create_server() -> Server:
    """Create and configure the MCP server."""
    server = Server("dcp")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return ALL_TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        handler = TOOL_HANDLERS.get(name)
        if handler is None:
            return [TextContent(type="text", text=json.dumps({"error": f"Unknown tool: {name}"}))]
        return await handler(arguments)

    @server.list_prompts()
    async def list_prompts() -> list[Prompt]:
        return get_all_prompts()

    @server.get_prompt()
    async def handle_get_prompt(name: str, arguments: dict[str, str] | None) -> GetPromptResult:
        return await get_prompt(name, arguments)

    @server.list_resources()
    async def list_resources() -> list[Resource]:
        return [GUIDANCE_RESOURCE]

    @server.read_resource()
    async def read_resource(uri: AnyUrl) -> str:
        if str(uri) == "dcp://guidance":
            return build_guidance_content()
        return f"Unknown resource: {uri}"

    return server


def run_server() -> None:
    """Run the MCP server using stdio transport."""
    import asyncio

    async def main():
        server = create_server()

        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options()
            )

    asyncio.run(main())


if __name__ == "__main__":
    run_server()
