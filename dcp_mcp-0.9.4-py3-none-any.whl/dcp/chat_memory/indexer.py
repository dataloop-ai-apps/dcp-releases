"""Background indexer for Cursor chat messages into SQLite FTS5.

Reads messages from Cursor's local SQLite databases and stores them in
the FTS5 store for keyword search. No subprocess needed — all operations
run in-process.

Progress is tracked in a thread-safe dataclass.
"""

import sqlite3
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime

BATCH_SIZE = 200
MAX_MESSAGES_PER_RUN = 50_000
BATCH_SLEEP_SECONDS = 0.1
CHUNK_SIZE = 512
CHUNK_OVERLAP = 64
MAX_UNCHUNKED_LENGTH = 2000
MAX_DOC_LENGTH = 4000
MAX_CHUNKS_PER_MESSAGE = 5


@dataclass
class IndexProgress:
    """Thread-safe indexing progress state."""

    status: str = "idle"
    percentage: int = 0
    processed: int = 0
    total: int = 0
    newly_indexed: int = 0
    total_indexed: int = 0
    last_completed: str | None = None
    current_run_started: str | None = None
    error: str | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def to_dict(self) -> dict:
        with self._lock:
            return {
                "status": self.status,
                "percentage": self.percentage,
                "processed": self.processed,
                "total": self.total,
                "newly_indexed": self.newly_indexed,
                "total_indexed": self.total_indexed,
                "last_completed": self.last_completed,
                "current_run_started": self.current_run_started,
                "error": self.error,
            }

    def set_indexing(self, total: int) -> None:
        with self._lock:
            self.status = "indexing"
            self.total = total
            self.processed = 0
            self.percentage = 0
            self.newly_indexed = 0
            self.error = None
            self.current_run_started = datetime.now().isoformat()

    def set_done(self, total_in_collection: int, newly_indexed: int) -> None:
        with self._lock:
            self.status = "done"
            self.percentage = 100
            self.newly_indexed = newly_indexed
            self.total_indexed = total_in_collection
            self.last_completed = datetime.now().isoformat()
            self.current_run_started = None

    def set_idle(self, total_in_collection: int = 0) -> None:
        with self._lock:
            self.status = "idle"
            self.total_indexed = total_in_collection
            self.total = 0
            self.processed = 0
            self.percentage = 0
            self.newly_indexed = 0
            self.current_run_started = None

    def set_error(self, error: str) -> None:
        with self._lock:
            self.status = "error"
            self.error = error
            self.current_run_started = None


def _chunk_text(text: str) -> list[str]:
    """Split long text into overlapping chunks for better search coverage."""
    if len(text) <= MAX_UNCHUNKED_LENGTH:
        return [text]

    text = text[:MAX_DOC_LENGTH]

    chunks = []
    start = 0
    while start < len(text) and len(chunks) < MAX_CHUNKS_PER_MESSAGE:
        end = start + CHUNK_SIZE
        chunk = text[start:end]
        if chunk.strip():
            chunks.append(chunk)
        start = end - CHUNK_OVERLAP

    return chunks if chunks else [text[:CHUNK_SIZE]]


def _build_document(msg) -> str:
    """Build the searchable document text from a message."""
    parts = [msg.text]
    total = len(msg.text)
    for cb in msg.code_blocks:
        addition = f"\n```\n{cb}\n```"
        if total + len(addition) > MAX_DOC_LENGTH:
            break
        parts.append(addition)
        total += len(addition)
    return "\n".join(parts)


def _init_meta_db(path) -> None:
    """Initialize the indexing metadata SQLite database."""
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS indexed_bubbles "
        "(bubble_id TEXT PRIMARY KEY)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS index_runs "
        "(id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "timestamp TEXT, messages_indexed INTEGER)"
    )
    conn.commit()
    conn.close()


def _load_known_ids(path) -> set[str]:
    """Load the set of already-indexed bubble IDs."""
    if not path.exists():
        return set()
    conn = sqlite3.connect(str(path))
    try:
        rows = conn.execute("SELECT bubble_id FROM indexed_bubbles").fetchall()
        return {r[0] for r in rows}
    finally:
        conn.close()


def _save_indexed_ids(path, ids: list[str]) -> None:
    """Save newly indexed bubble IDs to the metadata DB."""
    if not ids:
        return
    conn = sqlite3.connect(str(path))
    try:
        conn.executemany(
            "INSERT OR IGNORE INTO indexed_bubbles (bubble_id) VALUES (?)",
            [(bid,) for bid in ids],
        )
        conn.commit()
    finally:
        conn.close()


def _record_run(path, count: int) -> None:
    """Record an indexing run completion."""
    conn = sqlite3.connect(str(path))
    try:
        conn.execute(
            "INSERT INTO index_runs (timestamp, messages_indexed) VALUES (?, ?)",
            (datetime.now().isoformat(), count),
        )
        conn.commit()
    finally:
        conn.close()


def run_index() -> dict:
    """Run incremental indexing directly into the FTS store. Returns stats."""
    from dcp.chat_memory.config import get_meta_db_path
    from dcp.chat_memory.extractor import extract_messages_iter
    from dcp.chat_memory.fts_store import ChatFTSStore

    meta_path = get_meta_db_path()
    store = ChatFTSStore()

    _init_meta_db(meta_path)
    known_ids = _load_known_ids(meta_path)
    msg_iter = extract_messages_iter(known_ids)

    total_this_run = 0

    try:
        while total_this_run < MAX_MESSAGES_PER_RUN:
            batch = []
            for msg in msg_iter:
                batch.append(msg)
                if len(batch) >= BATCH_SIZE:
                    break
            if not batch:
                break

            doc_ids = []
            documents = []
            metadatas = []

            for msg in batch:
                doc_text = _build_document(msg)
                chunks = _chunk_text(doc_text)

                for chunk_idx, chunk in enumerate(chunks):
                    doc_id = (
                        f"{msg.bubble_id}:{chunk_idx}"
                        if len(chunks) > 1
                        else msg.bubble_id
                    )
                    doc_ids.append(doc_id)
                    documents.append(chunk)
                    metadatas.append({
                        "composer_id": msg.composer_id,
                        "bubble_id": msg.bubble_id,
                        "message_index": msg.message_index,
                        "message_type": msg.message_type,
                        "workspace_path": msg.workspace_path,
                        "conversation_name": msg.conversation_name,
                        "timestamp": msg.timestamp,
                        "mode": msg.mode,
                    })

            store.upsert(ids=doc_ids, documents=documents, metadatas=metadatas)
            _save_indexed_ids(meta_path, [m.bubble_id for m in batch])
            total_this_run += len(batch)

            time.sleep(BATCH_SLEEP_SECONDS)

        if total_this_run > 0:
            _record_run(meta_path, total_this_run)

        return {
            "indexed": total_this_run,
            "total_in_collection": store.count(),
        }
    finally:
        store.close()


class ChatMemoryIndexer:
    """Singleton indexer that manages background indexing of chat messages.

    All operations run in-process using SQLite FTS5.
    """

    _instance: "ChatMemoryIndexer | None" = None
    _instance_lock = threading.Lock()

    def __new__(cls) -> "ChatMemoryIndexer":
        with cls._instance_lock:
            if cls._instance is None:
                inst = super().__new__(cls)
                inst._initialized = False
                cls._instance = inst
            return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        self._thread: threading.Thread | None = None
        self._thread_lock = threading.Lock()
        self.progress = IndexProgress()

    def get_progress(self) -> dict:
        return self.progress.to_dict()

    def ensure_indexing_started(self) -> None:
        with self._thread_lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._thread = threading.Thread(
                target=self._run_index,
                daemon=True,
                name="chat-memory-indexer",
            )
            self._thread.start()

    def _run_index(self) -> None:
        try:
            self.progress.set_indexing(0)
            result = run_index()

            if "error" in result:
                self.progress.set_error(result["error"])
                return

            indexed = result.get("indexed", 0)
            total = result.get("total_in_collection", 0)

            if indexed == 0:
                self.progress.set_idle(total)
            else:
                self.progress.set_done(total, indexed)

        except Exception as e:
            self.progress.set_error(str(e))


