"""Import existing cursor rules into repo memory.

Supports both:
- Legacy: .cursorrules (single file)
- Modern: .cursor/rules/*.mdc (directory with multiple rule files)
"""

import re
from pathlib import Path
from datetime import datetime
from typing import NamedTuple

from dcp.schemas.memory import (
    RepoMemory,
    Learning,
    RepoGuideline,
    ConfidenceScore,
)


class RulesLocation(NamedTuple):
    """Location of cursor rules."""
    path: Path
    is_modern: bool  # True for .cursor/rules/, False for legacy .cursorrules


def find_cursor_rules(repo_path: str | Path) -> RulesLocation | None:
    """Find cursor rules in repo (modern or legacy).
    
    Returns:
        RulesLocation with path and format type, or None if not found.
    """
    path = Path(repo_path)
    
    # Check modern format first (.cursor/rules/)
    modern_path = path / ".cursor" / "rules"
    if modern_path.exists() and modern_path.is_dir():
        mdc_files = list(modern_path.glob("*.mdc"))
        if mdc_files:
            return RulesLocation(modern_path, is_modern=True)
    
    # Check legacy format (.cursorrules)
    legacy_candidates = [
        path / ".cursorrules",
        path / "cursorrules",
    ]
    
    for candidate in legacy_candidates:
        if candidate.exists() and candidate.is_file():
            return RulesLocation(candidate, is_modern=False)
    
    return None


# Keep old function name for backwards compatibility
def find_cursorrules(repo_path: str | Path) -> Path | None:
    """Find .cursorrules file in repo (legacy function)."""
    result = find_cursor_rules(repo_path)
    if result and not result.is_modern:
        return result.path
    return None


def parse_mdc_file(content: str) -> dict:
    """Parse a single .mdc file with frontmatter.
    
    Returns dict with:
    - description: from frontmatter
    - globs: file patterns for auto-attach
    - always_apply: whether rule always applies
    - rules: extracted rules from body
    """
    result = {
        "description": "",
        "globs": [],
        "always_apply": False,
        "rules": [],
    }
    
    # Parse frontmatter (between --- markers)
    frontmatter_match = re.match(r'^---\s*\n(.*?)\n---\s*\n(.*)$', content, re.DOTALL)
    
    if frontmatter_match:
        frontmatter = frontmatter_match.group(1)
        body = frontmatter_match.group(2)
        
        # Parse frontmatter fields
        for line in frontmatter.split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip().lower()
                value = value.strip()
                
                if key == 'description':
                    result["description"] = value
                elif key == 'globs':
                    # Parse as YAML-style list
                    if value.startswith('['):
                        globs = re.findall(r'"([^"]+)"', value)
                        result["globs"] = globs
                elif key == 'alwaysapply':
                    result["always_apply"] = value.lower() == 'true'
    else:
        body = content
    
    # Extract rules from body (bullet points and headers)
    bullets = re.findall(r'^[-*]\s+\*\*(.+?)\*\*', body, re.MULTILINE)
    bullets.extend(re.findall(r'^[-*]\s+(.+)$', body, re.MULTILINE))
    
    # Filter out very short items and duplicates
    seen = set()
    for bullet in bullets:
        bullet = bullet.strip()
        if len(bullet) > 15 and bullet not in seen:
            result["rules"].append(bullet)
            seen.add(bullet)
    
    return result


def parse_modern_rules(rules_dir: Path) -> dict:
    """Parse all .mdc files in a .cursor/rules/ directory.
    
    Returns dict with aggregated:
    - rules: list of all rules
    - conventions: list of conventions
    - patterns: list of patterns
    - context: list of context info
    """
    result = {
        "rules": [],
        "conventions": [],
        "patterns": [],
        "context": [],
    }
    
    for mdc_file in rules_dir.glob("*.mdc"):
        try:
            content = mdc_file.read_text(encoding="utf-8")
            parsed = parse_mdc_file(content)
            
            # Add description as context
            if parsed["description"]:
                result["context"].append(f"Rule: {mdc_file.stem} - {parsed['description']}")
            
            # Add extracted rules
            result["rules"].extend(parsed["rules"])
        except Exception:
            continue
    
    return result


def parse_cursorrules(content: str) -> dict:
    """Parse .cursorrules content into structured data.
    
    Returns dict with:
    - rules: list of extracted rules
    - conventions: list of naming/style conventions
    - patterns: list of code patterns
    - context: general context information
    """
    result = {
        "rules": [],
        "conventions": [],
        "patterns": [],
        "context": [],
    }
    
    # Split into sections (markdown headers)
    sections = re.split(r'^##?\s+', content, flags=re.MULTILINE)
    
    for section in sections:
        if not section.strip():
            continue
        
        lines = section.strip().split('\n')
        header = lines[0].strip().lower() if lines else ""
        body = '\n'.join(lines[1:]).strip() if len(lines) > 1 else ""
        
        # Extract bullet points as individual items
        bullets = re.findall(r'^[-*]\s+(.+)$', body, re.MULTILINE)
        
        # Categorize based on header keywords
        if any(kw in header for kw in ['rule', 'always', 'never', 'must', 'require']):
            result["rules"].extend(bullets if bullets else [body] if body else [])
        elif any(kw in header for kw in ['convention', 'naming', 'style', 'format']):
            result["conventions"].extend(bullets if bullets else [body] if body else [])
        elif any(kw in header for kw in ['pattern', 'architecture', 'structure']):
            result["patterns"].extend(bullets if bullets else [body] if body else [])
        elif any(kw in header for kw in ['context', 'about', 'overview', 'tech']):
            result["context"].extend(bullets if bullets else [body] if body else [])
        else:
            # Default: treat bullet points as rules
            if bullets:
                result["rules"].extend(bullets)
    
    # Also extract any standalone bullet points not in sections
    standalone_bullets = re.findall(r'^[-*]\s+(.+)$', content, re.MULTILINE)
    
    # Filter out duplicates
    all_found = set(result["rules"] + result["conventions"] + result["patterns"])
    for bullet in standalone_bullets:
        if bullet not in all_found and len(bullet) > 10:  # Skip very short items
            result["rules"].append(bullet)
    
    return result


def import_cursor_rules(
    repo_path: str | Path,
    memory: RepoMemory,
    backup: bool = True,
) -> tuple[RepoMemory, dict]:
    """Import cursor rules into repo memory (modern or legacy).
    
    Args:
        repo_path: Path to the repository
        memory: RepoMemory to update
        backup: Whether to backup the original files
    
    Returns:
        Tuple of (updated memory, import summary)
    """
    path = Path(repo_path)
    location = find_cursor_rules(path)
    
    if location is None:
        return memory, {"imported": False, "reason": "No cursor rules found"}
    
    # Parse based on format
    if location.is_modern:
        # Modern .cursor/rules/*.mdc format
        parsed = parse_modern_rules(location.path)
        source_desc = f".cursor/rules/ ({len(list(location.path.glob('*.mdc')))} files)"
    else:
        # Legacy .cursorrules format
        content = location.path.read_text(encoding="utf-8")
        parsed = parse_cursorrules(content)
        source_desc = str(location.path)
        
        # Backup legacy file
        if backup:
            backup_path = location.path.with_suffix(".cursorrules.backup")
            backup_path.write_text(content, encoding="utf-8")
    
    # Import rules as repo guidelines
    rules_imported = 0
    for i, rule in enumerate(parsed["rules"][:20]):  # Limit to 20
        if len(rule) < 10:  # Skip very short rules
            continue
        
        guideline_id = f"imported-{i+1:03d}"
        
        # Check if already exists
        existing = [g for g in memory.repo_guidelines if g.rule == rule]
        if existing:
            continue
        
        memory.repo_guidelines.append(RepoGuideline(
            id=guideline_id,
            rule=rule,
            rationale="Imported from existing cursor rules",
            severity="recommended",
        ))
        rules_imported += 1
    
    # Import conventions
    if parsed["conventions"]:
        memory.conventions.patterns.extend(
            c for c in parsed["conventions"] 
            if c not in memory.conventions.patterns
        )
    
    # Import patterns as learnings
    learnings_imported = 0
    for i, pattern in enumerate(parsed["patterns"][:10]):  # Limit to 10
        if len(pattern) < 10:
            continue
        
        learning = Learning(
            id=f"imported-pattern-{i+1:03d}",
            summary=pattern,
            category="gotchas",
            source_mode="import",
            confidence=ConfidenceScore(
                score=60,
                level="medium",
                factors={"source": "cursor_rules_import"},
            ),
            date=datetime.now(),
        )
        memory.learnings.gotchas.append(learning)
        learnings_imported += 1
    
    # Import context
    if parsed["context"]:
        memory.context.team_notes.extend(
            c for c in parsed["context"]
            if c not in memory.context.team_notes
        )
    
    summary = {
        "imported": True,
        "source": source_desc,
        "format": "modern" if location.is_modern else "legacy",
        "backup": str(location.path.with_suffix(".cursorrules.backup")) if backup and not location.is_modern else None,
        "rules_imported": rules_imported,
        "conventions_imported": len(parsed["conventions"]),
        "learnings_imported": learnings_imported,
        "context_imported": len(parsed["context"]),
    }
    
    return memory, summary


# Keep old function name for backwards compatibility
def import_cursorrules(
    repo_path: str | Path,
    memory: RepoMemory,
    backup: bool = True,
) -> tuple[RepoMemory, dict]:
    """Import cursor rules into repo memory (legacy function name)."""
    return import_cursor_rules(repo_path, memory, backup)
