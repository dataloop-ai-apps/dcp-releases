"""Starter knowledge templates based on tech stack (v2 — flat schema)."""

from dcp.schemas.memory import Learning


def get_starter_learnings(tech_stack: dict) -> list[Learning]:
    """Get starter learnings based on detected tech stack."""
    learnings: list[Learning] = []
    languages = tech_stack.get("languages", [])
    frameworks = tech_stack.get("frameworks", [])

    if "typescript" in languages:
        learnings.extend([
            Learning(id="starter-ts-001", summary="Prefer `unknown` over `any` for untyped data", category="review_feedback", confidence=50),
            Learning(id="starter-ts-002", summary="Use strict null checks - avoid `!` non-null assertion", category="review_feedback", confidence=50),
            Learning(id="starter-ts-003", summary="Prefer `const` over `let` when value won't be reassigned", category="review_feedback", confidence=50),
        ])

    if "python" in languages:
        learnings.extend([
            Learning(id="starter-py-001", summary="Use type hints for function signatures", category="review_feedback", confidence=50),
            Learning(id="starter-py-002", summary="Prefer f-strings over .format() or % formatting", category="review_feedback", confidence=50),
            Learning(id="starter-py-003", summary="Use pathlib.Path instead of os.path for path operations", category="review_feedback", confidence=50),
        ])

    if "react" in frameworks:
        learnings.extend([
            Learning(id="starter-react-001", summary="Memoize expensive computations with useMemo", category="review_feedback", confidence=50),
            Learning(id="starter-react-002", summary="Use useCallback for functions passed as props", category="review_feedback", confidence=50),
        ])

    if "fastify" in frameworks:
        learnings.extend([
            Learning(id="starter-fastify-001", summary="Use JSON Schema validation for all route inputs", category="review_feedback", confidence=50),
        ])

    if "django" in frameworks:
        learnings.extend([
            Learning(id="starter-django-001", summary="Use select_related/prefetch_related to avoid N+1 queries", category="review_feedback", confidence=50),
        ])

    return learnings


def get_starter_conventions(tech_stack: dict) -> list[str]:
    """Get starter conventions based on detected tech stack."""
    conventions: list[str] = []
    languages = tech_stack.get("languages", [])

    if "typescript" in languages or "javascript" in languages:
        conventions.extend([
            "PascalCase for types, interfaces, classes, and React components",
            "camelCase for variables, functions, and methods",
            "UPPER_SNAKE_CASE for constants",
            "One component per file for React components",
            "Co-locate tests with source files (*.test.ts)",
        ])

    if "python" in languages:
        conventions.extend([
            "snake_case for functions, variables, and modules",
            "PascalCase for classes",
            "UPPER_SNAKE_CASE for constants",
            "Use __init__.py for package exports",
        ])

    return conventions
