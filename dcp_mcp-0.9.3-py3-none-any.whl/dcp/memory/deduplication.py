"""Deduplication of learnings and conventions against base guidelines (v2)."""

from typing import NamedTuple

from dcp.schemas.memory import Learning
from dcp.guidelines.search import search_guidelines


class DeduplicationResult(NamedTuple):
    """Result of deduplication check."""
    is_duplicate: bool
    matched_guideline_id: str | None
    match_score: float
    reason: str


def check_against_guidelines(
    pattern: str,
    languages: list[str] | None = None,
    threshold: float = 0.75,
) -> DeduplicationResult:
    """Check if a pattern/learning is already covered by base guidelines."""
    try:
        results = search_guidelines(
            query=pattern,
            languages=languages,
            limit=1,
        )

        if not results:
            return DeduplicationResult(False, None, 0.0, "No matching guidelines found")

        top_match = results[0]
        similarity = 1.0 - min(top_match.relevance_score, 1.0)

        if similarity >= threshold:
            return DeduplicationResult(
                True, top_match.id, similarity,
                f"Matches guideline '{top_match.id}' ({similarity:.0%} similarity)",
            )
        else:
            return DeduplicationResult(
                False, top_match.id, similarity,
                f"Best match '{top_match.id}' below threshold ({similarity:.0%} < {threshold:.0%})",
            )
    except Exception as e:
        return DeduplicationResult(False, None, 0.0, f"Guidelines search unavailable: {e}")


def deduplicate_learnings(
    learnings: list[Learning],
    threshold: float = 0.75,
) -> tuple[list[Learning], list[dict]]:
    """Remove learnings already covered by base guidelines."""
    skipped = []
    kept = []

    for learning in learnings:
        result = check_against_guidelines(
            pattern=learning.summary,
            threshold=threshold,
        )

        if result.is_duplicate:
            skipped.append({
                "learning_id": learning.id,
                "summary": learning.summary,
                "matched_guideline": result.matched_guideline_id,
                "score": result.match_score,
                "reason": result.reason,
            })
        else:
            kept.append(learning)

    return kept, skipped


def deduplicate_conventions(
    conventions: list[str],
    languages: list[str] | None = None,
    threshold: float = 0.75,
) -> tuple[list[str], list[dict]]:
    """Remove conventions already covered by base guidelines."""
    skipped = []
    kept = []

    for item in conventions:
        result = check_against_guidelines(
            pattern=item,
            languages=languages,
            threshold=threshold,
        )

        if result.is_duplicate:
            skipped.append({
                "convention": item,
                "matched_guideline": result.matched_guideline_id,
                "score": result.match_score,
                "reason": result.reason,
            })
        else:
            kept.append(item)

    return kept, skipped
