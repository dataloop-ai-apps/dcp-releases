"""Load and save repo memory from YAML files (v2 — flat schema)."""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from dcp.schemas.memory import (
    RepoMemory,
    Metadata,
    Stack,
    Context,
    Learning,
    DocReference,
)

logger = logging.getLogger(__name__)

MEMORY_FILE = ".dcp/memory.yaml"


def get_memory_path(repo_path: str | Path) -> Path:
    """Get the path to the memory file for a repo."""
    return Path(repo_path) / MEMORY_FILE


def memory_exists(repo_path: str | Path) -> bool:
    """Check if memory exists for a repo."""
    return get_memory_path(repo_path).exists()


def load_memory(repo_path: str | Path) -> RepoMemory | None:
    """Load memory from a repo's .dcp/memory.yaml file.

    Handles both old (v1) and new (v2) schema formats by migrating
    old format on the fly.
    """
    memory_path = get_memory_path(repo_path)

    if not memory_path.exists():
        return None

    with open(memory_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if data is None:
        return None

    if not isinstance(data, dict):
        return None

    if _is_old_format(data):
        data = _migrate_v1_to_v2(data)
        logger.info("Migrated memory from v1 to v2 format for %s", memory_path)

    try:
        return RepoMemory(**data)
    except (ValidationError, Exception) as exc:
        logger.warning(
            "Strict load failed for %s, attempting safe recovery: %s",
            memory_path, exc,
        )
        return _load_memory_safe(data)


def _is_old_format(data: dict) -> bool:
    """Detect whether data uses the old (v1) schema."""
    if "tech_stack" in data and "stack" not in data:
        return True
    if "repo_guidelines" in data:
        return True
    if "git_discoveries" in data:
        return True
    if isinstance(data.get("architecture"), dict):
        return True
    if isinstance(data.get("conventions"), dict):
        return True
    if isinstance(data.get("learnings"), dict):
        return True
    version = (data.get("metadata") or {}).get("version", "")
    if version and not version.startswith("2"):
        return True
    return False


def _migrate_v1_to_v2(data: dict) -> dict:
    """Convert old v1 memory format to v2."""
    new: dict[str, Any] = {}

    # Metadata
    old_meta = data.get("metadata", {})
    if isinstance(old_meta, str):
        try:
            old_meta = json.loads(old_meta)
        except Exception:
            old_meta = {}
    new["metadata"] = {
        "repo_name": old_meta.get("repo_name", "unknown"),
        "created_at": old_meta.get("created_at", datetime.now().isoformat()),
        "last_updated": datetime.now().isoformat(),
        "version": "2.0",
    }

    # Architecture: was nested dict → now free-text string
    arch = data.get("architecture")
    if isinstance(arch, dict):
        parts = []
        if arch.get("type"):
            parts.append(f"Type: {arch['type']}")
        if arch.get("description"):
            parts.append(arch["description"])
        if arch.get("key_components"):
            for comp in arch["key_components"]:
                if isinstance(comp, dict):
                    parts.append(f"- {comp.get('name', '?')}: {comp.get('responsibility', '')}")
        new["architecture"] = "\n".join(parts) if parts else ""
    elif isinstance(arch, str):
        new["architecture"] = arch
    else:
        new["architecture"] = ""

    # Stack: was "tech_stack" with nested dependencies → flat "stack"
    ts = data.get("tech_stack") or data.get("stack")
    if isinstance(ts, dict):
        new["stack"] = {
            "languages": ts.get("languages", []),
            "runtime": ts.get("runtime"),
            "frameworks": ts.get("frameworks", []),
            "database": ts.get("database"),
            "testing": ts.get("testing"),
        }
    else:
        new["stack"] = {}

    # Conventions: was object with sub-lists → flat list of strings
    conv = data.get("conventions")
    if isinstance(conv, dict):
        flat: list[str] = []
        for key in ["naming", "file_structure", "patterns", "imports", "testing"]:
            items = conv.get(key, [])
            if isinstance(items, list):
                flat.extend(str(item) for item in items)
        new["conventions"] = flat
    elif isinstance(conv, list):
        new["conventions"] = [str(c) for c in conv]
    else:
        new["conventions"] = []

    # Context: was 4 fields → single notes list
    ctx = data.get("context")
    if isinstance(ctx, dict):
        notes: list[str] = []
        if ctx.get("notes"):
            notes.extend(ctx["notes"] if isinstance(ctx["notes"], list) else [str(ctx["notes"])])
        for field in ["active_migrations", "known_issues", "team_notes"]:
            items = ctx.get(field, [])
            if isinstance(items, list):
                notes.extend(str(item) for item in items)
            elif isinstance(items, str):
                notes.append(items)
        if ctx.get("current_sprint"):
            notes.append(f"Sprint: {ctx['current_sprint']}")
        new["context"] = {"notes": notes}
    else:
        new["context"] = {"notes": []}

    # Learnings: was categorized dict with nested ConfidenceScore → flat list
    learnings_data = data.get("learnings")
    flat_learnings: list[dict] = []

    if isinstance(learnings_data, dict):
        for category in ["review_feedback", "bug_patterns", "edge_cases", "gotchas", "decisions"]:
            items = learnings_data.get(category, [])
            if not isinstance(items, list):
                continue
            for item in items:
                if isinstance(item, dict):
                    conf = item.get("confidence", 50)
                    if isinstance(conf, dict):
                        conf = conf.get("score", 50)
                    flat_learnings.append({
                        "id": item.get("id", f"migrated-{len(flat_learnings)}"),
                        "summary": item.get("summary", ""),
                        "category": item.get("category", category),
                        "confidence": int(conf) if conf else 50,
                        "date": item.get("date", datetime.now().isoformat()),
                    })
    elif isinstance(learnings_data, list):
        for item in learnings_data:
            if isinstance(item, dict):
                conf = item.get("confidence", 50)
                if isinstance(conf, dict):
                    conf = conf.get("score", 50)
                flat_learnings.append({
                    "id": item.get("id", f"migrated-{len(flat_learnings)}"),
                    "summary": item.get("summary", ""),
                    "category": item.get("category", "decisions"),
                    "confidence": int(conf) if conf else 50,
                    "date": item.get("date", datetime.now().isoformat()),
                })

    # Migrate repo_guidelines into learnings (high confidence)
    guidelines = data.get("repo_guidelines", [])
    if isinstance(guidelines, list):
        for g in guidelines:
            if isinstance(g, dict):
                severity = g.get("severity", "recommended")
                conf = {"required": 95, "recommended": 75, "optional": 50}.get(severity, 75)
                flat_learnings.append({
                    "id": g.get("id", f"guideline-{len(flat_learnings)}"),
                    "summary": g.get("rule", ""),
                    "category": "decisions",
                    "confidence": conf,
                    "date": datetime.now().isoformat(),
                })

    new["learnings"] = flat_learnings

    # Docs: carry over if present (v1 didn't have this, but be forward-safe)
    if isinstance(data.get("docs"), list):
        new["docs"] = data["docs"]
    else:
        new["docs"] = []

    return new


def _load_memory_safe(data: dict) -> RepoMemory | None:
    """Load memory with per-field resilience."""
    try:
        meta_data = data.get("metadata", {})
        if isinstance(meta_data, str):
            try:
                meta_data = json.loads(meta_data)
            except Exception:
                meta_data = {}
        metadata = Metadata(**meta_data) if isinstance(meta_data, dict) else Metadata(repo_name="unknown")
    except Exception:
        metadata = Metadata(repo_name="unknown")

    memory = RepoMemory(metadata=metadata)

    if isinstance(data.get("architecture"), str):
        memory.architecture = data["architecture"]

    if isinstance(data.get("stack"), dict):
        try:
            memory.stack = Stack(**data["stack"])
        except Exception:
            pass

    if isinstance(data.get("conventions"), list):
        memory.conventions = [str(c) for c in data["conventions"]]

    if isinstance(data.get("context"), dict):
        try:
            memory.context = Context(**data["context"])
        except Exception:
            pass

    if isinstance(data.get("learnings"), list):
        for item in data["learnings"]:
            try:
                if isinstance(item, dict):
                    memory.learnings.append(Learning(**item))
            except Exception:
                pass

    if isinstance(data.get("docs"), list):
        for item in data["docs"]:
            try:
                if isinstance(item, dict):
                    memory.docs.append(DocReference(**item))
            except Exception:
                pass

    return memory


def save_memory(repo_path: str | Path, memory: RepoMemory) -> Path:
    """Save memory to a repo's .dcp/memory.yaml file."""
    memory_path = get_memory_path(repo_path)
    memory_path.parent.mkdir(parents=True, exist_ok=True)

    memory.update_timestamp()

    data = memory.model_dump(mode="json", exclude_none=True)

    with open(memory_path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    return memory_path


def create_initial_memory(repo_path: str | Path, repo_name: str | None = None) -> RepoMemory:
    """Create initial memory structure for a new repo."""
    path = Path(repo_path)

    if repo_name is None:
        repo_name = path.name

    return RepoMemory(
        metadata=Metadata(
            repo_name=repo_name,
            created_at=datetime.now(),
            last_updated=datetime.now(),
        )
    )
