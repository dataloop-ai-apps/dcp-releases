"""Git history analysis for smart initialization."""

import re
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

try:
    import git
    HAS_GIT = True
except ImportError:
    HAS_GIT = False

from dataclasses import dataclass, field


@dataclass
class GitDiscoveries:
    """Discoveries from git history analysis (local to analyzer)."""
    branch_patterns: list[dict] = field(default_factory=list)
    commit_patterns: list[dict] = field(default_factory=list)
    hot_files: list[dict] = field(default_factory=list)
    contributors: list[dict] = field(default_factory=list)
    test_patterns: list[dict] = field(default_factory=list)


def analyze_git_history(
    repo_path: str | Path,
    commits_to_analyze: int = 100,
) -> GitDiscoveries | None:
    """Analyze git history to discover patterns and conventions.
    
    Args:
        repo_path: Path to the repository
        commits_to_analyze: Number of recent commits to analyze
    
    Returns:
        GitDiscoveries object or None if not a git repo
    """
    if not HAS_GIT:
        return None
    
    try:
        repo = git.Repo(repo_path)
    except git.InvalidGitRepositoryError:
        return None
    
    discoveries = GitDiscoveries()
    
    # Analyze branches
    discoveries.branch_patterns = _analyze_branch_patterns(repo)
    
    # Analyze commits
    commit_data = _analyze_commits(repo, commits_to_analyze)
    discoveries.commit_patterns = commit_data["patterns"]
    discoveries.hot_files = commit_data["hot_files"]
    discoveries.contributors = commit_data["contributors"]
    
    # Analyze test patterns from file structure
    discoveries.test_patterns = _analyze_test_patterns(repo_path)
    
    return discoveries


def _analyze_branch_patterns(repo: "git.Repo") -> list[dict[str, Any]]:
    """Analyze branch naming patterns."""
    patterns: list[dict[str, Any]] = []
    branch_names = [ref.name for ref in repo.refs if isinstance(ref, git.Head)]
    
    # Common patterns to look for
    pattern_regexes = {
        "feature/{ticket}-{description}": r"^feature/[A-Z]+-\d+-[\w-]+$",
        "feature/{description}": r"^feature/[\w-]+$",
        "bugfix/{ticket}-{description}": r"^bugfix/[A-Z]+-\d+-[\w-]+$",
        "bugfix/{description}": r"^bugfix/[\w-]+$",
        "hotfix/{description}": r"^hotfix/[\w-]+$",
        "release/{version}": r"^release/v?\d+\.\d+(\.\d+)?$",
    }
    
    for pattern_name, regex in pattern_regexes.items():
        matches = [b for b in branch_names if re.match(regex, b)]
        if matches:
            patterns.append({
                "pattern": pattern_name,
                "examples": matches[:3],
                "confidence": min(90, 50 + len(matches) * 10),
                "occurrences": len(matches),
            })
    
    return sorted(patterns, key=lambda x: x["confidence"], reverse=True)


def _analyze_commits(
    repo: "git.Repo",
    limit: int,
) -> dict[str, Any]:
    """Analyze commit history."""
    commit_patterns: list[dict[str, Any]] = []
    file_changes: Counter = Counter()
    contributors: dict[str, dict[str, Any]] = {}
    
    try:
        commits = list(repo.iter_commits(max_count=limit))
    except git.GitCommandError:
        return {"patterns": [], "hot_files": [], "contributors": []}
    
    # Analyze commit messages
    conventional_count = 0
    ticket_prefix_count = 0
    
    for commit in commits:
        message = commit.message.strip()
        
        # Check for conventional commits
        if re.match(r"^(feat|fix|docs|style|refactor|test|chore)(\(.+\))?:", message):
            conventional_count += 1
        
        # Check for ticket prefix
        if re.match(r"^[A-Z]+-\d+[:\s]", message):
            ticket_prefix_count += 1
        
        # Track file changes
        try:
            for file in commit.stats.files:
                file_changes[file] += 1
        except Exception:
            pass
        
        # Track contributors
        author = commit.author.name
        email = commit.author.email
        if author not in contributors:
            contributors[author] = {
                "name": author,
                "email": email,
                "commit_count": 0,
                "recent_areas": set(),
            }
        contributors[author]["commit_count"] += 1
        
        # Track areas
        try:
            for file in commit.stats.files:
                parts = file.split("/")
                if len(parts) > 1:
                    contributors[author]["recent_areas"].add(parts[0] + "/")
        except Exception:
            pass
    
    # Determine commit patterns
    total = len(commits)
    if total > 0:
        if conventional_count / total > 0.5:
            commit_patterns.append({
                "pattern": "conventional_commits",
                "examples": [],
                "confidence": int(conventional_count / total * 100),
            })
        
        if ticket_prefix_count / total > 0.5:
            commit_patterns.append({
                "pattern": "ticket_prefix",
                "examples": [],
                "confidence": int(ticket_prefix_count / total * 100),
            })
    
    # Get hot files (changed frequently)
    hot_files = []
    thirty_days_ago = datetime.now() - timedelta(days=30)
    
    for file, count in file_changes.most_common(10):
        if count >= 5:  # At least 5 changes
            hot_files.append({
                "path": file,
                "changes_last_month": count,
                "note": "Frequently modified - consider reviewing",
            })
    
    # Format contributors
    contributor_list = []
    for author, data in sorted(
        contributors.items(),
        key=lambda x: x[1]["commit_count"],
        reverse=True
    )[:5]:
        contributor_list.append({
            "name": data["name"],
            "email": data["email"],
            "recent_areas": list(data["recent_areas"])[:5],
        })
    
    return {
        "patterns": commit_patterns,
        "hot_files": hot_files[:5],
        "contributors": contributor_list,
    }


def _analyze_test_patterns(repo_path: str | Path) -> list[dict[str, Any]]:
    """Analyze test file patterns."""
    patterns: list[dict[str, Any]] = []
    path = Path(repo_path)
    
    # Check for common test patterns
    test_patterns_to_check = [
        ("*.test.ts", "Co-located tests (*.test.ts)"),
        ("*.test.js", "Co-located tests (*.test.js)"),
        ("*_test.py", "Co-located tests (*_test.py)"),
        ("test_*.py", "Co-located tests (test_*.py)"),
        ("*.spec.ts", "Co-located specs (*.spec.ts)"),
        ("*.spec.js", "Co-located specs (*.spec.js)"),
    ]
    
    for pattern, description in test_patterns_to_check:
        matches = list(path.rglob(pattern))
        if matches:
            patterns.append({
                "type": "test_file_naming",
                "pattern": pattern,
                "description": description,
                "confidence": min(95, 70 + len(matches)),
                "examples": [str(m.relative_to(path)) for m in matches[:3]],
            })
    
    # Check for __tests__ directories
    test_dirs = list(path.rglob("__tests__"))
    if test_dirs:
        patterns.append({
            "type": "test_directory",
            "pattern": "__tests__/",
            "description": "Separate test directories",
            "confidence": 90,
            "examples": [str(d.relative_to(path)) for d in test_dirs[:3]],
        })
    
    # Check for tests/ directory at root
    if (path / "tests").exists():
        patterns.append({
            "type": "test_directory",
            "pattern": "tests/",
            "description": "Root tests directory",
            "confidence": 90,
        })
    
    return patterns


def detect_tech_stack(repo_path: str | Path) -> dict[str, Any]:
    """Detect the technology stack from files in the repo."""
    path = Path(repo_path)
    tech_stack: dict[str, Any] = {
        "languages": [],
        "frameworks": [],
        "testing": None,
        "orm": None,
        "database": None,
    }
    
    # Language detection
    if list(path.rglob("*.ts")) or list(path.rglob("*.tsx")):
        tech_stack["languages"].append("typescript")
    if list(path.rglob("*.js")) or list(path.rglob("*.jsx")):
        if "typescript" not in tech_stack["languages"]:
            tech_stack["languages"].append("javascript")
    if list(path.rglob("*.py")):
        tech_stack["languages"].append("python")
    if list(path.rglob("*.go")):
        tech_stack["languages"].append("go")
    if list(path.rglob("*.rs")):
        tech_stack["languages"].append("rust")
    
    # Framework detection from package.json
    package_json = path / "package.json"
    if package_json.exists():
        try:
            import json
            with open(package_json) as f:
                pkg = json.load(f)
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            
            # Frameworks
            if "react" in deps:
                tech_stack["frameworks"].append("react")
            if "vue" in deps:
                tech_stack["frameworks"].append("vue")
            if "fastify" in deps:
                tech_stack["frameworks"].append("fastify")
            if "express" in deps:
                tech_stack["frameworks"].append("express")
            if "next" in deps:
                tech_stack["frameworks"].append("next.js")
            
            # Testing
            if "vitest" in deps:
                tech_stack["testing"] = "vitest"
            elif "jest" in deps:
                tech_stack["testing"] = "jest"
            elif "mocha" in deps:
                tech_stack["testing"] = "mocha"
            
            # ORM
            if "prisma" in deps or "@prisma/client" in deps:
                tech_stack["orm"] = "prisma"
            elif "typeorm" in deps:
                tech_stack["orm"] = "typeorm"
            elif "sequelize" in deps:
                tech_stack["orm"] = "sequelize"
        except Exception:
            pass
    
    # Python framework detection
    requirements = path / "requirements.txt"
    pyproject = path / "pyproject.toml"
    
    if requirements.exists():
        try:
            with open(requirements) as f:
                content = f.read().lower()
            if "django" in content:
                tech_stack["frameworks"].append("django")
            if "fastapi" in content:
                tech_stack["frameworks"].append("fastapi")
            if "flask" in content:
                tech_stack["frameworks"].append("flask")
            if "pytest" in content:
                tech_stack["testing"] = "pytest"
            if "sqlalchemy" in content:
                tech_stack["orm"] = "sqlalchemy"
        except Exception:
            pass
    
    if pyproject.exists():
        try:
            with open(pyproject) as f:
                content = f.read().lower()
            if "django" in content:
                tech_stack["frameworks"].append("django")
            if "fastapi" in content:
                tech_stack["frameworks"].append("fastapi")
            if "pytest" in content:
                tech_stack["testing"] = "pytest"
        except Exception:
            pass
    
    return tech_stack
