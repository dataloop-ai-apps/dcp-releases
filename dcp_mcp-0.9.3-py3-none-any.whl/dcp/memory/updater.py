"""Memory update operations (v2 — simplified).

This module is kept for backward compatibility but the main update logic
is now handled directly in memory_tools.handle_update_memory.
"""

from typing import Any
from dcp.schemas.memory import RepoMemory
