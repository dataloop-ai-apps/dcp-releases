"""Dev Control Plane (DCP) - MCP server for development modes, guidelines, and active learning."""

__version__ = "0.9.3"


def create_server():
    from dcp.server import create_server as _create
    return _create()


def run_server():
    from dcp.server import run_server as _run
    _run()


__all__ = ["create_server", "run_server", "__version__"]
