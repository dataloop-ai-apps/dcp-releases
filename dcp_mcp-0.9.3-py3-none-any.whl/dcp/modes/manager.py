"""Mode manager for handling mode selection and state."""

import os
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from dcp.schemas.modes import ModeDefinition, CustomModeDefinition, ModeInfo
from dcp.modes.loader import load_builtin_modes, load_custom_modes


InteractionStyle = Literal["interactive", "autonomous"]

BASE_DIRECTIVES = """
FILE OUTPUT RULES:
When creating planning documents, reports, or working artifacts (PRDs, ADRs, design docs,
test plans, review reports, debug findings, diagrams, etc.), always write them to the
`.plans/` directory in the repo root. Create the directory if it doesn't exist.
This directory is git-ignored to keep the repo clean.

Naming convention: `.plans/<mode>-<descriptive-name>.md`
Examples: `.plans/planner-user-auth-prd.md`, `.plans/planner-api-design.md`,
          `.plans/tester-payment-flow-test-plan.md`

This does NOT apply to actual source code, test files, or documentation that should be
committed to the repository (e.g., README.md, API docs, test suites).

DOCUMENTATION RULES:
When documenting operational flows, setup instructions, or reusable procedures (release flow,
local development, running tests, deployment, CI/CD, etc.), use the `save_doc` tool to save
them to `.dcp/docs/` with a memory reference. This makes them discoverable via `read_memory`.

When to use `save_doc`:
- The user asks to document a flow or process
- You discover an undocumented operational procedure
- You write setup/installation instructions
- You create a runbook or troubleshooting guide

Check `read_memory` section `docs` first to see if a relevant doc already exists before
creating a new one. Update existing docs rather than creating duplicates.
"""

INTERACTIVE_DIRECTIVES = """
INTERACTIVE MODE:
- Be short and accurate. Say what's needed, nothing more.
- No filler words, no verbose explanations, no restating what was already said.
- When writing code, keep it clean — no duplication, no redundant comments, no boilerplate bloat.
- Do exactly what was asked within reasonable scope. Don't invent extra requirements,
  add unrequested features, or over-engineer the solution.
- If something is unclear, ask — don't guess and build.
- Ask clarifying questions when requirements are ambiguous.
- Propose options and wait for user confirmation before significant decisions.
- Suggest mode transitions when appropriate (e.g., "Ready to implement? Switch to developer").
- Provide detailed explanations when making non-obvious choices.
- Include confidence indicators for suggestions.
"""

AUTONOMOUS_DIRECTIVES = """
AUTONOMOUS MODE:
- You are running in non-interactive mode. stdin is closed. Do NOT ask questions.
- If a mode instruction says "ask the user", "offer to", "propose options", or
  "wait for confirmation" -- OVERRIDE IT. Instead, make a reasonable decision,
  state your assumption briefly, and proceed.
- Execute tasks to completion. Do not pause for confirmation.
- Keep output concise. No verbose explanations unless diagnosing a failure.
- When writing code, keep it clean — no duplication, no redundant comments, no boilerplate bloat.
- Do exactly what was asked within reasonable scope. Don't invent extra requirements,
  add unrequested features, or over-engineer the solution.
- Write an execution summary to `.plans/EXECUTION_SUMMARY.md` before finishing.
- If you encounter a blocker you truly cannot resolve, document it in the summary and stop.
"""

# Backward compat: SHARED_DIRECTIVES and FILE_OUTPUT_DIRECTIVE for any external imports
SHARED_DIRECTIVES = BASE_DIRECTIVES + INTERACTIVE_DIRECTIVES
FILE_OUTPUT_DIRECTIVE = SHARED_DIRECTIVES


def get_interaction_style() -> InteractionStyle:
    """Read interaction style from DCP_INTERACTION_STYLE env var."""
    style = os.environ.get("DCP_INTERACTION_STYLE", "interactive").lower()
    if style not in ("interactive", "autonomous"):
        return "interactive"
    return style  # type: ignore[return-value]


def get_style_directives(style: InteractionStyle | None = None) -> str:
    """Get the full directives block for a given interaction style."""
    if style is None:
        style = get_interaction_style()
    if style == "autonomous":
        return BASE_DIRECTIVES + AUTONOMOUS_DIRECTIVES
    return BASE_DIRECTIVES + INTERACTIVE_DIRECTIVES


class ModeManager:
    """Manages development modes and their state."""
    
    def __init__(self, repo_path: str | Path | None = None):
        self.repo_path = Path(repo_path) if repo_path else None
        self._builtin_modes: dict[str, ModeDefinition] = {}
        self._custom_modes: dict[str, CustomModeDefinition] = {}
        self._resolved_modes: dict[str, ModeDefinition] = {}
        self._current_mode: str | None = None
        self._current_context: str | None = None
        self._mode_activated_at: datetime | None = None
        self._interaction_style: InteractionStyle = get_interaction_style()
        
        self._load_modes()
    
    def _load_modes(self) -> None:
        """Load all built-in and custom modes."""
        self._builtin_modes = load_builtin_modes()
        
        if self.repo_path:
            self._custom_modes = load_custom_modes(self.repo_path)
        
        self._resolve_all_modes()
    
    def _resolve_all_modes(self) -> None:
        """Resolve all modes including custom mode inheritance."""
        # Start with built-in modes
        self._resolved_modes = dict(self._builtin_modes)
        
        # Resolve and add custom modes
        for mode_id, custom_mode in self._custom_modes.items():
            parent = None
            if custom_mode.extends:
                parent = self._builtin_modes.get(custom_mode.extends)
            
            resolved = custom_mode.resolve(parent)
            self._resolved_modes[mode_id] = resolved
    
    def reload_modes(self, repo_path: str | Path | None = None) -> None:
        """Reload modes, optionally from a new repo path."""
        if repo_path:
            self.repo_path = Path(repo_path)
        self._load_modes()
    
    def list_modes(self, include_custom: bool = True) -> list[ModeInfo]:
        """List all available modes."""
        modes: list[ModeInfo] = []
        
        # Add built-in modes
        for mode in self._builtin_modes.values():
            modes.append(ModeInfo(
                id=mode.id,
                name=mode.name,
                description=mode.description,
                source="builtin",
                triggers=mode.triggers,
            ))
        
        # Add custom modes
        if include_custom:
            for mode in self._custom_modes.values():
                modes.append(ModeInfo(
                    id=mode.id,
                    name=mode.name,
                    description=mode.description,
                    source="custom",
                    extends=mode.extends,
                    triggers=mode.triggers,
                ))
        
        return modes
    
    def get_mode(self, mode_id: str) -> ModeDefinition | None:
        """Get a resolved mode definition by ID."""
        return self._resolved_modes.get(mode_id)
    
    def select_mode(self, mode_id: str, context: str | None = None) -> ModeDefinition:
        """Select and activate a mode."""
        mode = self.get_mode(mode_id)
        if mode is None:
            raise ValueError(f"Unknown mode: {mode_id}")
        
        self._current_mode = mode_id
        self._current_context = context
        self._mode_activated_at = datetime.now()
        
        return mode
    
    def get_current_mode(self) -> dict[str, Any] | None:
        """Get information about the currently active mode."""
        if self._current_mode is None:
            return None
        
        return {
            "mode": self._current_mode,
            "activated_at": self._mode_activated_at.isoformat() if self._mode_activated_at else None,
            "context": self._current_context,
            "interaction_style": self._interaction_style,
        }
    
    def suggest_mode(self, user_input: str) -> str | None:
        """Suggest a mode based on user input keywords."""
        user_input_lower = user_input.lower()
        
        # Check all modes for trigger matches
        best_match: str | None = None
        best_score = 0
        
        for mode in self._resolved_modes.values():
            score = 0
            for trigger in mode.triggers:
                if trigger.lower() in user_input_lower:
                    score += 1
            
            if score > best_score:
                best_score = score
                best_match = mode.id
        
        return best_match
    
    @property
    def interaction_style(self) -> InteractionStyle:
        """Current interaction style."""
        return self._interaction_style

    def get_mode_prompt(self, mode_id: str, variables: dict[str, str] | None = None) -> str:
        """Get the system prompt for a mode with variables substituted and directives injected.

        Directives are selected based on the active interaction style
        (DCP_INTERACTION_STYLE env var, defaults to 'interactive').
        """
        mode = self.get_mode(mode_id)
        if mode is None:
            raise ValueError(f"Unknown mode: {mode_id}")
        
        prompt = mode.system_prompt
        
        # Substitute variables
        all_vars = mode.variables.copy()
        if variables:
            all_vars.update(variables)
        
        for key, value in all_vars.items():
            prompt = prompt.replace(f"{{{key}}}", value)
        
        prompt += "\n" + get_style_directives(self._interaction_style)
        
        return prompt
    
    def get_mode_checklist(self, mode_id: str) -> dict[str, list[str]]:
        """Get the checklist for a mode."""
        mode = self.get_mode(mode_id)
        if mode is None:
            raise ValueError(f"Unknown mode: {mode_id}")
        
        return mode.checklist
