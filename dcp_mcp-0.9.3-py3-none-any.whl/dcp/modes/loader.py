"""Load mode definitions from YAML files."""

import os
from pathlib import Path
from typing import Generator

import yaml

from dcp.schemas.modes import ModeDefinition, CustomModeDefinition


def get_builtin_modes_dir() -> Path:
    """Get the path to built-in mode definitions."""
    from dcp.paths import get_modes_dir
    return get_modes_dir()


def load_yaml_file(path: Path) -> dict:
    """Load a YAML file and return its contents."""
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_builtin_modes() -> dict[str, ModeDefinition]:
    """Load all built-in mode definitions."""
    modes_dir = get_builtin_modes_dir()
    modes: dict[str, ModeDefinition] = {}
    
    if not modes_dir.exists():
        return modes
    
    for yaml_file in modes_dir.glob("*.yaml"):
        try:
            data = load_yaml_file(yaml_file)
            mode = ModeDefinition(**data)
            modes[mode.id] = mode
        except Exception as e:
            print(f"Warning: Failed to load mode from {yaml_file}: {e}")
    
    return modes


def load_custom_modes(repo_path: str | Path) -> dict[str, CustomModeDefinition]:
    """Load custom mode definitions from a repo's .dcp/modes/ directory."""
    modes_dir = Path(repo_path) / ".dcp" / "modes"
    modes: dict[str, CustomModeDefinition] = {}
    
    if not modes_dir.exists():
        return modes
    
    for yaml_file in modes_dir.glob("*.yaml"):
        try:
            data = load_yaml_file(yaml_file)
            mode = CustomModeDefinition(**data)
            modes[mode.id] = mode
        except Exception as e:
            print(f"Warning: Failed to load custom mode from {yaml_file}: {e}")
    
    return modes


def save_custom_mode(repo_path: str | Path, mode: CustomModeDefinition) -> Path:
    """Save a custom mode definition to the repo's .dcp/modes/ directory."""
    modes_dir = Path(repo_path) / ".dcp" / "modes"
    modes_dir.mkdir(parents=True, exist_ok=True)
    
    file_path = modes_dir / f"{mode.id}.yaml"
    
    with open(file_path, "w", encoding="utf-8") as f:
        yaml.dump(mode.model_dump(exclude_none=True), f, default_flow_style=False, sort_keys=False)
    
    return file_path
