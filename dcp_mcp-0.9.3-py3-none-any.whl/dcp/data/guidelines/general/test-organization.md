---
id: general-test-organization
title: Test Organization
category: general
languages: [python, typescript, javascript]
frameworks: []
severity: required
tags: [testing, organization, structure]
---

# Test Organization

## Summary

Tests must always be placed in a dedicated `tests/` directory. Never mix test files with source code.

## Guidelines

### 1. Use a Dedicated Tests Directory

```
# ✅ Good - dedicated tests folder
project/
├── src/
│   └── mypackage/
│       ├── __init__.py
│       └── module.py
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   └── test_module.py
└── pyproject.toml
```

```
# ❌ Bad - tests mixed with source
project/
├── src/
│   └── mypackage/
│       ├── __init__.py
│       ├── module.py
│       └── test_module.py  # Don't do this!
└── pyproject.toml
```

### 2. Mirror Source Structure in Tests

```
# ✅ Good - test structure mirrors source
src/
├── api/
│   ├── routes.py
│   └── handlers.py
└── services/
    └── auth.py

tests/
├── api/
│   ├── test_routes.py
│   └── test_handlers.py
└── services/
    └── test_auth.py
```

### 3. TypeScript/JavaScript Projects

```
# ✅ Good - __tests__ or tests directory
project/
├── src/
│   ├── components/
│   │   └── Button.tsx
│   └── utils/
│       └── helpers.ts
├── tests/           # or __tests__/
│   ├── components/
│   │   └── Button.test.tsx
│   └── utils/
│       └── helpers.test.ts
└── package.json
```

```typescript
// ✅ Good - co-located test files (acceptable alternative)
src/
├── components/
│   ├── Button.tsx
│   └── Button.test.tsx  // Only if project convention allows
```

### 4. Naming Conventions

```python
# ✅ Good - clear test file naming
tests/
├── test_user_service.py      # test_ prefix (pytest)
├── test_auth_handlers.py
└── integration/
    └── test_api_flows.py
```

```typescript
// ✅ Good - .test.ts or .spec.ts suffix
tests/
├── user.service.test.ts      // .test.ts suffix
├── auth.handlers.spec.ts     // .spec.ts suffix
└── integration/
    └── api-flows.test.ts
```

### 5. Shared Test Utilities

```python
# ✅ Good - centralized test fixtures and utilities
tests/
├── conftest.py           # Shared pytest fixtures
├── fixtures/
│   ├── __init__.py
│   ├── users.py          # User test data
│   └── mocks.py          # Shared mocks
├── helpers/
│   └── assertions.py     # Custom assertions
└── test_*.py
```

```typescript
// ✅ Good - shared test utilities
tests/
├── setup.ts              // Test setup/teardown
├── fixtures/
│   ├── users.ts          // Test data factories
│   └── mocks.ts          // Shared mocks
├── helpers/
│   └── render.tsx        // Custom render utilities
└── *.test.ts
```

### 6. Separate Test Types

```
# ✅ Good - organized by test type
tests/
├── unit/                 # Fast, isolated tests
│   └── test_*.py
├── integration/          # Tests with dependencies
│   └── test_*.py
├── e2e/                  # End-to-end tests
│   └── test_*.py
└── conftest.py           # Shared across all
```

## Rationale

- **Separation of concerns**: Production code stays clean and focused
- **Build optimization**: Easy to exclude tests from production bundles
- **CI/CD**: Simple to configure test runners with a single path
- **Discoverability**: Developers know exactly where to find and add tests
- **Code coverage**: Tools can easily identify test vs source directories

## Configuration Examples

```toml
# pyproject.toml
[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = ["test_*.py"]
```

```json
// jest.config.js or package.json
{
  "jest": {
    "testMatch": ["<rootDir>/tests/**/*.test.ts"],
    "collectCoverageFrom": ["src/**/*.ts"]
  }
}
```

## Exceptions

- **Co-located component tests**: Some React/Vue projects prefer `Component.test.tsx` next to `Component.tsx` for tight coupling. This is acceptable if it's the established project convention.
- **Storybook stories**: `*.stories.tsx` files are often co-located with components.

## Related

- [Code Quality Standards](./code-quality.md)
- [Project Structure](./project-structure.md)
