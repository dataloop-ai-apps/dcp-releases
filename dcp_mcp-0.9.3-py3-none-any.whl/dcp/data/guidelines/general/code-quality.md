---
id: general-code-quality
title: Code Quality Standards
category: general
subcategory: quality
languages:
  - typescript
  - javascript
  - python
frameworks: []
tags:
  - quality
  - readability
  - maintainability
  - best-practices
severity: recommended
applies_when:
  - writing new code
  - reviewing code
  - refactoring
version: "1.0"
---

# Code Quality Standards

## Summary

Write code that is easy to read, understand, and maintain. Prioritize clarity over cleverness.

## Guidelines

### 1. Keep Functions Focused

```typescript
// ✅ Good - single responsibility
async function validateUser(user: UserInput): Promise<ValidationResult> {
  const errors: string[] = [];
  
  if (!isValidEmail(user.email)) {
    errors.push('Invalid email format');
  }
  
  if (user.password.length < 8) {
    errors.push('Password too short');
  }
  
  return { valid: errors.length === 0, errors };
}

async function createUser(input: UserInput): Promise<User> {
  const validation = await validateUser(input);
  if (!validation.valid) {
    throw new ValidationError(validation.errors);
  }
  
  return await db.users.create(input);
}
```

```typescript
// ❌ Bad - doing too much
async function createUser(input: UserInput): Promise<User> {
  // Validation mixed with creation
  if (!isValidEmail(input.email)) throw new Error('Bad email');
  if (input.password.length < 8) throw new Error('Bad password');
  const hash = await bcrypt.hash(input.password, 10);
  const user = await db.users.create({ ...input, password: hash });
  await sendWelcomeEmail(user.email);
  await analytics.track('user_created', user.id);
  return user;
}
```

### 2. Use Meaningful Names

```typescript
// ✅ Good - intent is clear
const activeUsers = users.filter(user => user.isActive);
const daysSinceLastLogin = differenceInDays(now, user.lastLoginAt);

function calculateOrderTotal(items: CartItem[]): Money {
  return items.reduce((total, item) => total.add(item.price), Money.zero());
}
```

```typescript
// ❌ Bad - cryptic names
const a = users.filter(u => u.a);
const d = diff(n, u.l);

function calc(i: any[]): number {
  return i.reduce((t, x) => t + x.p, 0);
}
```

### 3. Avoid Deep Nesting

```typescript
// ✅ Good - early returns flatten logic
async function processOrder(orderId: string): Promise<void> {
  const order = await getOrder(orderId);
  if (!order) {
    throw new NotFoundError('Order not found');
  }
  
  if (order.status !== 'pending') {
    throw new InvalidStateError('Order already processed');
  }
  
  if (!order.paymentVerified) {
    throw new PaymentError('Payment not verified');
  }
  
  await fulfillOrder(order);
}
```

```typescript
// ❌ Bad - deeply nested
async function processOrder(orderId: string): Promise<void> {
  const order = await getOrder(orderId);
  if (order) {
    if (order.status === 'pending') {
      if (order.paymentVerified) {
        await fulfillOrder(order);
      } else {
        throw new PaymentError('Payment not verified');
      }
    } else {
      throw new InvalidStateError('Order already processed');
    }
  } else {
    throw new NotFoundError('Order not found');
  }
}
```

### 4. Prefer Composition Over Inheritance

```typescript
// ✅ Good - composition
interface Logger {
  log(message: string): void;
}

interface Metrics {
  increment(metric: string): void;
}

class OrderService {
  constructor(
    private readonly db: Database,
    private readonly logger: Logger,
    private readonly metrics: Metrics,
  ) {}
  
  async createOrder(input: OrderInput): Promise<Order> {
    this.logger.log('Creating order');
    const order = await this.db.orders.create(input);
    this.metrics.increment('orders_created');
    return order;
  }
}
```

### 5. Write Self-Documenting Code

```typescript
// ✅ Good - code explains itself
const isEligibleForDiscount = 
  customer.membershipYears >= 2 && 
  order.total.isGreaterThan(Money.fromDollars(100));

if (isEligibleForDiscount) {
  order.applyDiscount(LOYALTY_DISCOUNT_PERCENT);
}
```

```typescript
// ❌ Bad - magic numbers and unclear logic
if (c.y >= 2 && o.t > 100) {
  o.t = o.t * 0.9;  // What is 0.9? Why 2? Why 100?
}
```

### 6. Handle Edge Cases Explicitly

```typescript
// ✅ Good - edge cases handled
function divide(a: number, b: number): number {
  if (b === 0) {
    throw new DivisionByZeroError();
  }
  return a / b;
}

function getFirstElement<T>(array: T[]): T | undefined {
  return array[0];  // Return type makes emptiness explicit
}
```

## Metrics

- Functions should be under 50 lines
- Cyclomatic complexity under 10
- Nesting depth under 4 levels
- File size under 500 lines (prefer smaller)

## Related

- [Testing Guidelines](./testing.md)
- [Documentation Standards](./documentation.md)
