---
id: ts-error-handling
title: TypeScript Error Handling
category: languages/typescript
subcategory: patterns
languages:
  - typescript
  - javascript
frameworks: []
tags:
  - error
  - exception
  - result
  - type-safety
severity: required
applies_when:
  - handling external API responses
  - parsing user input
  - database operations
  - file system operations
version: "1.0"
---

# TypeScript Error Handling

## Summary

Use typed error handling with Result types for recoverable errors.
Reserve exceptions for truly exceptional circumstances.

## Guidelines

### 1. Use Result Types for Recoverable Errors

```typescript
// ✅ Good - explicit error handling
type Result<T, E = Error> = 
  | { ok: true; value: T } 
  | { ok: false; error: E };

function parseConfig(raw: string): Result<Config, ParseError> {
  try {
    const parsed = JSON.parse(raw);
    if (!isValidConfig(parsed)) {
      return { ok: false, error: new ParseError("Invalid config structure") };
    }
    return { ok: true, value: parsed };
  } catch (e) {
    return { ok: false, error: new ParseError(e.message) };
  }
}

// Usage - compiler enforces handling
const result = parseConfig(input);
if (!result.ok) {
  logger.error("Config parse failed", result.error);
  return defaultConfig;
}
const config = result.value;  // TypeScript knows this is Config
```

```typescript
// ❌ Bad - hidden failure modes
function parseConfig(raw: string): Config {
  return JSON.parse(raw);  // Throws on invalid JSON
}
```

### 2. Create Domain-Specific Error Classes

```typescript
// ✅ Good - rich error context
class AuthenticationError extends Error {
  constructor(
    message: string,
    public readonly code: AuthErrorCode,
    public readonly userId?: string,
    public readonly attemptCount?: number
  ) {
    super(message);
    this.name = 'AuthenticationError';
  }
}

enum AuthErrorCode {
  INVALID_CREDENTIALS = 'INVALID_CREDENTIALS',
  ACCOUNT_LOCKED = 'ACCOUNT_LOCKED',
  TOKEN_EXPIRED = 'TOKEN_EXPIRED',
}
```

### 3. Never Use `any` in Error Handling

```typescript
// ❌ Bad
try {
  await doSomething();
} catch (e: any) {
  console.log(e.message);  // Runtime error if e is not an Error
}

// ✅ Good
try {
  await doSomething();
} catch (e) {
  if (e instanceof Error) {
    console.log(e.message);
  } else {
    console.log("Unknown error", e);
  }
}
```

### 4. Use Exhaustive Error Handling

```typescript
// ✅ Good - handle all cases
function handleError(error: AuthError | NetworkError | ValidationError): void {
  switch (error.type) {
    case 'auth':
      redirectToLogin();
      break;
    case 'network':
      showRetryDialog();
      break;
    case 'validation':
      highlightFields(error.fields);
      break;
    default:
      // TypeScript error if a case is missing
      const _exhaustive: never = error;
  }
}
```

## Rationale

- **Type safety**: Compiler enforces error handling
- **Explicit**: Callers know exactly what can fail
- **Debuggable**: Rich error context aids troubleshooting
- **Maintainable**: New error types cause compile errors at call sites

## Related

- [Error Codes Standard](./error-codes.md)
- [Logging Guidelines](../general/logging.md)
