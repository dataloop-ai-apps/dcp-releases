---
id: security-input-validation
title: Input Validation
category: security
subcategory: validation
languages:
  - typescript
  - javascript
  - python
frameworks:
  - fastify
  - express
  - django
  - fastapi
tags:
  - security
  - validation
  - input
  - sanitization
  - injection
severity: required
applies_when:
  - accepting user input
  - processing API requests
  - handling file uploads
  - parsing query parameters
version: "1.0"
---

# Input Validation

## Summary

Always validate and sanitize all input at system boundaries. Never trust data from external sources.

## Guidelines

### 1. Validate at the Boundary

```typescript
// ✅ Good - validate at API boundary
const createUserSchema = {
  body: {
    type: 'object',
    required: ['email', 'name'],
    properties: {
      email: { type: 'string', format: 'email', maxLength: 255 },
      name: { type: 'string', minLength: 1, maxLength: 100 },
      age: { type: 'integer', minimum: 0, maximum: 150 },
    },
    additionalProperties: false,  // Reject unknown fields
  },
};

app.post('/users', { schema: createUserSchema }, async (req, reply) => {
  // req.body is guaranteed to match schema
  const user = await createUser(req.body);
  return user;
});
```

### 2. Use Schema Validation Libraries

```typescript
// ✅ Good - Zod for runtime validation
import { z } from 'zod';

const UserInput = z.object({
  email: z.string().email().max(255),
  name: z.string().min(1).max(100),
  age: z.number().int().min(0).max(150).optional(),
});

type UserInput = z.infer<typeof UserInput>;

function processUser(input: unknown): UserInput {
  return UserInput.parse(input);  // Throws ZodError if invalid
}
```

```python
# ✅ Good - Pydantic for Python
from pydantic import BaseModel, EmailStr, constr, conint

class UserInput(BaseModel):
    email: EmailStr
    name: constr(min_length=1, max_length=100)
    age: conint(ge=0, le=150) | None = None
    
    class Config:
        extra = "forbid"  # Reject unknown fields
```

### 3. Sanitize for Output Context

```typescript
// ✅ Good - context-aware escaping
function renderComment(comment: string): string {
  // Escape HTML entities for browser display
  return escapeHtml(comment);
}

function buildQuery(userInput: string): string {
  // Use parameterized queries, never string concatenation
  return db.query('SELECT * FROM users WHERE name = $1', [userInput]);
}
```

### 4. Limit Input Size

```typescript
// ✅ Good - prevent DoS via large inputs
const uploadSchema = {
  body: {
    type: 'object',
    properties: {
      content: { type: 'string', maxLength: 1_000_000 },  // 1MB max
    },
  },
};

// Also limit at infrastructure level
app.register(require('@fastify/multipart'), {
  limits: {
    fileSize: 10 * 1024 * 1024,  // 10MB
    files: 5,
  },
});
```

### 5. Validate File Uploads

```typescript
// ✅ Good - validate file type and content
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif'];
const MAX_SIZE = 5 * 1024 * 1024;  // 5MB

async function validateUpload(file: MultipartFile): Promise<void> {
  // Check declared MIME type
  if (!ALLOWED_TYPES.includes(file.mimetype)) {
    throw new ValidationError('Invalid file type');
  }
  
  // Verify actual content matches (magic bytes)
  const buffer = await file.toBuffer();
  const detected = await fileType.fromBuffer(buffer);
  
  if (!detected || !ALLOWED_TYPES.includes(detected.mime)) {
    throw new ValidationError('File content does not match declared type');
  }
  
  if (buffer.length > MAX_SIZE) {
    throw new ValidationError('File too large');
  }
}
```

## Anti-Patterns to Avoid

```typescript
// ❌ Bad - SQL injection vulnerability
const query = `SELECT * FROM users WHERE name = '${userName}'`;

// ❌ Bad - trusting client-provided type
const file = req.file;
if (file.mimetype === 'image/jpeg') {  // Client can lie
  saveImage(file);
}

// ❌ Bad - no length limits
const comment = req.body.comment;  // Could be gigabytes
```

## Rationale

- **Defense in depth**: Input validation is the first line of defense
- **Fail fast**: Invalid input should be rejected immediately
- **Predictable**: Validated data has known shape and constraints
- **Secure**: Prevents injection attacks and data corruption

## Related

- [SQL Injection Prevention](./sql-injection.md)
- [XSS Prevention](./xss-prevention.md)
