---
id: py-type-hints
title: Python Type Hints
category: languages/python
subcategory: style
languages:
  - python
frameworks: []
tags:
  - types
  - hints
  - mypy
  - static-analysis
severity: recommended
applies_when:
  - writing function signatures
  - defining classes
  - working with complex data structures
version: "1.0"
---

# Python Type Hints

## Summary

Use type hints consistently to improve code clarity and enable static analysis.

## Guidelines

### 1. Always Type Function Signatures

```python
# ✅ Good - clear input/output types
def calculate_total(items: list[CartItem], discount: Decimal = Decimal("0")) -> Money:
    subtotal = sum(item.price for item in items)
    return Money(subtotal * (1 - discount))

async def get_user(user_id: int) -> User | None:
    return await db.users.get(user_id)
```

```python
# ❌ Bad - no type information
def calculate_total(items, discount=0):
    subtotal = sum(item.price for item in items)
    return subtotal * (1 - discount)
```

### 2. Use Modern Type Syntax (Python 3.10+)

```python
# ✅ Good - modern union syntax
def process(value: str | int | None) -> dict[str, Any]:
    ...

# ✅ Good - generic collections (no typing import needed)
def filter_items(items: list[Item]) -> list[Item]:
    return [item for item in items if item.is_active]
```

```python
# Older style (still valid but prefer modern)
from typing import Union, List, Optional

def process(value: Union[str, int, None]) -> Dict[str, Any]:
    ...
```

### 3. Type Class Attributes

```python
# ✅ Good - typed dataclass
from dataclasses import dataclass
from datetime import datetime

@dataclass
class User:
    id: int
    email: str
    created_at: datetime
    is_active: bool = True
    roles: list[str] = field(default_factory=list)
```

```python
# ✅ Good - typed Pydantic model
from pydantic import BaseModel

class UserCreate(BaseModel):
    email: str
    password: str
    name: str | None = None
```

### 4. Use TypeVar for Generics

```python
# ✅ Good - generic function
from typing import TypeVar

T = TypeVar('T')

def first_or_default(items: list[T], default: T) -> T:
    return items[0] if items else default

# Type is preserved
user = first_or_default(users, default_user)  # type: User
```

### 5. Use Protocol for Structural Typing

```python
# ✅ Good - protocol defines interface
from typing import Protocol

class Serializable(Protocol):
    def to_dict(self) -> dict[str, Any]: ...

def save_to_json(obj: Serializable, path: Path) -> None:
    data = obj.to_dict()
    path.write_text(json.dumps(data))

# Any class with to_dict() method works
save_to_json(user, Path("user.json"))
save_to_json(order, Path("order.json"))
```

### 6. Annotate Complex Types with TypeAlias

```python
# ✅ Good - named type aliases
from typing import TypeAlias

UserId: TypeAlias = int
JsonDict: TypeAlias = dict[str, Any]
Handler: TypeAlias = Callable[[Request], Awaitable[Response]]

def register_handler(path: str, handler: Handler) -> None:
    ...
```

## Configuration

```toml
# pyproject.toml - mypy configuration
[tool.mypy]
python_version = "3.10"
strict = true
warn_return_any = true
warn_unused_ignores = true
```

## Related

- [Python Code Style](./style.md)
- [Pydantic Usage](./pydantic.md)
