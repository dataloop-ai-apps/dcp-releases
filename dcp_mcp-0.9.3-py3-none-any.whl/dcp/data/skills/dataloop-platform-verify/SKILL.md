---
name: dataloop-platform-verify
description: Verify implementations, check state, reproduce bugs, or validate test results on the Dataloop platform using browser MCP tools. Use when you need to verify behavior on Dataloop, check platform state, inspect UI, or validate deployed changes.
---

# Dataloop Platform Verification

Use browser MCP tools to interact with the Dataloop platform for verification, debugging, or validation.

**Primary MCP**: `user-playwright` — launches an external Chromium browser with full Playwright API (`browser_run_code`, `browser_evaluate`, `browser_wait_for`). Preferred for cookie injection and UI testing.

**Fallback MCP**: `cursor-ide-browser` — the built-in Cursor browser. Supports navigation, snapshots, clicks, and typing but lacks `evaluate`/`run_code`. Use when Playwright MCP is unavailable.

## URLs

| Environment | URL |
|---|---|
| Production / RC | `https://rc-con.dataloop.ai/projects` |
| Local dev | `https://local.dataloop.ai:8443/projects` |

## Credentials

Read from environment variables or `.env` / `.env.local` in the workspace root:

```
DATALOOP_USERNAME=...
DATALOOP_PASSWORD=...
DATALOOP_ENVIRONMENT=rc   # optional, defaults to 'rc'
```

If not set, ask the user for credentials before proceeding.

---

## Authentication Flow

When you need to open any Dataloop UI page, follow these steps in order:

### 1. Get Auth Tokens via SDK

Run this shell command to extract the JWT and refresh token:

```bash
python -c "
import os, dtlpy as dl
env = os.environ.get('DATALOOP_ENVIRONMENT', 'rc')
dl.setenv(env)
dl.login_m2m(os.environ.get('DATALOOP_USERNAME'), os.environ.get('DATALOOP_PASSWORD'))
jwt = dl.token()
refresh = dl.client_api.environments[dl.environment()].get('refresh_token', '')
print(f'JWT={jwt}')
print(f'REFRESH={refresh}')
"
```

Parse the two values from the output: `JWT` and `REFRESH`.

### 2. Navigate to the Target URL

```
browser_navigate → { "url": "<target_url>" }
```

### 3. Handle Certificate Errors (local dev only)

After navigating to `local.dataloop.ai`, take a snapshot:

```
browser_snapshot
```

If the page shows "Your connection is not private", "NET::ERR_CERT", or any certificate warning:

**Type "thisisunsafe"** — one letter at a time using `browser_press_key`:

```
browser_press_key → { "key": "t" }
browser_press_key → { "key": "h" }
browser_press_key → { "key": "i" }
browser_press_key → { "key": "s" }
browser_press_key → { "key": "i" }
browser_press_key → { "key": "s" }
browser_press_key → { "key": "u" }
browser_press_key → { "key": "n" }
browser_press_key → { "key": "s" }
browser_press_key → { "key": "a" }
browser_press_key → { "key": "f" }
browser_press_key → { "key": "e" }
```

Do NOT use `browser_type` or `browser_fill` — the bypass only works with raw key presses (no input field to target).

Wait 2-3 seconds, then snapshot again to confirm the page loaded.

### 4. Inject Authentication Cookies

The Dataloop UI requires two cookies: `JWT` and `refresh_token`.

**Using user-playwright (preferred):**

Use `browser_run_code` to inject cookies via Playwright's context API (camelCase for JS API):

```
browser_run_code → {
  "code": "async (page) => { const ctx = page.context(); await ctx.addCookies([{ name: 'JWT', value: '<JWT_VALUE>', domain: '.dataloop.ai', path: '/', httpOnly: true, secure: true, sameSite: 'Lax' }, { name: 'refresh_token', value: '<REFRESH_VALUE>', domain: '.dataloop.ai', path: '/', httpOnly: true, secure: true, sameSite: 'Lax' }]); }"
}
```

**Using cursor-ide-browser (no `evaluate` tool):**

Navigate to `javascript:` URLs to set cookies (`httpOnly` cannot be set via JS, but the UI still accepts them):

```
browser_navigate → { "url": "javascript:void(document.cookie='JWT=<JWT_VALUE>;path=/;domain=.dataloop.ai;secure;samesite=lax')" }
browser_navigate → { "url": "javascript:void(document.cookie='refresh_token=<REFRESH_VALUE>;path=/;domain=.dataloop.ai;secure;samesite=lax')" }
```

If `javascript:` navigation is blocked, fall back to manual login (step 6).

### 5. Reload and Verify

Navigate to the target URL again to reload with authentication:

```
browser_navigate → { "url": "<target_url>" }
```

Take a snapshot and confirm you see the Dataloop platform UI (projects list, etc.) and NOT a login page.

### 6. Fallback — Auth0 Manual Login

If cookie injection fails (still on login page after reload):

1. Use `browser_snapshot` to find the email and password input `ref` attributes
2. Use `browser_type` with the `ref` to fill credentials — do NOT use `browser_fill_form` (Auth0 inputs don't support it)
3. Click the submit button via `browser_click` with `ref`
4. Wait for redirect back to the app

```
browser_snapshot   → find email input ref
browser_type       → { "ref": "<email_ref>", "text": "<DATALOOP_USERNAME>" }
browser_type       → { "ref": "<password_ref>", "text": "<DATALOOP_PASSWORD>" }
browser_click      → { "ref": "<submit_ref>" }
browser_wait_for   → app loaded (e.g. text "My Projects" or "CloudOps")
```

---

## UI Testing Patterns

After authentication, use these patterns for verifying platform behavior.

### Getting Page Structure

```
browser_snapshot → returns accessibility tree with element refs
```

The snapshot returns a YAML accessibility tree. Each interactive element has a `ref` attribute (e.g. `ref=e385`) used for subsequent interactions.

**Refs are ephemeral** — they change on page navigation or DOM updates. Always take a fresh `browser_snapshot` before interacting after navigation or significant state changes.

### Interacting with Elements

```
browser_click         → click by ref
browser_type          → type text into input by ref (appends)
browser_fill_form     → clear and replace input value
browser_press_key     → keyboard shortcuts (Escape, Enter, Tab)
browser_select_option → dropdown selection
```

### Capturing Evidence

```
browser_take_screenshot  → PNG screenshot of viewport
browser_snapshot         → DOM structure for assertions
browser_console_messages → check for JS errors
```

### Wait Strategy

Use short incremental waits with snapshot checks — not one long wait:

```
browser_wait_for time=3000
browser_snapshot  → check if ready
browser_wait_for time=3000  → if not ready, wait again
```

### Testing Filters

1. Type in search input → verify table filters
2. Click Clear Filters → verify table resets
3. Open dropdown filters → select options → verify results

### Testing Side Panels

1. Click a table row → verify side panel opens with details
2. Click 3-dot menu → verify action menu items
3. Click away or same row → verify panel closes

---

## Gotchas

- `browser_wait_for` `time` param is in **seconds** (not ms) for the Playwright MCP
- Auth0 login forms don't work with `browser_fill_form` — use `browser_type` with `ref` directly
- If the page shows "Loading, please wait..." for too long, the dev server may need a restart
- `browser_evaluate` may abort on complex expressions — prefer `browser_snapshot` for DOM inspection
- Screenshots from Playwright MCP are saved to `.playwright-mcp/` (gitignored)

---

## When to Use

- **Developer mode**: Verify implementation correctness after coding, check impact of code changes
- **Tester mode**: Validate test results and inspect platform state
- **Debugger mode**: Reproduce bugs and investigate live issues
