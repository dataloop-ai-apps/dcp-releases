"""Export Figma design context (screenshots, structure, tokens) to local files.

Usage:
    python export_figma.py --file-key KEY --node-id ID [--output DIR] [--scale 2] [--depth 2]

Requires:
    - FIGMA_API_KEY environment variable (Figma Personal Access Token)
    - requests package (pip install requests)
"""

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    import requests
except ImportError:
    print("ERROR: 'requests' package not found. Install it: pip install requests")
    sys.exit(1)

API_BASE = "https://api.figma.com/v1"
MAX_RETRIES = 3
RETRY_DELAY = 5


def get_headers():
    token = os.environ.get("FIGMA_API_KEY", "")
    if not token:
        for env_file in [".env", ".env.local"]:
            if os.path.exists(env_file):
                with open(env_file) as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("FIGMA_API_KEY="):
                            token = line.split("=", 1)[1].strip().strip("'\"")
                            break
            if token:
                break
    if not token:
        print("ERROR: FIGMA_API_KEY not found in environment or .env files")
        sys.exit(1)
    return {"X-Figma-Token": token}


def api_get(endpoint, params=None, headers=None):
    """GET with retry on 429 rate limit."""
    url = f"{API_BASE}{endpoint}"
    for attempt in range(MAX_RETRIES):
        resp = requests.get(url, params=params, headers=headers, timeout=30)
        if resp.status_code == 429:
            wait = RETRY_DELAY * (attempt + 1)
            print(f"  Rate limited, waiting {wait}s...")
            time.sleep(wait)
            continue
        if resp.status_code == 403:
            print(f"  403 Forbidden: {endpoint} - check token permissions")
            return None
        if resp.status_code == 404:
            print(f"  404 Not Found: {endpoint}")
            return None
        resp.raise_for_status()
        return resp.json()
    print(f"  Failed after {MAX_RETRIES} retries: {endpoint}")
    return None


def slugify(name):
    """Convert a section name to a filename-safe slug."""
    s = name.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    return s.strip("-")


def fetch_node_tree(file_key, node_id, depth, headers):
    """Fetch the node tree for a given page/frame."""
    print(f"Fetching node tree for {node_id} (depth={depth})...")
    data = api_get(
        f"/files/{file_key}/nodes",
        params={"ids": node_id, "depth": depth},
        headers=headers,
    )
    if not data:
        return None
    nodes = data.get("nodes", {})
    node_data = nodes.get(node_id, {})
    return node_data.get("document")


def extract_sections(document, depth=1):
    """Extract top-level children as sections."""
    if not document:
        return []
    children = document.get("children", [])
    sections = []
    for i, child in enumerate(children):
        name = child.get("name", f"Section {i + 1}")
        node_id = child.get("id", "")
        node_type = child.get("type", "")
        sections.append({
            "index": i + 1,
            "name": name,
            "node_id": node_id,
            "type": node_type,
            "slug": slugify(name),
            "data": child,
        })
    return sections


def extract_text_nodes(node, texts=None):
    """Recursively extract TEXT node content."""
    if texts is None:
        texts = []
    if node.get("type") == "TEXT":
        chars = node.get("characters", "")
        if chars.strip():
            texts.append(chars.strip())
    for child in node.get("children", []):
        extract_text_nodes(child, texts)
    return texts


def extract_component_refs(node, refs=None):
    """Recursively find INSTANCE nodes (component usage)."""
    if refs is None:
        refs = []
    if node.get("type") == "INSTANCE":
        name = node.get("name", "Unknown")
        component_id = node.get("componentId", "")
        refs.append({"name": name, "componentId": component_id})
    for child in node.get("children", []):
        extract_component_refs(child, refs)
    return refs


def describe_layout(node):
    """Extract auto-layout info from a node."""
    layout = node.get("layoutMode")
    if not layout:
        return None
    info = {
        "direction": layout,
        "padding": {
            "top": node.get("paddingTop", 0),
            "right": node.get("paddingRight", 0),
            "bottom": node.get("paddingBottom", 0),
            "left": node.get("paddingLeft", 0),
        },
        "gap": node.get("itemSpacing", 0),
        "alignment": node.get("primaryAxisAlignItems", ""),
        "counterAlignment": node.get("counterAxisAlignItems", ""),
    }
    return info


def download_screenshots(file_key, sections, output_dir, scale, headers):
    """Download screenshots for all sections."""
    screenshots_dir = output_dir / "screenshots"
    screenshots_dir.mkdir(parents=True, exist_ok=True)

    node_ids = [s["node_id"] for s in sections]
    if not node_ids:
        print("  No sections to screenshot")
        return

    ids_str = ",".join(node_ids)
    print(f"Requesting screenshots for {len(node_ids)} sections...")
    data = api_get(
        f"/images/{file_key}",
        params={"ids": ids_str, "format": "png", "scale": str(scale)},
        headers=headers,
    )

    if not data:
        print("  Failed to get image URLs")
        return

    if data.get("err"):
        print(f"  Image API error: {data['err']}")
        return

    images = data.get("images", {})
    print(f"  Got {len(images)} image URLs")

    for section in sections:
        url = images.get(section["node_id"])
        if not url:
            print(f"  SKIP {section['name']} ({section['node_id']}) - no URL returned")
            continue

        filename = f"{section['index']:02d}-{section['slug']}.png"
        section["screenshot"] = f"screenshots/{filename}"
        filepath = screenshots_dir / filename

        print(f"  Downloading {filename}...")
        try:
            img_resp = requests.get(url, timeout=60)
            img_resp.raise_for_status()
            with open(filepath, "wb") as f:
                f.write(img_resp.content)
            print(f"  Saved {filepath} ({len(img_resp.content)} bytes)")
        except Exception as e:
            print(f"  Failed to download {filename}: {e}")


def fetch_variables(file_key, headers):
    """Fetch design variables/tokens (enterprise feature, may 403)."""
    print("Fetching design variables...")
    data = api_get(f"/files/{file_key}/variables/local", headers=headers)
    if not data:
        print("  Variables not available (may require enterprise plan)")
        return None
    return data


def generate_overview(document, sections, variables, args, output_dir):
    """Generate overview.md summarizing the design export."""
    page_name = document.get("name", "Untitled") if document else "Untitled"
    figma_url = f"https://www.figma.com/design/{args.file_key}?node-id={args.node_id.replace(':', '-')}"
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    lines = [
        f"# {page_name} — Figma Design Export\n",
        f"**Source**: {figma_url}",
        f"**Exported**: {now}",
        f"**File Key**: {args.file_key}",
        f"**Node ID**: {args.node_id}\n",
    ]

    # Section table
    lines.append("## Sections\n")
    lines.append("| # | Section | Screenshot | Node ID | Type |")
    lines.append("|---|---------|------------|---------|------|")
    for s in sections:
        screenshot = s.get("screenshot", "—")
        if screenshot != "—":
            screenshot = f"[screenshot]({screenshot})"
        lines.append(
            f"| {s['index']} | {s['name']} | {screenshot} | `{s['node_id']}` | {s['type']} |"
        )

    # Per-section details
    for s in sections:
        lines.append(f"\n## {s['index']}. {s['name']}\n")

        layout = describe_layout(s["data"])
        if layout:
            lines.append("### Layout")
            lines.append(f"- Direction: {layout['direction']}")
            p = layout["padding"]
            lines.append(f"- Padding: top={p['top']} right={p['right']} bottom={p['bottom']} left={p['left']}")
            lines.append(f"- Gap: {layout['gap']}")
            if layout["alignment"]:
                lines.append(f"- Alignment: {layout['alignment']}")
            lines.append("")

        texts = extract_text_nodes(s["data"])
        if texts:
            lines.append("### Text Content")
            for t in texts[:20]:
                display = t[:80] + "..." if len(t) > 80 else t
                lines.append(f"- {display}")
            if len(texts) > 20:
                lines.append(f"- ... and {len(texts) - 20} more text nodes")
            lines.append("")

        components = extract_component_refs(s["data"])
        if components:
            lines.append("### Component Instances")
            seen = set()
            for c in components:
                if c["name"] not in seen:
                    lines.append(f"- {c['name']}")
                    seen.add(c["name"])
            lines.append("")

    # Tokens summary
    if variables:
        lines.append("\n## Design Tokens\n")
        meta = variables.get("meta", {})
        var_collections = meta.get("variableCollections", {})
        var_defs = meta.get("variables", {})
        lines.append(f"- Collections: {len(var_collections)}")
        lines.append(f"- Variables: {len(var_defs)}")
        lines.append("- See `tokens.json` for full details")

    overview_path = output_dir / "overview.md"
    with open(overview_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Generated {overview_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Export Figma design context to local files"
    )
    parser.add_argument("--file-key", required=True, help="Figma file key")
    parser.add_argument("--node-id", required=True, help="Page/frame node ID (e.g. 37:33477)")
    parser.add_argument("--output", default=".plans/design", help="Output directory")
    parser.add_argument("--scale", type=int, default=2, help="Screenshot scale (1-4)")
    parser.add_argument("--depth", type=int, default=2, help="Node tree depth")
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    headers = get_headers()

    # 1. Fetch node tree
    document = fetch_node_tree(args.file_key, args.node_id, args.depth, headers)
    if not document:
        print("ERROR: Could not fetch node tree. Check file key and node ID.")
        sys.exit(1)

    # 2. Extract sections
    sections = extract_sections(document)
    print(f"Found {len(sections)} top-level sections:")
    for s in sections:
        print(f"  {s['index']:02d}. {s['name']} ({s['node_id']}) [{s['type']}]")

    # 3. Download screenshots
    download_screenshots(args.file_key, sections, output_dir, args.scale, headers)

    # 4. Fetch design variables
    variables = fetch_variables(args.file_key, headers)
    if variables:
        tokens_path = output_dir / "tokens.json"
        with open(tokens_path, "w", encoding="utf-8") as f:
            json.dump(variables, f, indent=2)
        print(f"Saved {tokens_path}")

    # 5. Generate overview
    generate_overview(document, sections, variables, args, output_dir)

    print(f"\nExport complete -> {output_dir}/")


if __name__ == "__main__":
    main()
