---
name: figma-design-export
description: Export Figma design context (screenshots, page structure, tokens) to .plans/design/ using the Figma REST API. Use when the task involves implementing a UI design from Figma, or when a Figma URL is found in the task description or Jira ticket.
---

# Figma Design Export

Export design context from a Figma file to local files that the developer agent
can reference during implementation. No live Figma dependency after export.

## When to Use

- Task context contains a Figma URL (`figma.com/design/...`)
- Task involves implementing a new UI page, component, or dialog from a design
- DCP memory indicates the repo is a frontend app with Figma designs

## Prerequisites

- `FIGMA_API_KEY` environment variable must be set (Figma Personal Access Token)
- If not set, check `.env` / `.env.local` in the workspace root
- If still not found, skip the export and note it in the plan:
  "Design export skipped — no FIGMA_API_KEY. Developer should reference Figma manually."
- Python `requests` package must be available. Install if needed: `pip install requests`

## Step 1: Parse the Figma URL

Extract from the URL:
- `fileKey`: the file identifier
- `nodeId`: the page or frame node ID (convert `-` to `:` in the URL's `node-id` param)

URL formats:
- `figma.com/design/:fileKey/:fileName?node-id=:nodeId`
- `figma.com/design/:fileKey/branch/:branchKey/:fileName` → use branchKey as fileKey

Examples:
- `https://www.figma.com/design/HNZlIBqOdZ7Pp0pEcROIEk/My-Page?node-id=37-33477`
  → fileKey=`HNZlIBqOdZ7Pp0pEcROIEk`, nodeId=`37:33477`

## Step 2: Run the Export Script

```bash
python .cursor/skills/figma-design-export/scripts/export_figma.py \
  --file-key <fileKey> \
  --node-id <nodeId> \
  --output .plans/design
```

The script:
1. Fetches the page/frame structure from the Figma API (top-level children)
2. Downloads a screenshot of each section as PNG
3. Fetches design variables/tokens (if available)
4. Generates `overview.md` summarizing the page structure
5. Saves `tokens.json` with design variables

If the script fails (missing dependency, API error), check the error output and fix.
Common issues:
- `requests` not installed → `pip install requests`
- 403 Forbidden → token expired or lacks file access
- 429 Rate Limited → wait and retry

## Step 3: Enrich with Figma MCP (Optional)

If the Figma MCP (`user-Figma`) is available in the workspace, use it for richer
context that the REST API alone can't provide:

For each top-level section identified in `overview.md`:

1. Call `get_design_context` with `nodeId` and `fileKey` to get:
   - Generated reference code (React/Vue/etc. based on project stack)
   - Component mappings (Code Connect)
   - Layout hints and design annotations

2. Save each response to `.plans/design/code-context/{section-name}.md`

3. Optionally call `get_variable_defs` for per-node design tokens

Skip this step if the Figma MCP is not configured or returns errors.

## Step 4: Review and Summarize

1. Read `.plans/design/overview.md` — verify it has the page structure
2. Check `.plans/design/screenshots/` — verify PNGs are present and readable
3. Add any manual notes about the design intent, interactions, or edge cases
4. If implementing, hand off to developer mode with a reference to `.plans/design/`

## Output Structure

```
.plans/design/
  overview.md              # Page structure, section list, component descriptions
  screenshots/
    01-main-view.png       # Screenshot per top-level section
    02-create-dialog.png
    03-edit-panel.png
    ...
  tokens.json              # Design variables (colors, spacing, typography) if available
  code-context/            # Optional: Figma MCP code references
    main-view.md
    create-dialog.md
    ...
```

## Overview Template

The export script generates `overview.md` using this structure:

```markdown
# {Page Name} — Figma Design Export

**Source**: {figma_url}
**Exported**: {date}
**File Key**: {fileKey}
**Node ID**: {nodeId}

## Sections

| # | Section | Screenshot | Node ID |
|---|---------|------------|---------|
| 1 | {name}  | screenshots/{file}.png | {id} |

## {Section Name}

### Layout
- {layout direction, padding, gaps from auto-layout}

### Key Elements
- {text nodes, buttons, inputs, tables identified}

### Component Instances
- {design system components used}

## Design Tokens
- {summary of colors, typography, spacing from tokens.json}
```
