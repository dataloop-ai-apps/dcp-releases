"""ChromaDB client for guidelines storage and retrieval."""

from pathlib import Path
from typing import Any

import chromadb
from chromadb.config import Settings

from dcp.schemas.guidelines import Guideline, GuidelineMetadata, SearchResult


class GuidelinesClient:
    """Client for interacting with the guidelines vector store.
    
    Uses ChromaDB's default embedding model (all-MiniLM-L6-v2) for consistency
    between indexing and querying. No external API required.
    """
    
    COLLECTION_NAME = "guidelines"
    
    def __init__(
        self,
        persist_directory: str | Path | None = None,
    ):
        """Initialize the guidelines client.
        
        Args:
            persist_directory: Directory for persistent storage. If None, uses in-memory.
        """
        self.persist_directory = Path(persist_directory) if persist_directory else None
        self._client: chromadb.Client | None = None
        self._collection: chromadb.Collection | None = None
    
    @property
    def client(self) -> chromadb.Client:
        """Get or create the ChromaDB client."""
        if self._client is None:
            if self.persist_directory:
                self._client = chromadb.PersistentClient(
                    path=str(self.persist_directory),
                    settings=Settings(anonymized_telemetry=False)
                )
            else:
                self._client = chromadb.Client(
                    settings=Settings(anonymized_telemetry=False)
                )
        return self._client
    
    @property
    def collection(self) -> chromadb.Collection:
        """Get or create the guidelines collection.
        
        Uses ChromaDB's default embedding function (all-MiniLM-L6-v2)
        which runs locally without requiring any API keys.
        """
        if self._collection is None:
            # Use default embedding function (all-MiniLM-L6-v2)
            # This ensures consistency between indexing and querying
            self._collection = self.client.get_or_create_collection(
                name=self.COLLECTION_NAME,
                metadata={"description": "Coding guidelines and best practices"}
            )
        
        return self._collection
    
    def _build_metadata(self, guideline: Guideline) -> dict:
        """Build ChromaDB metadata dict from a guideline.
        
        Languages and frameworks are stored both as comma-separated strings
        (for display) and as individual boolean fields (for filtering).
        """
        metadata = {
            "id": guideline.metadata.id,
            "title": guideline.metadata.title,
            "category": guideline.metadata.category,
            "subcategory": guideline.metadata.subcategory or "",
            "languages": ",".join(guideline.metadata.languages),
            "frameworks": ",".join(guideline.metadata.frameworks),
            "tags": ",".join(guideline.metadata.tags),
            "severity": guideline.metadata.severity,
        }
        
        # Add individual language fields for filtering (ChromaDB doesn't support $contains)
        for lang in guideline.metadata.languages:
            metadata[f"lang_{lang.lower()}"] = "true"
        
        # Add individual framework fields for filtering
        for fw in guideline.metadata.frameworks:
            metadata[f"fw_{fw.lower()}"] = "true"
        
        return metadata
    
    def add_guideline(self, guideline: Guideline) -> None:
        """Add a guideline to the collection."""
        metadata = self._build_metadata(guideline)
        
        # Create searchable text
        searchable_text = f"{guideline.metadata.title}\n\n{guideline.summary or ''}\n\n{guideline.content}"
        
        self.collection.upsert(
            ids=[guideline.metadata.id],
            documents=[searchable_text],
            metadatas=[metadata],
        )
    
    def add_guidelines(self, guidelines: list[Guideline]) -> None:
        """Add multiple guidelines to the collection."""
        if not guidelines:
            return
        
        ids = []
        documents = []
        metadatas = []
        
        for guideline in guidelines:
            ids.append(guideline.metadata.id)
            
            searchable_text = f"{guideline.metadata.title}\n\n{guideline.summary or ''}\n\n{guideline.content}"
            documents.append(searchable_text)
            
            metadatas.append(self._build_metadata(guideline))
        
        self.collection.upsert(ids=ids, documents=documents, metadatas=metadatas)
    
    def search(
        self,
        query: str,
        languages: list[str] | None = None,
        frameworks: list[str] | None = None,
        categories: list[str] | None = None,
        severity: list[str] | None = None,
        limit: int = 5,
    ) -> list[SearchResult]:
        """Search guidelines with optional filters.
        
        Args:
            query: Search query (natural language or keywords)
            languages: Filter by languages (e.g., ["typescript", "python"])
            frameworks: Filter by frameworks (e.g., ["react", "fastify"])
            categories: Filter by categories (e.g., ["security", "performance"])
            severity: Filter by severity (e.g., ["required", "recommended"])
            limit: Maximum results to return
        
        Returns:
            List of SearchResult objects sorted by relevance
        """
        # Build where clause for filters
        # ChromaDB supports: $eq, $ne, $gt, $gte, $lt, $lte, $in, $nin
        # Languages/frameworks stored as individual boolean fields: lang_python, fw_react, etc.
        where_clauses = []
        
        if languages:
            # Match any of the specified languages using individual lang_* fields
            lang_clauses = []
            for lang in languages:
                lang_clauses.append({f"lang_{lang.lower()}": {"$eq": "true"}})
            if len(lang_clauses) == 1:
                where_clauses.append(lang_clauses[0])
            else:
                where_clauses.append({"$or": lang_clauses})
        
        if frameworks:
            # Match any of the specified frameworks using individual fw_* fields
            framework_clauses = []
            for fw in frameworks:
                framework_clauses.append({f"fw_{fw.lower()}": {"$eq": "true"}})
            if len(framework_clauses) == 1:
                where_clauses.append(framework_clauses[0])
            else:
                where_clauses.append({"$or": framework_clauses})
        
        if categories:
            # Categories use $eq for exact match or $in for multiple
            if len(categories) == 1:
                where_clauses.append({"category": {"$eq": categories[0]}})
            else:
                where_clauses.append({"category": {"$in": categories}})
        
        if severity:
            where_clauses.append({"severity": {"$in": severity}})
        
        # Combine all where clauses
        where = None
        if len(where_clauses) == 1:
            where = where_clauses[0]
        elif len(where_clauses) > 1:
            where = {"$and": where_clauses}
        
        # Perform search
        results = self.collection.query(
            query_texts=[query],
            n_results=limit,
            where=where,
            include=["documents", "metadatas", "distances"],
        )
        
        search_results = []
        
        if results["ids"] and results["ids"][0]:
            for i, doc_id in enumerate(results["ids"][0]):
                metadata = results["metadatas"][0][i] if results["metadatas"] else {}
                document = results["documents"][0][i] if results["documents"] else ""
                distance = results["distances"][0][i] if results["distances"] else 1.0
                
                # Convert distance to relevance score (0-1, higher is better)
                relevance = max(0, 1 - distance)
                
                # Determine match reasons
                match_reasons = ["semantic match"]
                if languages and metadata.get("languages"):
                    for lang in languages:
                        if lang in metadata["languages"]:
                            match_reasons.append(f"language: {lang}")
                if frameworks and metadata.get("frameworks"):
                    for fw in frameworks:
                        if fw in metadata["frameworks"]:
                            match_reasons.append(f"framework: {fw}")
                
                search_results.append(SearchResult(
                    id=doc_id,
                    title=metadata.get("title", ""),
                    content=document,
                    category=metadata.get("category", ""),
                    languages=metadata.get("languages", "").split(",") if metadata.get("languages") else [],
                    frameworks=metadata.get("frameworks", "").split(",") if metadata.get("frameworks") else [],
                    relevance_score=relevance,
                    match_reasons=match_reasons,
                ))
        
        return search_results
    
    def get_by_id(self, guideline_id: str) -> dict[str, Any] | None:
        """Get a guideline by its ID."""
        results = self.collection.get(
            ids=[guideline_id],
            include=["documents", "metadatas"],
        )
        
        if results["ids"]:
            return {
                "id": results["ids"][0],
                "content": results["documents"][0] if results["documents"] else "",
                "metadata": results["metadatas"][0] if results["metadatas"] else {},
            }
        
        return None
    
    def list_categories(self) -> list[dict[str, Any]]:
        """List all guideline categories with counts."""
        # Get all metadata
        results = self.collection.get(include=["metadatas"])
        
        categories: dict[str, int] = {}
        
        if results["metadatas"]:
            for metadata in results["metadatas"]:
                category = metadata.get("category", "uncategorized")
                categories[category] = categories.get(category, 0) + 1
        
        return [
            {"id": cat, "name": cat.replace("/", " > ").title(), "guideline_count": count}
            for cat, count in sorted(categories.items())
        ]
    
    def count(self) -> int:
        """Get the total number of guidelines."""
        return self.collection.count()
