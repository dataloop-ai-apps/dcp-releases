"""Guidelines engine for semantic search."""

from dcp.guidelines.fts_client import GuidelinesClient
from dcp.guidelines.search import (
    search_guidelines,
    get_guideline,
    list_guideline_categories,
)
from dcp.guidelines.ingester import (
    ingest_guidelines,
    get_default_guidelines_dir,
)

__all__ = [
    "GuidelinesClient",
    "search_guidelines",
    "get_guideline",
    "list_guideline_categories",
    "ingest_guidelines",
    "get_default_guidelines_dir",
]
