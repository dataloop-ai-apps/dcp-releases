"""SQLite FTS5 client for guidelines storage and retrieval.

Drop-in replacement for the ChromaDB-based client. Uses SQLite FTS5 for
full-text search with BM25 ranking — zero external dependencies, works
identically on Windows/Mac/Linux.
"""

import sqlite3
from pathlib import Path
from typing import Any

from dcp.schemas.guidelines import Guideline, SearchResult


class GuidelinesClient:
    """Client for interacting with the guidelines FTS5 store.

    Uses SQLite FTS5 with porter stemming for keyword search and BM25 ranking.
    """

    def __init__(self, persist_directory: str | Path | None = None):
        self.persist_directory = Path(persist_directory) if persist_directory else None
        self._conn: sqlite3.Connection | None = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            if self.persist_directory:
                self.persist_directory.mkdir(parents=True, exist_ok=True)
                db_path = self.persist_directory / "guidelines.db"
                self._conn = sqlite3.connect(str(db_path))
            else:
                self._conn = sqlite3.connect(":memory:")
            self._conn.row_factory = sqlite3.Row
            self._ensure_tables()
        return self._conn

    def _ensure_tables(self) -> None:
        c = self.conn
        c.execute("""
            CREATE TABLE IF NOT EXISTS guidelines (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT '',
                subcategory TEXT NOT NULL DEFAULT '',
                languages TEXT NOT NULL DEFAULT '',
                frameworks TEXT NOT NULL DEFAULT '',
                tags TEXT NOT NULL DEFAULT '',
                severity TEXT NOT NULL DEFAULT 'recommended',
                content TEXT NOT NULL DEFAULT ''
            )
        """)
        c.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS guidelines_fts USING fts5(
                id, title, content, tokenize='porter unicode61'
            )
        """)
        c.commit()

    def _build_metadata(self, guideline: Guideline) -> dict:
        return {
            "id": guideline.metadata.id,
            "title": guideline.metadata.title,
            "category": guideline.metadata.category,
            "subcategory": guideline.metadata.subcategory or "",
            "languages": ",".join(guideline.metadata.languages),
            "frameworks": ",".join(guideline.metadata.frameworks),
            "tags": ",".join(guideline.metadata.tags),
            "severity": guideline.metadata.severity,
        }

    def add_guideline(self, guideline: Guideline) -> None:
        meta = self._build_metadata(guideline)
        searchable = f"{guideline.metadata.title}\n\n{guideline.summary or ''}\n\n{guideline.content}"
        self._upsert_one(meta, searchable)

    def add_guidelines(self, guidelines: list[Guideline]) -> None:
        if not guidelines:
            return
        for g in guidelines:
            self.add_guideline(g)

    def _upsert_one(self, meta: dict, searchable_text: str) -> None:
        c = self.conn
        c.execute("DELETE FROM guidelines_fts WHERE id = ?", (meta["id"],))
        c.execute(
            "INSERT OR REPLACE INTO guidelines "
            "(id, title, category, subcategory, languages, frameworks, tags, severity, content) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                meta["id"], meta["title"], meta["category"], meta["subcategory"],
                meta["languages"], meta["frameworks"], meta["tags"],
                meta["severity"], searchable_text,
            ),
        )
        c.execute(
            "INSERT INTO guidelines_fts (id, title, content) VALUES (?, ?, ?)",
            (meta["id"], meta["title"], searchable_text),
        )
        c.commit()

    @staticmethod
    def _fts_escape(query: str) -> str:
        """Escape a user query for FTS5 MATCH safety.

        Wraps each token in double quotes so special chars are treated as
        literals, then joins with implicit AND.
        """
        tokens = query.split()
        if not tokens:
            return '""'
        return " ".join(f'"{t}"' for t in tokens)

    def search(
        self,
        query: str,
        languages: list[str] | None = None,
        frameworks: list[str] | None = None,
        categories: list[str] | None = None,
        severity: list[str] | None = None,
        limit: int = 5,
    ) -> list[SearchResult]:
        safe_query = self._fts_escape(query)
        where_parts: list[str] = []
        params: list[Any] = [safe_query]

        if languages:
            lang_clauses = " OR ".join(
                f"LOWER(g.languages) LIKE ?" for _ in languages
            )
            where_parts.append(f"({lang_clauses})")
            params.extend(f"%{lang.lower()}%" for lang in languages)

        if frameworks:
            fw_clauses = " OR ".join(
                f"LOWER(g.frameworks) LIKE ?" for _ in frameworks
            )
            where_parts.append(f"({fw_clauses})")
            params.extend(f"%{fw.lower()}%" for fw in frameworks)

        if categories:
            placeholders = ",".join("?" for _ in categories)
            where_parts.append(f"g.category IN ({placeholders})")
            params.extend(categories)

        if severity:
            placeholders = ",".join("?" for _ in severity)
            where_parts.append(f"g.severity IN ({placeholders})")
            params.extend(severity)

        where_sql = (" AND " + " AND ".join(where_parts)) if where_parts else ""
        params.append(limit)

        sql = f"""
            SELECT g.*, bm25(guidelines_fts) AS rank
            FROM guidelines_fts fts
            JOIN guidelines g ON g.id = fts.id
            WHERE guidelines_fts MATCH ?
            {where_sql}
            ORDER BY rank
            LIMIT ?
        """

        rows = self.conn.execute(sql, params).fetchall()

        if not rows:
            return []

        worst_rank = min(r["rank"] for r in rows)
        best_rank = max(r["rank"] for r in rows)
        span = best_rank - worst_rank if best_rank != worst_rank else 1.0

        results: list[SearchResult] = []
        for row in rows:
            relevance = 1.0 - (row["rank"] - worst_rank) / span if span else 0.5

            match_reasons = ["keyword match"]
            if languages:
                for lang in languages:
                    if lang.lower() in (row["languages"] or "").lower():
                        match_reasons.append(f"language: {lang}")
            if frameworks:
                for fw in frameworks:
                    if fw.lower() in (row["frameworks"] or "").lower():
                        match_reasons.append(f"framework: {fw}")

            results.append(SearchResult(
                id=row["id"],
                title=row["title"],
                content=row["content"],
                category=row["category"],
                languages=[l for l in (row["languages"] or "").split(",") if l],
                frameworks=[f for f in (row["frameworks"] or "").split(",") if f],
                relevance_score=round(max(0.0, min(1.0, relevance)), 4),
                match_reasons=match_reasons,
            ))

        return results

    def get_by_id(self, guideline_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM guidelines WHERE id = ?", (guideline_id,)
        ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "content": row["content"],
            "metadata": {
                "id": row["id"],
                "title": row["title"],
                "category": row["category"],
                "subcategory": row["subcategory"],
                "languages": row["languages"],
                "frameworks": row["frameworks"],
                "tags": row["tags"],
                "severity": row["severity"],
            },
        }

    def list_categories(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT category, COUNT(*) AS cnt FROM guidelines GROUP BY category ORDER BY category"
        ).fetchall()
        return [
            {"id": r["category"], "name": r["category"].replace("/", " > ").title(), "guideline_count": r["cnt"]}
            for r in rows
        ]

    def count(self) -> int:
        row = self.conn.execute("SELECT COUNT(*) AS cnt FROM guidelines").fetchone()
        return row["cnt"] if row else 0
