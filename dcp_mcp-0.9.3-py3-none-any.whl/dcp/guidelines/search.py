"""High-level search functions for guidelines."""

import os
from pathlib import Path

from dcp.guidelines.fts_client import GuidelinesClient
from dcp.schemas.guidelines import SearchResult


# Global client instance
_client: GuidelinesClient | None = None


def get_default_db_path() -> Path | None:
    """Get the default pre-indexed guidelines database path."""
    # Check environment variable first
    env_path = os.environ.get("GUIDELINES_DB_PATH")
    if env_path and Path(env_path).exists():
        return Path(env_path)
    
    # Check relative to package (for pip install)
    package_dir = Path(__file__).parent.parent.parent.parent
    data_path = package_dir / "data" / "guidelines_db"
    if data_path.exists():
        return data_path
    
    # Check in /app/data (Docker)
    docker_path = Path("/app/data/guidelines_db")
    if docker_path.exists():
        return docker_path
    
    return None


def get_client(persist_directory: str | None = None) -> GuidelinesClient:
    """Get or create the guidelines client.
    
    Uses pre-indexed database if available, falls back to in-memory.
    """
    global _client
    if _client is None:
        db_path = persist_directory or get_default_db_path()
        _client = GuidelinesClient(db_path)
        
        if _client.count() == 0:
            _try_auto_ingest(_client)
    
    return _client


def _try_auto_ingest(client: GuidelinesClient) -> None:
    """Try to auto-ingest guidelines if database is empty."""
    from dcp.guidelines.ingester import get_default_guidelines_dir, discover_guidelines
    
    guidelines_dir = get_default_guidelines_dir()
    if guidelines_dir.exists():
        guidelines = list(discover_guidelines(guidelines_dir))
        if guidelines:
            client.add_guidelines(guidelines)


def search_guidelines(
    query: str,
    languages: list[str] | None = None,
    frameworks: list[str] | None = None,
    categories: list[str] | None = None,
    severity: list[str] | None = None,
    limit: int = 5,
    boost_repo_stack: bool = False,
    tech_stack: dict | None = None,
) -> list[SearchResult]:
    """Search guidelines with filtering and optional repo stack boosting.
    
    Args:
        query: Search query
        languages: Filter by languages
        frameworks: Filter by frameworks
        categories: Filter by categories
        severity: Filter by severity
        limit: Maximum results
        boost_repo_stack: If True, boost results matching repo's tech stack
        tech_stack: Tech stack from repo memory (used if boost_repo_stack is True)
    
    Returns:
        List of SearchResult objects
    """
    client = get_client()
    
    # If boosting by repo stack and we have tech stack info, use it for filtering
    if boost_repo_stack and tech_stack:
        if not languages and tech_stack.get("languages"):
            languages = tech_stack["languages"]
        if not frameworks and tech_stack.get("frameworks"):
            frameworks = tech_stack["frameworks"]
    
    results = client.search(
        query=query,
        languages=languages,
        frameworks=frameworks,
        categories=categories,
        severity=severity,
        limit=limit,
    )
    
    return results


def get_guideline(guideline_id: str) -> dict | None:
    """Get a specific guideline by ID.
    
    Args:
        guideline_id: The guideline ID
    
    Returns:
        Guideline data or None if not found
    """
    client = get_client()
    return client.get_by_id(guideline_id)


def list_guideline_categories() -> list[dict]:
    """List all guideline categories with counts."""
    client = get_client()
    return client.list_categories()
