"""Ingest guidelines from markdown files into ChromaDB."""

import re
from pathlib import Path
from typing import Iterator

from dcp.guidelines.fts_client import GuidelinesClient
from dcp.schemas.guidelines import Guideline, GuidelineMetadata


def parse_frontmatter(content: str) -> tuple[dict, str]:
    """Parse YAML frontmatter from markdown content.
    
    Supports both inline lists [a, b] and YAML-style lists:
      - item1
      - item2
    
    Returns:
        Tuple of (metadata dict, remaining content)
    """
    # Check for frontmatter delimiters
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n(.*)$', content, re.DOTALL)
    
    if not match:
        return {}, content
    
    frontmatter_text = match.group(1)
    body = match.group(2)
    
    # Parse YAML (simple implementation)
    metadata = {}
    current_key = None
    current_list = None
    
    for line in frontmatter_text.split('\n'):
        stripped = line.strip()
        
        # Skip empty lines
        if not stripped:
            continue
        
        # Check if it's a list item (starts with -)
        if stripped.startswith('- '):
            if current_list is not None:
                item = stripped[2:].strip().strip('"\'')
                current_list.append(item)
            continue
        
        # If we were building a list, save it
        if current_list is not None and current_key:
            metadata[current_key] = current_list
            current_list = None
            current_key = None
        
        # Parse key: value
        if ':' in line and not line.startswith(' '):
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()
            
            # Empty value means list follows
            if not value:
                current_key = key
                current_list = []
                continue
            
            # Handle inline lists [item1, item2]
            if value.startswith('[') and value.endswith(']'):
                value = [v.strip().strip('"\'') for v in value[1:-1].split(',') if v.strip()]
            # Handle quoted strings
            elif value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            
            metadata[key] = value
    
    # Don't forget last list if any
    if current_list is not None and current_key:
        metadata[current_key] = current_list
    
    return metadata, body


def extract_summary(content: str) -> str | None:
    """Extract the first paragraph as summary."""
    paragraphs = content.strip().split('\n\n')
    for p in paragraphs:
        p = p.strip()
        # Skip headers and code blocks
        if p and not p.startswith('#') and not p.startswith('```'):
            return p[:500]  # Limit to 500 chars
    return None


def load_guideline_from_file(file_path: Path) -> Guideline | None:
    """Load a guideline from a markdown file.
    
    Expected format:
    ```markdown
    ---
    id: unique-guideline-id
    title: Guideline Title
    category: category/subcategory
    languages: [python, typescript]
    frameworks: [react, fastify]
    severity: required|recommended|optional
    tags: [tag1, tag2]
    ---
    
    # Guideline content...
    ```
    """
    try:
        content = file_path.read_text(encoding='utf-8')
    except Exception:
        return None
    
    metadata, body = parse_frontmatter(content)
    
    # Use filename as fallback ID
    default_id = file_path.stem
    
    # Determine category from directory structure
    rel_path = file_path.relative_to(file_path.parent.parent)
    default_category = str(rel_path.parent).replace('\\', '/')
    
    # Build metadata
    guideline_metadata = GuidelineMetadata(
        id=metadata.get('id', default_id),
        title=metadata.get('title', default_id.replace('-', ' ').title()),
        category=metadata.get('category', default_category),
        subcategory=metadata.get('subcategory'),
        languages=metadata.get('languages', []),
        frameworks=metadata.get('frameworks', []),
        tags=metadata.get('tags', []),
        severity=metadata.get('severity', 'recommended'),
    )
    
    return Guideline(
        metadata=guideline_metadata,
        content=body.strip(),
        summary=extract_summary(body),
    )


def discover_guidelines(directory: Path) -> Iterator[Guideline]:
    """Discover all guideline markdown files in a directory."""
    for md_file in directory.rglob('*.md'):
        guideline = load_guideline_from_file(md_file)
        if guideline:
            yield guideline


def ingest_guidelines(
    directory: str | Path,
    persist_directory: str | Path | None = None,
) -> dict:
    """Ingest all guidelines from a directory into ChromaDB.
    
    Args:
        directory: Directory containing guideline markdown files
        persist_directory: Optional directory for persistent ChromaDB storage
    
    Returns:
        Dict with ingestion results
    """
    directory = Path(directory)
    
    if not directory.exists():
        return {"success": False, "error": f"Directory not found: {directory}"}
    
    client = GuidelinesClient(persist_directory)
    
    guidelines = list(discover_guidelines(directory))
    
    if not guidelines:
        return {"success": False, "error": "No guideline files found"}
    
    client.add_guidelines(guidelines)
    
    # Collect stats
    categories = {}
    languages = set()
    
    for g in guidelines:
        cat = g.metadata.category
        categories[cat] = categories.get(cat, 0) + 1
        languages.update(g.metadata.languages)
    
    return {
        "success": True,
        "total_ingested": len(guidelines),
        "categories": categories,
        "languages": list(languages),
        "guidelines": [
            {"id": g.metadata.id, "title": g.metadata.title, "category": g.metadata.category}
            for g in guidelines
        ],
    }


def get_default_guidelines_dir() -> Path:
    """Get the default guidelines directory (bundled with package)."""
    from dcp.paths import get_guidelines_dir
    return get_guidelines_dir()
