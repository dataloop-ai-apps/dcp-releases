"""Configuration for Cursor chat memory indexing and search."""

import os
import platform
from pathlib import Path


def get_cursor_storage_path() -> Path:
    """Auto-detect the Cursor storage directory based on OS.

    Overridable via CURSOR_STORAGE_PATH env var.
    """
    override = os.environ.get("CURSOR_STORAGE_PATH")
    if override:
        return Path(override)

    system = platform.system()
    if system == "Windows":
        base = os.environ.get("APPDATA", "")
        return Path(base) / "Cursor" / "User"
    elif system == "Darwin":
        return Path.home() / "Library" / "Application Support" / "Cursor" / "User"
    else:
        return Path.home() / ".config" / "Cursor" / "User"


def get_data_dir() -> Path:
    """Get the data directory for chat memory storage.

    Overridable via DCP_CHAT_MEMORY_DIR env var.
    Default: ~/.dcp/chat-memory/
    """
    override = os.environ.get("DCP_CHAT_MEMORY_DIR")
    if override:
        return Path(override)
    return Path.home() / ".dcp" / "chat-memory"


def get_chroma_dir() -> Path:
    """Get the ChromaDB storage directory for chat message embeddings."""
    return get_data_dir() / "chroma"


def get_fts_db_path() -> Path:
    """Get the SQLite FTS5 database path for chat messages."""
    return get_data_dir() / "chat.db"


def get_meta_db_path() -> Path:
    """Get the path to the indexing metadata SQLite database."""
    return get_data_dir() / "index_meta.db"


def get_global_db_path() -> Path:
    """Get the path to Cursor's global state.vscdb."""
    return get_cursor_storage_path() / "globalStorage" / "state.vscdb"


def get_workspace_storage_path() -> Path:
    """Get the path to Cursor's workspaceStorage directory."""
    return get_cursor_storage_path() / "workspaceStorage"
