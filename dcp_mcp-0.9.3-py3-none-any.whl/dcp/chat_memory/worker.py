"""Subprocess worker for ChromaDB operations.

ALL ChromaDB / onnxruntime work happens here, in a separate process.
If onnxruntime crashes (e.g. native access violation on Windows),
only this subprocess dies — the MCP server stays alive.

Protocol: receives a JSON command on stdin, writes JSON result to stdout.
"""

import json
import sys
import os
import time

# Suppress any stray output from onnxruntime / chromadb
os.environ.setdefault("ORT_LOG_LEVEL", "3")  # ERROR only
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")


def _get_collection():
    import chromadb
    from chromadb.config import Settings
    from dcp.chat_memory.config import get_chroma_dir

    chroma_dir = get_chroma_dir()
    chroma_dir.mkdir(parents=True, exist_ok=True)
    client = chromadb.PersistentClient(
        path=str(chroma_dir),
        settings=Settings(anonymized_telemetry=False),
    )
    return client.get_or_create_collection(
        name="chat_messages",
        metadata={"description": "Cursor chat message history"},
    )


def cmd_search(params: dict) -> dict:
    """Run a semantic search against the indexed chat messages."""
    query = params["query"]
    n_results = params.get("n_results", 5)
    where = params.get("where")
    fetch_limit = n_results * 5

    collection = _get_collection()
    count = collection.count()
    if count == 0:
        return {"results": _empty_results(), "count": 0}

    try:
        results = collection.query(
            query_texts=[query],
            n_results=min(fetch_limit, count),
            where=where,
            include=["documents", "metadatas", "distances"],
        )
    except Exception as e:
        return {"results": _empty_results(), "count": count, "error": str(e)}

    return {"results": results, "count": count}


def cmd_get(params: dict) -> dict:
    """Get documents by filter (for conversation expansion)."""
    collection = _get_collection()
    try:
        results = collection.get(
            where=params["where"],
            include=["documents", "metadatas"],
        )
    except Exception as e:
        return {"results": _empty_results(), "error": str(e)}
    return {"results": results}


def cmd_index(params: dict) -> dict:
    """Run incremental indexing. Returns stats."""
    import sqlite3
    from dcp.chat_memory.config import get_meta_db_path
    from dcp.chat_memory.extractor import extract_messages_iter
    from dcp.chat_memory.indexer import (
        _init_meta_db, _load_known_ids, _save_indexed_ids,
        _record_run, _build_document, _chunk_text,
        BATCH_SIZE, MAX_MESSAGES_PER_RUN, BATCH_SLEEP_SECONDS,
    )

    meta_path = get_meta_db_path()
    collection = _get_collection()

    _init_meta_db(meta_path)
    known_ids = _load_known_ids(meta_path)
    msg_iter = extract_messages_iter(known_ids)

    total_this_run = 0

    while total_this_run < MAX_MESSAGES_PER_RUN:
        batch = []
        for msg in msg_iter:
            batch.append(msg)
            if len(batch) >= BATCH_SIZE:
                break
        if not batch:
            break

        doc_ids = []
        documents = []
        metadatas = []

        for msg in batch:
            doc_text = _build_document(msg)
            chunks = _chunk_text(doc_text)

            for chunk_idx, chunk in enumerate(chunks):
                doc_id = (
                    f"{msg.bubble_id}:{chunk_idx}"
                    if len(chunks) > 1
                    else msg.bubble_id
                )
                doc_ids.append(doc_id)
                documents.append(chunk)
                metadatas.append({
                    "composer_id": msg.composer_id,
                    "bubble_id": msg.bubble_id,
                    "message_index": msg.message_index,
                    "message_type": msg.message_type,
                    "workspace_path": msg.workspace_path,
                    "conversation_name": msg.conversation_name,
                    "timestamp": msg.timestamp,
                    "mode": msg.mode,
                })

        collection.upsert(ids=doc_ids, documents=documents, metadatas=metadatas)
        _save_indexed_ids(meta_path, [m.bubble_id for m in batch])
        total_this_run += len(batch)

        time.sleep(BATCH_SLEEP_SECONDS)

    if total_this_run > 0:
        _record_run(meta_path, total_this_run)

    return {
        "indexed": total_this_run,
        "total_in_collection": collection.count(),
    }


def cmd_count(_params: dict) -> dict:
    """Get current collection count."""
    collection = _get_collection()
    return {"count": collection.count()}


def _empty_results() -> dict:
    return {"ids": [[]], "documents": [[]], "metadatas": [[]], "distances": [[]]}


COMMANDS = {
    "search": cmd_search,
    "get": cmd_get,
    "index": cmd_index,
    "count": cmd_count,
}


def main():
    raw = sys.stdin.read()
    try:
        request = json.loads(raw)
    except json.JSONDecodeError as e:
        print(json.dumps({"error": f"Invalid JSON: {e}"}))
        sys.exit(1)

    cmd = request.get("cmd")
    params = request.get("params", {})

    handler = COMMANDS.get(cmd)
    if not handler:
        print(json.dumps({"error": f"Unknown command: {cmd}"}))
        sys.exit(1)

    try:
        result = handler(params)
        print(json.dumps(result, default=str))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
