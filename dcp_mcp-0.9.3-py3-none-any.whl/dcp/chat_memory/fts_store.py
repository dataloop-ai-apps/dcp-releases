"""SQLite FTS5 store for chat message indexing and search.

Replaces the ChromaDB worker subprocess with direct in-process SQLite queries.
Zero external dependencies, no onnxruntime, no native crash risk.
"""

import sqlite3
from pathlib import Path
from typing import Any

from dcp.chat_memory.config import get_fts_db_path


def _get_conn(db_path: Path | None = None) -> sqlite3.Connection:
    path = db_path or get_fts_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    _ensure_tables(conn)
    return conn


def _ensure_tables(conn: sqlite3.Connection) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS chat_messages (
            doc_id TEXT PRIMARY KEY,
            bubble_id TEXT NOT NULL,
            composer_id TEXT NOT NULL,
            message_index INTEGER NOT NULL DEFAULT 0,
            message_type TEXT NOT NULL DEFAULT '',
            workspace_path TEXT NOT NULL DEFAULT '',
            conversation_name TEXT NOT NULL DEFAULT '',
            timestamp TEXT NOT NULL DEFAULT '',
            mode TEXT NOT NULL DEFAULT '',
            document TEXT NOT NULL DEFAULT ''
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_chat_composer
        ON chat_messages(composer_id)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_chat_bubble
        ON chat_messages(bubble_id)
    """)
    conn.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS chat_fts USING fts5(
            doc_id, document, tokenize='porter unicode61'
        )
    """)
    conn.commit()


class ChatFTSStore:
    """In-process FTS5 store for chat messages."""

    def __init__(self, db_path: Path | None = None):
        self._db_path = db_path
        self._conn: sqlite3.Connection | None = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = _get_conn(self._db_path)
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def upsert(
        self,
        ids: list[str],
        documents: list[str],
        metadatas: list[dict[str, Any]],
    ) -> None:
        c = self.conn
        for doc_id, doc, meta in zip(ids, documents, metadatas):
            c.execute("DELETE FROM chat_fts WHERE doc_id = ?", (doc_id,))
            c.execute(
                "INSERT OR REPLACE INTO chat_messages "
                "(doc_id, bubble_id, composer_id, message_index, message_type, "
                "workspace_path, conversation_name, timestamp, mode, document) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    doc_id,
                    meta.get("bubble_id", doc_id),
                    meta.get("composer_id", ""),
                    meta.get("message_index", 0),
                    meta.get("message_type", ""),
                    meta.get("workspace_path", ""),
                    meta.get("conversation_name", ""),
                    meta.get("timestamp", ""),
                    meta.get("mode", ""),
                    doc,
                ),
            )
            c.execute(
                "INSERT INTO chat_fts (doc_id, document) VALUES (?, ?)",
                (doc_id, doc),
            )
        c.commit()

    @staticmethod
    def _fts_escape(query: str) -> str:
        tokens = query.split()
        if not tokens:
            return '""'
        return " ".join(f'"{t}"' for t in tokens)

    def search(
        self,
        query: str,
        n_results: int = 5,
        where: dict[str, Any] | None = None,
    ) -> dict:
        """Search chat messages. Returns ChromaDB-compatible result dict."""
        total = self.count()
        if total == 0:
            return {"results": _empty_results(), "count": 0}

        safe_q = self._fts_escape(query)
        where_sql, params = self._build_where(where)
        params.insert(0, safe_q)

        fetch_limit = n_results * 5
        params.append(fetch_limit)

        sql = f"""
            SELECT m.*, bm25(chat_fts) AS rank
            FROM chat_fts fts
            JOIN chat_messages m ON m.doc_id = fts.doc_id
            WHERE chat_fts MATCH ?
            {where_sql}
            ORDER BY rank
            LIMIT ?
        """

        try:
            rows = self.conn.execute(sql, params).fetchall()
        except Exception as e:
            return {"results": _empty_results(), "count": total, "error": str(e)}

        ids: list[str] = []
        documents: list[str] = []
        metadatas: list[dict] = []
        distances: list[float] = []

        if rows:
            worst_rank = min(r["rank"] for r in rows)
            best_rank = max(r["rank"] for r in rows)
            span = best_rank - worst_rank if best_rank != worst_rank else 1.0

            for row in rows:
                relevance = 1.0 - (row["rank"] - worst_rank) / span if span else 0.5
                distance = 1.0 - max(0.0, min(1.0, relevance))

                ids.append(row["doc_id"])
                documents.append(row["document"])
                metadatas.append({
                    "composer_id": row["composer_id"],
                    "bubble_id": row["bubble_id"],
                    "message_index": row["message_index"],
                    "message_type": row["message_type"],
                    "workspace_path": row["workspace_path"],
                    "conversation_name": row["conversation_name"],
                    "timestamp": row["timestamp"],
                    "mode": row["mode"],
                })
                distances.append(round(distance, 4))

        return {
            "results": {
                "ids": [ids],
                "documents": [documents],
                "metadatas": [metadatas],
                "distances": [distances],
            },
            "count": total,
        }

    def get(self, where: dict[str, Any]) -> dict:
        """Get documents by metadata filter. Returns ChromaDB-compatible dict."""
        where_sql, params = self._build_where(where, prefix="WHERE")

        sql = f"SELECT * FROM chat_messages m {where_sql} ORDER BY m.message_index"

        try:
            rows = self.conn.execute(sql, params).fetchall()
        except Exception as e:
            return {"results": _empty_results_flat(), "error": str(e)}

        ids = [r["doc_id"] for r in rows]
        documents = [r["document"] for r in rows]
        metadatas = [
            {
                "composer_id": r["composer_id"],
                "bubble_id": r["bubble_id"],
                "message_index": r["message_index"],
                "message_type": r["message_type"],
                "workspace_path": r["workspace_path"],
                "conversation_name": r["conversation_name"],
                "timestamp": r["timestamp"],
                "mode": r["mode"],
            }
            for r in rows
        ]

        return {"results": {"ids": ids, "documents": documents, "metadatas": metadatas}}

    def count(self) -> int:
        row = self.conn.execute("SELECT COUNT(*) AS cnt FROM chat_messages").fetchone()
        return row["cnt"] if row else 0

    @staticmethod
    def _build_where(
        where: dict[str, Any] | None,
        prefix: str = "AND",
    ) -> tuple[str, list[Any]]:
        """Convert a ChromaDB-style where filter to SQL."""
        if not where:
            return "", []

        clauses: list[str] = []
        params: list[Any] = []

        for key, value in where.items():
            if key == "$and":
                for sub in value:
                    sub_sql, sub_params = ChatFTSStore._build_where(sub, prefix="AND")
                    if sub_sql:
                        clauses.append(sub_sql.replace("AND ", "", 1))
                        params.extend(sub_params)
            elif key == "$or":
                or_parts = []
                for sub in value:
                    sub_sql, sub_params = ChatFTSStore._build_where(sub, prefix="AND")
                    if sub_sql:
                        or_parts.append(sub_sql.replace("AND ", "", 1))
                        params.extend(sub_params)
                if or_parts:
                    clauses.append(f"({' OR '.join(or_parts)})")
            elif isinstance(value, dict):
                for op, operand in value.items():
                    if op == "$eq":
                        clauses.append(f"m.{key} = ?")
                        params.append(operand)
                    elif op == "$gte":
                        clauses.append(f"m.{key} >= ?")
                        params.append(operand)
                    elif op == "$lte":
                        clauses.append(f"m.{key} <= ?")
                        params.append(operand)
                    elif op == "$in":
                        placeholders = ",".join("?" for _ in operand)
                        clauses.append(f"m.{key} IN ({placeholders})")
                        params.extend(operand)
            else:
                clauses.append(f"m.{key} = ?")
                params.append(value)

        if not clauses:
            return "", []

        return f" {prefix} " + " AND ".join(clauses), params


def _empty_results() -> dict:
    return {"ids": [[]], "documents": [[]], "metadatas": [[]], "distances": [[]]}


def _empty_results_flat() -> dict:
    return {"ids": [], "documents": [], "metadatas": []}
