"""Search across indexed Cursor chat messages using SQLite FTS5.

All operations run in-process — no subprocess, no onnxruntime.
"""

from dcp.chat_memory.fts_store import ChatFTSStore
from dcp.chat_memory.indexer import _build_search_filter

CONTEXT_WINDOW = 3
MAX_TEXT_LENGTH = 3000


def search_chats(
    query: str,
    workspace_path: str | None = None,
    n_results: int = 5,
    time_range: str | None = None,
) -> list[dict]:
    """Search indexed chat messages (blocking)."""
    where = _build_search_filter(workspace_path, time_range)
    store = ChatFTSStore()
    try:
        result = store.search(query=query, n_results=n_results, where=where)
    finally:
        store.close()
    return _process_search_result(result, n_results)


def _process_search_result(result: dict | None, n_results: int) -> list[dict]:
    """Process raw search results into grouped conversations."""
    if result is None or "error" in result:
        return []

    count = result.get("count", 0)
    if count == 0:
        return []

    results = result.get("results", {})
    if not results.get("ids") or not results["ids"][0]:
        return []

    conversations = _group_by_conversation(results)

    sorted_convs = sorted(
        conversations.values(),
        key=lambda c: c["relevance_score"],
        reverse=True,
    )[:n_results]

    output = []
    for conv in sorted_convs:
        messages = _expand_conversation(
            conv["composer_id"], conv["matched_bubble_ids"]
        )
        output.append({
            "conversation_name": conv["conversation_name"],
            "composer_id": conv["composer_id"],
            "workspace_path": conv["workspace_path"],
            "mode": conv["mode"],
            "relevance_score": round(conv["relevance_score"], 3),
            "messages": messages,
        })

    return output


def _group_by_conversation(results: dict) -> dict[str, dict]:
    """Group search results by composer_id, keeping best relevance per conversation."""
    conversations: dict[str, dict] = {}

    for i, doc_id in enumerate(results["ids"][0]):
        metadata = results["metadatas"][0][i] if results["metadatas"] else {}
        distance = results["distances"][0][i] if results["distances"] else 1.0
        relevance = max(0.0, 1.0 - distance)

        composer_id = metadata.get("composer_id", "")
        if not composer_id:
            continue

        if composer_id not in conversations:
            conversations[composer_id] = {
                "composer_id": composer_id,
                "conversation_name": metadata.get("conversation_name", ""),
                "workspace_path": metadata.get("workspace_path", ""),
                "mode": metadata.get("mode", ""),
                "relevance_score": relevance,
                "matched_bubble_ids": set(),
            }
        elif relevance > conversations[composer_id]["relevance_score"]:
            conversations[composer_id]["relevance_score"] = relevance

        conversations[composer_id]["matched_bubble_ids"].add(
            metadata.get("bubble_id", doc_id)
        )

    return conversations


def _expand_conversation(
    composer_id: str,
    matched_bubble_ids: set[str],
) -> list[dict]:
    """Fetch messages around matched ones for conversation context."""
    store = ChatFTSStore()
    try:
        result = store.get({"composer_id": {"$eq": composer_id}})
    finally:
        store.close()
    return _parse_expansion(result, matched_bubble_ids)


def _parse_expansion(result: dict | None, matched_bubble_ids: set[str]) -> list[dict]:
    """Parse expansion results into message list."""
    if result is None or "error" in result:
        return []

    conv_results = result.get("results", {})
    if not conv_results.get("ids"):
        return []

    seen: dict[str, dict] = {}
    for i, doc_id in enumerate(conv_results["ids"]):
        metadata = conv_results["metadatas"][i] if conv_results.get("metadatas") else {}
        document = conv_results["documents"][i] if conv_results.get("documents") else ""
        bubble_id = metadata.get("bubble_id", doc_id)

        if bubble_id not in seen:
            seen[bubble_id] = {
                "bubble_id": bubble_id,
                "role": metadata.get("message_type", "unknown"),
                "text": document,
                "timestamp": metadata.get("timestamp", ""),
                "message_index": metadata.get("message_index", 0),
                "is_match": bubble_id in matched_bubble_ids,
            }
        else:
            seen[bubble_id]["text"] += " " + document

    all_messages = sorted(seen.values(), key=lambda m: m.get("message_index", 0))

    if not all_messages:
        return []

    match_indices = {
        i for i, m in enumerate(all_messages) if m.get("is_match")
    }

    if not match_indices:
        return [_format_message(m) for m in all_messages[: CONTEXT_WINDOW * 2]]

    include_indices: set[int] = set()
    for idx in match_indices:
        for offset in range(-CONTEXT_WINDOW, CONTEXT_WINDOW + 1):
            target = idx + offset
            if 0 <= target < len(all_messages):
                include_indices.add(target)

    return [_format_message(all_messages[i]) for i in sorted(include_indices)]


def _format_message(msg: dict) -> dict:
    """Format a message for the response, truncating very long texts."""
    text = msg.get("text", "")
    if len(text) > MAX_TEXT_LENGTH:
        text = text[:MAX_TEXT_LENGTH] + "... [truncated]"

    result: dict = {
        "role": msg.get("role", "unknown"),
        "text": text,
    }
    if msg.get("timestamp"):
        result["timestamp"] = msg["timestamp"]
    return result
