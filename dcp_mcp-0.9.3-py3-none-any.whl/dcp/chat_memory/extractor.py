"""Extract chat messages from Cursor's local SQLite databases."""

import json
import sqlite3
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path

from dcp.chat_memory.config import get_global_db_path, get_workspace_storage_path


@dataclass
class ChatMessage:
    """A single chat message extracted from Cursor."""

    bubble_id: str
    composer_id: str
    message_index: int
    text: str
    message_type: str  # "user" or "assistant"
    code_blocks: list[str] = field(default_factory=list)
    workspace_path: str = ""
    conversation_name: str = ""
    timestamp: str = ""
    mode: str = ""


def _open_readonly(db_path: Path) -> sqlite3.Connection | None:
    """Open a SQLite database in read-only mode to avoid locking Cursor."""
    if not db_path.exists():
        return None
    try:
        uri = f"file:{db_path}?mode=ro"
        return sqlite3.connect(uri, uri=True)
    except sqlite3.Error:
        return None


def _build_workspace_mappings(ws_storage: Path) -> dict[str, dict]:
    """Build composer ID to workspace metadata mappings.

    Scans workspace storage directories for composer.composerData
    and workspace.json to map conversations to workspaces.
    """
    mappings: dict[str, dict] = {}

    if not ws_storage.exists():
        return mappings

    for ws_dir in ws_storage.iterdir():
        if not ws_dir.is_dir():
            continue

        workspace_path = _read_workspace_path(ws_dir)
        _read_composer_data(ws_dir, workspace_path, mappings)

    return mappings


def _read_workspace_path(ws_dir: Path) -> str:
    """Read workspace path from workspace.json in a workspace storage dir."""
    ws_json = ws_dir / "workspace.json"
    if not ws_json.exists():
        return ""

    try:
        data = json.loads(ws_json.read_text(encoding="utf-8"))
        folder = data.get("folder", "")
        if not folder:
            return ""
        if folder.startswith("file:///"):
            return folder[8:]
        if folder.startswith("file://"):
            return folder[7:]
        return folder
    except (json.JSONDecodeError, OSError):
        return ""


def _read_composer_data(
    ws_dir: Path, workspace_path: str, mappings: dict[str, dict]
) -> None:
    """Read composer metadata from a workspace's state.vscdb."""
    db_path = ws_dir / "state.vscdb"
    conn = _open_readonly(db_path)
    if conn is None:
        return

    try:
        cursor = conn.execute(
            "SELECT value FROM ItemTable WHERE key = 'composer.composerData'"
        )
        row = cursor.fetchone()
        if not row:
            return

        composer_data = json.loads(row[0])
        if not isinstance(composer_data, dict):
            return

        for composer_id, meta in composer_data.items():
            if not isinstance(meta, dict):
                continue
            mappings[composer_id] = {
                "workspace_path": workspace_path,
                "name": meta.get("name", ""),
                "mode": meta.get("mode", ""),
                "timestamp": str(
                    meta.get("lastUpdatedAt", meta.get("createdAt", ""))
                ),
            }
    except (sqlite3.Error, json.JSONDecodeError, KeyError):
        pass
    finally:
        conn.close()


def extract_messages_iter(
    known_ids: set[str] | None = None,
) -> Iterator[ChatMessage]:
    """Yield chat messages one at a time from Cursor's SQLite databases.

    Uses cursor iteration instead of fetchall() to avoid loading all rows
    into memory at once. This is critical for large chat histories (30K+).

    Args:
        known_ids: Set of bubble IDs already indexed. These will be skipped.
    """
    if known_ids is None:
        known_ids = set()

    global_db = get_global_db_path()
    conn = _open_readonly(global_db)
    if conn is None:
        return

    ws_mappings = _build_workspace_mappings(get_workspace_storage_path())

    try:
        cursor = conn.execute(
            "SELECT key, value FROM cursorDiskKV WHERE key LIKE 'bubbleId:%'"
        )

        for key, value in cursor:
            if not key or value is None:
                continue

            parts = key.split(":")
            if len(parts) < 3:
                continue

            bubble_id = key
            composer_id = parts[1]

            if bubble_id in known_ids:
                continue

            try:
                msg_index = int(parts[2])
            except ValueError:
                msg_index = 0

            try:
                data = json.loads(value)
            except (json.JSONDecodeError, TypeError):
                continue

            text = data.get("text", "")
            if not text and not data.get("codeBlocks"):
                continue

            msg_type_raw = data.get("type", 0)
            if msg_type_raw == 1 or msg_type_raw == "user":
                message_type = "user"
            else:
                message_type = "assistant"

            code_blocks = []
            for cb in data.get("codeBlocks", []):
                if isinstance(cb, dict):
                    content = cb.get("content", cb.get("code", ""))
                    if content:
                        code_blocks.append(content)
                elif isinstance(cb, str):
                    code_blocks.append(cb)

            ws_meta = ws_mappings.get(composer_id, {})

            yield ChatMessage(
                bubble_id=bubble_id,
                composer_id=composer_id,
                message_index=msg_index,
                text=text,
                message_type=message_type,
                code_blocks=code_blocks,
                workspace_path=ws_meta.get("workspace_path", ""),
                conversation_name=ws_meta.get("name", ""),
                timestamp=str(ws_meta.get("timestamp", "")),
                mode=ws_meta.get("mode", ""),
            )
    except sqlite3.Error:
        pass
    finally:
        conn.close()
