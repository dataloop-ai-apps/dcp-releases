"""CLI entry point for dcp (Dev Control Plane)."""

import argparse
import shutil
import sys
from pathlib import Path

from rich.console import Console
from rich.table import Table

console = Console()


def get_example_cursor_rules_dir() -> Path:
    """Get the path to the bundled cursor rules directory."""
    from dcp.paths import get_cursor_rules_dir
    return get_cursor_rules_dir()


def copy_cursor_rules(
    repo_path: Path,
    force: bool = False,
) -> dict:
    """Copy .cursor/rules/*.mdc files to target repo.
    
    Args:
        repo_path: Target repository path
        force: Overwrite existing files if True
        
    Returns:
        Summary dict with copied/skipped/merged files
    """
    result = {
        "success": True,
        "copied": [],
        "skipped": [],
        "merged": [],
        "errors": [],
    }
    
    examples_dir = get_example_cursor_rules_dir()
    
    if not examples_dir.exists():
        result["success"] = False
        result["errors"].append(f"Example rules not found at {examples_dir}")
        return result
    
    # Create .cursor/rules/ directory in target repo
    target_dir = repo_path / ".cursor" / "rules"
    target_dir.mkdir(parents=True, exist_ok=True)
    
    # Copy each .mdc file
    for mdc_file in examples_dir.glob("*.mdc"):
        target_file = target_dir / mdc_file.name
        
        if target_file.exists():
            if force:
                # Overwrite
                shutil.copy2(mdc_file, target_file)
                result["copied"].append(mdc_file.name)
            else:
                # Skip existing files
                result["skipped"].append(mdc_file.name)
        else:
            # Copy new file
            shutil.copy2(mdc_file, target_file)
            result["copied"].append(mdc_file.name)
    
    return result


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="dcp",
        description="Dev Control Plane - Development modes, guidelines, and active learning",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # init command
    init_parser = subparsers.add_parser("init", help="Initialize memory for a repo")
    init_parser.add_argument("--path", "-p", default=".", help="Path to repo (default: current directory)")
    init_parser.add_argument("--name", "-n", help="Repo name (default: directory name)")
    init_parser.add_argument("--no-git", action="store_true", help="Skip git analysis")
    init_parser.add_argument("--no-starters", action="store_true", help="Skip starter templates")
    init_parser.add_argument("--merge-existing", action="store_true", help="Import existing .cursorrules into memory")
    init_parser.add_argument("--no-cursor-rules", action="store_true", help="Skip copying .cursor/rules/ files")
    init_parser.add_argument("--force-cursor-rules", action="store_true", help="Overwrite existing .cursor/rules/ files")
    init_parser.add_argument("--no-dedup", action="store_true", help="Skip deduplication against base guidelines")
    init_parser.add_argument("--dedup-threshold", type=float, default=0.75, help="Dedup similarity threshold (default: 0.75)")
    
    # serve command (MCP server)
    serve_parser = subparsers.add_parser("serve", help="Start the MCP server")
    
    # info command
    info_parser = subparsers.add_parser("info", help="Show repo memory info")
    info_parser.add_argument("--path", "-p", default=".", help="Path to repo")
    
    # ingest command (for guidelines)
    ingest_parser = subparsers.add_parser("ingest", help="Ingest guidelines into search index")
    ingest_parser.add_argument("--guidelines", "-g", help="Path to guidelines directory")
    ingest_parser.add_argument("--output", "-o", help="Path to output database directory")
    
    args = parser.parse_args()
    
    if args.command == "init":
        return cmd_init(args)
    elif args.command == "serve":
        return cmd_serve(args)
    elif args.command == "info":
        return cmd_info(args)
    elif args.command == "ingest":
        return cmd_ingest(args)
    else:
        parser.print_help()
        return 0


def cmd_init(args):
    """Initialize memory for a repo."""
    from dcp.memory.loader import memory_exists, create_initial_memory, save_memory
    from dcp.memory.git_analyzer import detect_tech_stack
    from dcp.memory.starter_templates import get_starter_learnings, get_starter_conventions
    from dcp.schemas.memory import Stack

    repo_path = Path(args.path).resolve()

    if not repo_path.exists():
        console.print(f"[red]Error:[/red] Path does not exist: {repo_path}")
        return 1

    if memory_exists(repo_path):
        console.print(f"[yellow]Warning:[/yellow] Memory already exists at {repo_path}")
        console.print("Use [cyan]dcp info[/cyan] to view or edit directly.")
        return 1

    console.print(f"\n[bold]Analyzing repository:[/bold] [cyan]{repo_path}[/cyan]\n")

    memory = create_initial_memory(repo_path, args.name)

    # Detect tech stack
    console.print("[bold]Tech Stack Detection[/bold]")
    tech_stack = detect_tech_stack(repo_path)
    memory.stack = Stack(**tech_stack)

    if tech_stack.get("languages"):
        console.print(f"   Languages: [green]{', '.join(tech_stack['languages'])}[/green]")
    if tech_stack.get("frameworks"):
        console.print(f"   Frameworks: [green]{', '.join(tech_stack['frameworks'])}[/green]")
    if tech_stack.get("testing"):
        console.print(f"   Testing: [green]{tech_stack['testing']}[/green]")

    # Git analysis → context notes
    if not args.no_git:
        console.print("\n[bold]Git History Analysis[/bold]")
        try:
            from dcp.memory.git_analyzer import analyze_git_history
            discoveries = analyze_git_history(repo_path)
            if discoveries:
                if discoveries.branch_patterns:
                    top = discoveries.branch_patterns[0]
                    memory.context.notes.append(f"Branch pattern: {top.get('pattern', 'unknown')}")
                    console.print(f"   Branch pattern: [green]{top['pattern']}[/green]")
                if discoveries.hot_files:
                    names = [f.get("file", "?") for f in discoveries.hot_files[:3]]
                    memory.context.notes.append(f"Hot files: {', '.join(names)}")
                    console.print(f"   Hot files: [yellow]{len(discoveries.hot_files)} frequently modified[/yellow]")
            else:
                console.print("   [dim]Not a git repository or no history[/dim]")
        except Exception:
            console.print("   [dim]Git analysis skipped[/dim]")

    # Starter templates
    if not args.no_starters:
        console.print("\n[bold]Pre-populating Memory[/bold]")

        starter_learnings = get_starter_learnings(tech_stack)
        starter_conventions = get_starter_conventions(tech_stack)

        deduplicate = not getattr(args, 'no_dedup', False)
        dedup_threshold = getattr(args, 'dedup_threshold', 0.75)

        if deduplicate:
            from dcp.memory.deduplication import deduplicate_learnings, deduplicate_conventions

            console.print("\n[bold]Checking Against Base Guidelines[/bold]")
            original_count = len(starter_learnings)

            starter_learnings, skipped_learnings = deduplicate_learnings(
                starter_learnings, threshold=dedup_threshold
            )

            languages = tech_stack.get("languages", [])
            starter_conventions, skipped_conventions = deduplicate_conventions(
                starter_conventions, languages=languages, threshold=dedup_threshold
            )

            if skipped_learnings:
                console.print(f"   Skipped: [yellow]{len(skipped_learnings)}[/yellow] learnings (already in base guidelines)")
            if skipped_conventions:
                console.print(f"   Skipped: [yellow]{len(skipped_conventions)}[/yellow] conventions (already in base guidelines)")
            console.print(f"   Unique learnings to add: [green]{len(starter_learnings)}[/green]")

        memory.learnings = starter_learnings
        memory.conventions = starter_conventions

        if starter_learnings:
            console.print(f"   Added [green]{len(starter_learnings)}[/green] starter learnings")
        console.print(f"   Added conventions for detected stack")

    # Save memory
    file_path = save_memory(repo_path, memory)

    console.print(f"\n[bold green]Created:[/bold green] {file_path.relative_to(repo_path)}")

    # Copy .cursor/rules/ files
    if not getattr(args, 'no_cursor_rules', False):
        console.print("\n[bold]Cursor Rules Setup[/bold]")
        force_rules = getattr(args, 'force_cursor_rules', False)
        rules_result = copy_cursor_rules(repo_path, force=force_rules)

        if rules_result["copied"]:
            console.print(f"   Copied: [green]{', '.join(rules_result['copied'])}[/green]")
        if rules_result["skipped"]:
            console.print(f"   Skipped (already exist): [yellow]{', '.join(rules_result['skipped'])}[/yellow]")
        if rules_result["errors"]:
            for error in rules_result["errors"]:
                console.print(f"   [red]Error: {error}[/red]")

    console.print("\n[bold]Next steps:[/bold]")
    console.print("   1. Review the memory file and adjust as needed")
    console.print("   2. Add architecture overview if not detected")
    console.print("   3. Use the MCP tools in Cursor to interact")

    return 0


def cmd_serve(args):
    """Start the MCP server."""
    from dcp.server import run_server
    run_server()
    return 0


def cmd_info(args):
    """Show repo memory info."""
    from dcp.memory.loader import load_memory, memory_exists

    repo_path = Path(args.path).resolve()

    if not memory_exists(repo_path):
        console.print(f"[yellow]No memory found at {repo_path}[/yellow]")
        console.print("Run [cyan]dcp init[/cyan] to create one.")
        return 1

    memory = load_memory(repo_path)

    if memory is None:
        console.print("[red]Error loading memory[/red]")
        return 1

    console.print(f"\n[bold]Repo Memory: {memory.metadata.repo_name}[/bold]\n")

    # Architecture
    if memory.architecture:
        console.print("[bold]Architecture[/bold]")
        console.print(f"  {memory.architecture[:200]}")

    # Tech stack
    console.print("\n[bold]Stack[/bold]")
    if memory.stack.languages:
        console.print(f"  Languages: {', '.join(memory.stack.languages)}")
    if memory.stack.frameworks:
        console.print(f"  Frameworks: {', '.join(memory.stack.frameworks)}")

    # Conventions
    if memory.conventions:
        console.print(f"\n[bold]Conventions:[/bold] {len(memory.conventions)}")

    # Learnings summary
    console.print(f"\n[bold]Learnings:[/bold] {len(memory.learnings)} total")

    table = Table(show_header=True, header_style="bold")
    table.add_column("Category")
    table.add_column("Count", justify="right")
    table.add_column("High Confidence (80+)", justify="right")

    from collections import Counter
    cat_counts = Counter(l.category for l in memory.learnings)
    cat_high = Counter(l.category for l in memory.learnings if l.confidence >= 80)

    for cat in ["review_feedback", "bug_patterns", "edge_cases", "gotchas", "decisions"]:
        count = cat_counts.get(cat, 0)
        if count > 0:
            table.add_row(cat, str(count), str(cat_high.get(cat, 0)))

    if cat_counts:
        console.print(table)

    # Context
    if memory.context.notes:
        console.print(f"\n[bold]Context Notes:[/bold] {len(memory.context.notes)}")

    console.print(f"\n[dim]Last updated: {memory.metadata.last_updated}[/dim]")

    return 0


def cmd_ingest(args):
    """Ingest guidelines into search index."""
    from dcp.guidelines.ingester import ingest_guidelines, get_default_guidelines_dir
    
    # Determine guidelines directory
    if args.guidelines:
        guidelines_dir = Path(args.guidelines).resolve()
    else:
        guidelines_dir = get_default_guidelines_dir()
    
    if not guidelines_dir.exists():
        console.print(f"[red]Guidelines directory not found: {guidelines_dir}[/red]")
        return 1
    
    console.print(f"Ingesting guidelines from: [cyan]{guidelines_dir}[/cyan]")
    
    # Determine output directory
    output_dir = Path(args.output) if args.output else None
    
    result = ingest_guidelines(guidelines_dir, output_dir)
    
    if not result.get("success"):
        console.print(f"[red]Error: {result.get('error')}[/red]")
        return 1
    
    console.print(f"\n[green]Ingested {result['total_ingested']} guidelines[/green]")
    
    if result.get("categories"):
        console.print("\n[bold]Categories:[/bold]")
        for cat, count in result["categories"].items():
            console.print(f"  {cat}: {count}")
    
    if result.get("languages"):
        console.print(f"\n[bold]Languages:[/bold] {', '.join(result['languages'])}")
    
    if output_dir:
        console.print(f"\nSaved to: [cyan]{output_dir}[/cyan]")
    else:
        console.print("\n[yellow]Note: Using in-memory storage (not persisted)[/yellow]")
        console.print("Use [cyan]--output PATH[/cyan] to save to disk")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
