"""MCP tools for guideline search and retrieval."""

from typing import Any

from mcp.types import TextContent

from dcp.guidelines.search import (
    search_guidelines,
    get_guideline,
    list_guideline_categories,
)


async def handle_search_guidelines(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle search_guidelines tool call."""
    query = arguments["query"]
    languages = arguments.get("languages")
    frameworks = arguments.get("frameworks")
    categories = arguments.get("categories")
    severity = arguments.get("severity")
    limit = arguments.get("limit", 5)
    boost_repo_stack = arguments.get("boost_repo_stack", False)
    
    results = search_guidelines(
        query=query,
        languages=languages,
        frameworks=frameworks,
        categories=categories,
        severity=severity,
        limit=limit,
        boost_repo_stack=boost_repo_stack,
    )

    return [TextContent(type="text", text=_format_guideline_results(query, results))]


def _format_guideline_results(query: str, results: list) -> str:
    """Format guideline search results as plain text."""
    lines = []
    lines.append(f"query: {query}")
    lines.append(f"total_results: {len(results)}")

    if not results:
        lines.append("results: none")
        return "\n".join(lines)

    for i, r in enumerate(results, 1):
        d = r.model_dump()
        lines.append(f"\n--- guideline {i} ---")
        lines.append(f"id: {d.get('id', '?')}")
        lines.append(f"title: {d.get('title', '?')}")
        lines.append(f"category: {d.get('category', '?')}")
        lines.append(f"severity: {d.get('severity', '?')}")
        lines.append(f"score: {d.get('score', 0)}")
        if d.get("languages"):
            lines.append(f"languages: {', '.join(d['languages'])}")
        if d.get("frameworks"):
            lines.append(f"frameworks: {', '.join(d['frameworks'])}")
        if d.get("description"):
            lines.append(f"description: {d['description']}")

    return "\n".join(lines)


async def handle_get_guideline(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle get_guideline tool call."""
    guideline_id = arguments["guideline_id"]
    
    guideline = get_guideline(guideline_id)
    
    if guideline is None:
        return [TextContent(type="text", text=f"error: Guideline not found: {guideline_id}")]

    lines = []
    for k, v in guideline.items():
        if isinstance(v, list):
            lines.append(f"{k}: {', '.join(str(x) for x in v)}")
        else:
            lines.append(f"{k}: {v}")
    return [TextContent(type="text", text="\n".join(lines))]


async def handle_list_categories(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle list_guideline_categories tool call."""
    categories = list_guideline_categories()
    
    lines = [f"total_categories: {len(categories)}"]
    for cat in categories:
        lines.append(f"  - {cat}")
    return [TextContent(type="text", text="\n".join(lines))]
