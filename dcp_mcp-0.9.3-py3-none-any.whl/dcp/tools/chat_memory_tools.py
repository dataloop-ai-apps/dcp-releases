"""MCP tool handler for chat memory search.

All heavy operations (ChromaDB, onnxruntime) run in isolated worker
subprocesses so native crashes cannot kill the MCP server.

Logging goes to ~/.dcp/chat-memory/dcp-chat.log for post-crash debugging.
"""

import json
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from mcp.types import TextContent

LOG_DIR = Path.home() / ".dcp" / "chat-memory"
LOG_FILE = LOG_DIR / "dcp-chat.log"


def _setup_file_logger() -> logging.Logger:
    """Set up a file logger that survives MCP server crashes."""
    logger = logging.getLogger("dcp.chat_memory")
    if logger.handlers:
        return logger
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(str(LOG_FILE), encoding="utf-8")
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s: %(message)s"
    ))
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    return logger


logger = _setup_file_logger()


def _run_worker_safe(cmd: str, params: dict | None = None, timeout: int = 60) -> dict:
    """Run a worker subprocess with maximum isolation.

    Uses subprocess.run (not asyncio) with fully piped stdio and
    explicit handle inheritance disabled on Windows.
    """
    request = json.dumps({"cmd": cmd, "params": params or {}})
    logger.debug("Worker START cmd=%s timeout=%s", cmd, timeout)

    try:
        kwargs: dict = {
            "input": request,
            "capture_output": True,
            "text": True,
            "timeout": timeout,
        }
        if sys.platform == "win32":
            kwargs["creationflags"] = (
                subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
            )

        result = subprocess.run(
            [sys.executable, "-m", "dcp.chat_memory.worker"],
            **kwargs,
        )
    except subprocess.TimeoutExpired:
        logger.warning("Worker TIMEOUT cmd=%s after %ss", cmd, timeout)
        return {"error": f"Worker timed out after {timeout}s"}
    except OSError as e:
        logger.error("Worker SPAWN FAILED cmd=%s: %s", cmd, e)
        return {"error": f"Failed to spawn worker: {e}"}
    except Exception as e:
        logger.error("Worker UNEXPECTED cmd=%s: %s", cmd, e, exc_info=True)
        return {"error": f"Worker error: {type(e).__name__}: {e}"}

    if result.returncode != 0:
        stderr = (result.stderr or "").strip()[:500]
        stdout = (result.stdout or "").strip()[:500]
        if result.returncode == 3221225477:
            logger.error("Worker NATIVE CRASH cmd=%s (onnxruntime access violation) stderr=%s stdout=%s", cmd, stderr, stdout)
            return {"error": f"Worker crashed (onnxruntime access violation). stderr: {stderr}"}
        logger.error("Worker FAILED cmd=%s exit=%s stderr=%s stdout=%s", cmd, result.returncode, stderr, stdout)
        return {"error": f"Worker exited with code {result.returncode}. stderr: {stderr}. stdout: {stdout}"}

    stdout = (result.stdout or "").strip()
    if not stdout:
        logger.error("Worker EMPTY cmd=%s", cmd)
        return {"error": "Worker returned empty output"}

    try:
        data = json.loads(stdout)
        logger.debug("Worker OK cmd=%s keys=%s", cmd, list(data.keys()))
        return data
    except json.JSONDecodeError:
        logger.error("Worker BAD JSON cmd=%s stdout=%s", cmd, stdout[:200])
        return {"error": f"Worker returned invalid JSON: {stdout[:200]}"}


def _search_sync(query: str, n_results: int, workspace_path: str | None, time_range: str | None) -> dict:
    """Run search in a synchronous subprocess — safe to call from any context."""
    from dcp.chat_memory.indexer import _build_search_filter

    where = _build_search_filter(workspace_path, time_range)
    return _run_worker_safe("search", {
        "query": query,
        "n_results": n_results,
        "where": where,
    })


def _get_sync(where: dict) -> dict:
    """Run get-by-filter in a synchronous subprocess."""
    return _run_worker_safe("get", {"where": where})


def _process_search_results(raw: dict, n_results: int) -> list[dict]:
    """Process raw worker search output into grouped conversations."""
    from dcp.chat_memory.searcher import CONTEXT_WINDOW, MAX_TEXT_LENGTH

    if not raw or "error" in raw:
        return []

    count = raw.get("count", 0)
    if count == 0:
        return []

    results = raw.get("results", {})
    if not results.get("ids") or not results["ids"][0]:
        return []

    conversations = _group_by_conversation(results)

    sorted_convs = sorted(
        conversations.values(),
        key=lambda c: c["relevance_score"],
        reverse=True,
    )[:n_results]

    output = []
    for conv in sorted_convs:
        messages = _expand_conversation_sync(conv["composer_id"], conv["matched_bubble_ids"])
        output.append({
            "conversation_name": conv["conversation_name"],
            "composer_id": conv["composer_id"],
            "workspace_path": conv["workspace_path"],
            "mode": conv["mode"],
            "relevance_score": round(conv["relevance_score"], 3),
            "messages": messages,
        })

    return output


def _group_by_conversation(results: dict) -> dict[str, dict]:
    """Group search results by composer_id."""
    conversations: dict[str, dict] = {}
    for i, doc_id in enumerate(results["ids"][0]):
        metadata = results["metadatas"][0][i] if results["metadatas"] else {}
        distance = results["distances"][0][i] if results["distances"] else 1.0
        relevance = max(0.0, 1.0 - distance)
        composer_id = metadata.get("composer_id", "")
        if not composer_id:
            continue
        if composer_id not in conversations:
            conversations[composer_id] = {
                "composer_id": composer_id,
                "conversation_name": metadata.get("conversation_name", ""),
                "workspace_path": metadata.get("workspace_path", ""),
                "mode": metadata.get("mode", ""),
                "relevance_score": relevance,
                "matched_bubble_ids": set(),
            }
        elif relevance > conversations[composer_id]["relevance_score"]:
            conversations[composer_id]["relevance_score"] = relevance
        conversations[composer_id]["matched_bubble_ids"].add(
            metadata.get("bubble_id", doc_id)
        )
    return conversations


def _expand_conversation_sync(composer_id: str, matched_bubble_ids: set[str]) -> list[dict]:
    """Fetch context messages around matched ones via subprocess."""
    from dcp.chat_memory.searcher import CONTEXT_WINDOW, MAX_TEXT_LENGTH

    result = _get_sync({"composer_id": {"$eq": composer_id}})
    if not result or "error" in result:
        return []

    conv_results = result.get("results", {})
    if not conv_results.get("ids"):
        return []

    seen: dict[str, dict] = {}
    for i, doc_id in enumerate(conv_results["ids"]):
        metadata = conv_results["metadatas"][i] if conv_results.get("metadatas") else {}
        document = conv_results["documents"][i] if conv_results.get("documents") else ""
        bubble_id = metadata.get("bubble_id", doc_id)
        if bubble_id not in seen:
            seen[bubble_id] = {
                "bubble_id": bubble_id,
                "role": metadata.get("message_type", "unknown"),
                "text": document,
                "timestamp": metadata.get("timestamp", ""),
                "message_index": metadata.get("message_index", 0),
                "is_match": bubble_id in matched_bubble_ids,
            }
        else:
            seen[bubble_id]["text"] += " " + document

    all_messages = sorted(seen.values(), key=lambda m: m.get("message_index", 0))
    if not all_messages:
        return []

    match_indices = {i for i, m in enumerate(all_messages) if m.get("is_match")}
    if not match_indices:
        return [_format_msg(m) for m in all_messages[:CONTEXT_WINDOW * 2]]

    include: set[int] = set()
    for idx in match_indices:
        for offset in range(-CONTEXT_WINDOW, CONTEXT_WINDOW + 1):
            target = idx + offset
            if 0 <= target < len(all_messages):
                include.add(target)

    return [_format_msg(all_messages[i]) for i in sorted(include)]


def _format_msg(msg: dict) -> dict:
    from dcp.chat_memory.searcher import MAX_TEXT_LENGTH
    text = msg.get("text", "")
    if len(text) > MAX_TEXT_LENGTH:
        text = text[:MAX_TEXT_LENGTH] + "... [truncated]"
    result: dict = {"role": msg.get("role", "unknown"), "text": text}
    if msg.get("timestamp"):
        result["timestamp"] = msg["timestamp"]
    return result


async def handle_search_chats(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle search_chats tool call.

    All ChromaDB/onnxruntime work happens in isolated subprocesses via
    _run_worker_safe. No background threads, no async subprocess — just
    plain subprocess.run with Windows process isolation flags.
    """
    query = arguments.get("query", "")
    if not query:
        return [TextContent(type="text", text="error: query parameter is required")]

    logger.info("search_chats called query=%r n_results=%s", query, arguments.get("n_results", 5))

    try:
        import asyncio

        workspace_path = arguments.get("workspace_path")
        n_results = arguments.get("n_results", 5)
        time_range = arguments.get("time_range")

        loop = asyncio.get_event_loop()
        raw = await loop.run_in_executor(
            None, _search_sync, query, n_results * 5, workspace_path, time_range,
        )

        if "error" in raw:
            logger.warning("search_chats worker error: %s", raw["error"])
            return [TextContent(type="text", text=f"error: {raw['error']}")]

        results = await loop.run_in_executor(
            None, _process_search_results, raw, n_results,
        )

        index_status: dict = {"status": "idle", "total_indexed": raw.get("count", 0)}
        if os.environ.get("DCP_CHAT_INDEX_ENABLED", "").lower() in ("1", "true", "yes"):
            try:
                from dcp.chat_memory.indexer import ChatMemoryIndexer
                indexer = ChatMemoryIndexer()
                indexer.ensure_indexing_started()
                index_status = indexer.get_progress()
            except Exception as e:
                logger.warning("Background indexer failed to start: %s", e)
                index_status = {"status": "error", "error": str(e)}

        logger.info("search_chats OK results=%d", len(results))
        return [TextContent(type="text", text=_format_chat_results(results, index_status))]

    except Exception as e:
        logger.error("search_chats CRASHED: %s", e, exc_info=True)
        return [TextContent(type="text", text=f"error: {type(e).__name__}: {e}")]


def _format_chat_results(results: list[dict], index_status: dict) -> str:
    """Format chat search results as plain text."""
    lines = []
    lines.append(f"result_count: {len(results)}")
    lines.append(f"index_status: {index_status.get('status', 'unknown')}, total_indexed={index_status.get('total_indexed', 0)}")

    if not results:
        lines.append("results: none")
        return "\n".join(lines)

    for i, r in enumerate(results, 1):
        lines.append(f"\n--- result {i} ---")
        lines.append(f"conversation: {r.get('conversation_name', '?')}")
        lines.append(f"composer_id: {r.get('composer_id', '?')}")
        lines.append(f"workspace: {r.get('workspace_path', '?')}")
        lines.append(f"mode: {r.get('mode', '?')}")
        lines.append(f"relevance: {r.get('relevance_score', 0)}")
        for msg in r.get("messages", []):
            role = msg.get("role", "?")
            text = msg.get("text", "")
            lines.append(f"  {role}: {text}")

    return "\n".join(lines)
