"""MCP tools for mode management."""

import json
from typing import Any

from mcp.types import TextContent

from dcp.modes.manager import ModeManager
from dcp.modes.loader import save_custom_mode
from dcp.schemas.modes import CustomModeDefinition


# Global mode manager instance
_mode_manager: ModeManager | None = None


def get_mode_manager(repo_path: str | None = None) -> ModeManager:
    """Get or create the mode manager instance."""
    global _mode_manager
    if _mode_manager is None or repo_path:
        _mode_manager = ModeManager(repo_path)
    return _mode_manager


async def handle_select_mode(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle select_mode tool call."""
    mode_id = arguments["mode"]
    context = arguments.get("context")
    repo_path = arguments.get("repo_path")
    
    manager = get_mode_manager(repo_path)
    
    try:
        mode = manager.select_mode(mode_id, context)
        
        result = {
            "mode_id": mode.id,
            "name": mode.name,
            "description": mode.description,
            "instructions": manager.get_mode_prompt(mode_id),
            "available_tools": mode.tools_enabled,
            "checklist": mode.checklist,
            "related_modes": mode.related_modes,
        }
        
        return [TextContent(type="text", text=json.dumps(result, indent=2))]
    except ValueError as e:
        return [TextContent(type="text", text=f"Error: {e}")]


async def handle_list_modes(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle list_modes tool call."""
    repo_path = arguments.get("repo_path")
    include_custom = arguments.get("include_custom", True)
    
    manager = get_mode_manager(repo_path)
    modes = manager.list_modes(include_custom)
    
    result = {
        "modes": [mode.model_dump() for mode in modes]
    }
    
    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_get_current_mode(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle get_current_mode tool call."""
    manager = get_mode_manager()
    current = manager.get_current_mode()
    
    if current is None:
        return [TextContent(type="text", text=json.dumps({"mode": None, "message": "No mode currently selected"}))]
    
    return [TextContent(type="text", text=json.dumps(current, indent=2))]


async def handle_get_mode(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle get_mode tool call."""
    mode_id = arguments["mode_id"]
    repo_path = arguments.get("repo_path")
    
    manager = get_mode_manager(repo_path)
    mode = manager.get_mode(mode_id)
    
    if mode is None:
        return [TextContent(type="text", text=json.dumps({"error": f"Mode not found: {mode_id}"}))]
    
    result = {
        "mode": mode.model_dump(),
        "resolved_prompt": manager.get_mode_prompt(mode_id),
        "effective_tools": mode.tools_enabled,
    }
    
    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_save_custom_mode(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle save_custom_mode tool call."""
    repo_path = arguments["repo_path"]
    mode_data = arguments["mode"]
    
    try:
        custom_mode = CustomModeDefinition(**mode_data)
        file_path = save_custom_mode(repo_path, custom_mode)
        
        # Reload modes to include the new one
        manager = get_mode_manager(repo_path)
        manager.reload_modes(repo_path)
        
        result = {
            "success": True,
            "file_path": str(file_path),
            "mode_id": custom_mode.id,
        }
        
        return [TextContent(type="text", text=json.dumps(result, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"success": False, "error": str(e)}))]


async def handle_suggest_mode(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle suggest_mode tool call."""
    user_input = arguments["user_input"]
    repo_path = arguments.get("repo_path")
    
    manager = get_mode_manager(repo_path)
    suggested = manager.suggest_mode(user_input)
    
    result = {
        "suggested_mode": suggested,
        "confidence": "high" if suggested else "none",
    }
    
    if suggested:
        mode = manager.get_mode(suggested)
        if mode:
            result["mode_info"] = {
                "name": mode.name,
                "description": mode.description,
            }
    
    return [TextContent(type="text", text=json.dumps(result, indent=2))]
