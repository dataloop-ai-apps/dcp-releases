"""MCP tools for memory management (simplified v2)."""

import json
import logging
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from mcp.types import TextContent

from dcp.memory.loader import (
    load_memory,
    save_memory,
    memory_exists,
    create_initial_memory,
    get_memory_path,
)
from dcp.memory.git_analyzer import detect_tech_stack
from dcp.schemas.memory import Stack, Learning, DocReference

logger = logging.getLogger(__name__)


def _get_cursor_rules_dir() -> Path:
    """Get the path to the bundled cursor rules directory."""
    from dcp.paths import get_cursor_rules_dir
    return get_cursor_rules_dir()


def _get_skills_dir() -> Path:
    """Get the path to the bundled skills directory."""
    from dcp.paths import get_skills_dir
    return get_skills_dir()


def _copy_cursor_rules(repo_path: Path, force: bool = False) -> dict:
    """Copy cursor rules to target repo."""
    result = {"copied": [], "skipped": [], "errors": []}

    source_dir = _get_cursor_rules_dir()
    if not source_dir.exists():
        result["errors"].append(f"Cursor rules not found at {source_dir}")
        return result

    target_dir = repo_path / ".cursor" / "rules"
    target_dir.mkdir(parents=True, exist_ok=True)

    for mdc_file in source_dir.glob("*.mdc"):
        target_file = target_dir / mdc_file.name
        if target_file.exists() and not force:
            result["skipped"].append(mdc_file.name)
        else:
            shutil.copy2(mdc_file, target_file)
            result["copied"].append(mdc_file.name)

    return result


def _files_are_identical(source: Path, target: Path) -> bool:
    """Check if two files have identical content."""
    if not target.exists():
        return False
    return source.read_bytes() == target.read_bytes()


def _copy_skills(repo_path: Path, force: bool = False, smart: bool = False) -> dict:
    """Copy bundled skills to target repo's .cursor/skills/ directory.

    Args:
        repo_path: Target repo root.
        force: Overwrite all skills unconditionally.
        smart: Content-based sync — only overwrite files whose content differs.
               Mutually exclusive intent with *force* (force wins if both set).
    """
    result: dict = {"copied": [], "updated": [], "skipped": [], "errors": []}

    source_dir = _get_skills_dir()
    if not source_dir.exists():
        result["errors"].append(f"Skills not found at {source_dir}")
        return result

    target_dir = repo_path / ".cursor" / "skills"

    for skill_dir in source_dir.iterdir():
        if not skill_dir.is_dir():
            continue

        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            continue

        target_skill_dir = target_dir / skill_dir.name
        skill_exists = target_skill_dir.exists()

        if not skill_exists or force:
            shutil.copytree(skill_dir, target_skill_dir, dirs_exist_ok=True)
            result["copied"].append(skill_dir.name)

        elif smart:
            any_changed = False
            for src_file in skill_dir.rglob("*"):
                if not src_file.is_file():
                    continue
                rel = src_file.relative_to(skill_dir)
                dst_file = target_skill_dir / rel
                if not _files_are_identical(src_file, dst_file):
                    dst_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src_file, dst_file)
                    any_changed = True
            if any_changed:
                result["updated"].append(skill_dir.name)
            else:
                result["skipped"].append(skill_dir.name)

        else:
            result["skipped"].append(skill_dir.name)

    return result


def _sync_skills_silently(repo_path: Path) -> None:
    """Best-effort skill sync — never raises, never alters tool output."""
    try:
        _copy_skills(repo_path, smart=True)
    except Exception:
        logger.warning("Failed to sync skills to %s", repo_path, exc_info=True)


def _ensure_gitignore_entries(repo_path: Path) -> dict:
    """Ensure .plans/ is in the target repo's .gitignore."""
    result: dict = {"added": [], "already_present": []}

    PLANS_VARIANTS = {".plans/", ".plans", ".plans/*", "plans/", "plans", "plans/*"}

    gitignore_path = repo_path / ".gitignore"

    if gitignore_path.exists():
        content = gitignore_path.read_text(encoding="utf-8")
    else:
        content = ""

    existing_lines = {line.strip() for line in content.splitlines()}

    if existing_lines & PLANS_VARIANTS:
        result["already_present"].append(".plans/")
    else:
        block = "\n# Mode working artifacts (plans, PRDs, design docs, etc.)\n.plans/"
        if content and not content.endswith("\n"):
            block = "\n" + block
        gitignore_path.write_text(content + block + "\n", encoding="utf-8")
        result["added"].append(".plans/")

    return result


def _generate_learning_id(category: str) -> str:
    """Generate a unique learning ID."""
    short_uuid = str(uuid.uuid4())[:8]
    prefix = {
        "review_feedback": "rf",
        "bug_patterns": "bp",
        "edge_cases": "ec",
        "gotchas": "g",
        "decisions": "adr",
    }.get(category, "l")
    return f"{prefix}-{short_uuid}"


def _slugify(text: str) -> str:
    """Convert text to a URL/filename-friendly slug."""
    import re
    slug = text.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    return slug.strip("-")


# =============================================================================
# Tool handlers
# =============================================================================


async def handle_save_doc(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle save_doc tool call.

    Creates/updates a doc file in .dcp/docs/ and registers a reference in memory.
    """
    repo_path = arguments["repo_path"]
    title = arguments["title"]
    content = arguments["content"]
    description = arguments["description"]
    category = arguments.get("category", "guide")
    doc_id = arguments.get("doc_id") or _slugify(title)

    memory = load_memory(repo_path)
    if memory is None:
        return [TextContent(type="text", text=json.dumps({
            "success": False,
            "error": "Memory not found. Run init_repo first.",
        }))]

    try:
        docs_dir = Path(repo_path) / ".dcp" / "docs"
        docs_dir.mkdir(parents=True, exist_ok=True)

        filename = f"{doc_id}.md"
        filepath = docs_dir / filename
        relative_path = f".dcp/docs/{filename}"

        filepath.write_text(content, encoding="utf-8")

        existing = memory.get_doc_by_id(doc_id)
        if existing:
            existing.title = title
            existing.description = description
            existing.category = category
            existing.path = relative_path
            existing.last_updated = datetime.now()
            action = "updated"
        else:
            memory.docs.append(DocReference(
                id=doc_id,
                title=title,
                description=description,
                path=relative_path,
                category=category,
                last_updated=datetime.now(),
            ))
            action = "created"

        save_memory(repo_path, memory)

        return [TextContent(type="text", text=json.dumps({
            "success": True,
            "action": action,
            "doc_id": doc_id,
            "path": relative_path,
            "title": title,
            "category": category,
        }))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({
            "success": False,
            "error": str(e),
        }))]


async def handle_read_memory(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle read_memory tool call."""
    repo_path = arguments["repo_path"]
    section = arguments.get("section")

    memory = load_memory(repo_path)

    if memory is None:
        return [TextContent(type="text", text="error: Memory not found. Run init_repo first.")]

    _sync_skills_silently(Path(repo_path))

    data = memory.model_dump(mode="json", exclude_none=True)

    if section:
        if section not in data:
            valid = ", ".join(data.keys())
            return [TextContent(type="text", text=f"error: Unknown section: {section}. Valid: {valid}")]
        data = {section: data[section]}

    return [TextContent(type="text", text=_format_memory_plain(data))]


def _format_memory_plain(data: dict) -> str:
    """Format memory as plain text to avoid markdown regex issues with JSON brackets."""
    lines = []

    if "metadata" in data:
        m = data["metadata"]
        lines.append("metadata:")
        for k, v in m.items():
            lines.append(f"  {k}: {v}")

    if "architecture" in data:
        lines.append(f"architecture: {data['architecture']}")

    if "stack" in data:
        s = data["stack"]
        lines.append("stack:")
        if s.get("languages"):
            lines.append(f"  languages: {', '.join(s['languages'])}")
        if s.get("frameworks"):
            lines.append(f"  frameworks: {', '.join(s['frameworks'])}")

    if "conventions" in data:
        lines.append("conventions:")
        for c in data["conventions"]:
            lines.append(f"  - {c}")

    if "context" in data:
        ctx = data["context"]
        notes = ctx.get("notes", [])
        if notes:
            lines.append("context.notes:")
            for n in notes:
                lines.append(f"  - {n}")

    if "learnings" in data:
        lines.append("learnings:")
        for lr in data["learnings"]:
            lines.append(f"  - id={lr.get('id', '?')} confidence={lr.get('confidence', '?')} category={lr.get('category', '?')}")
            lines.append(f"    {lr.get('summary', '')}")

    if "docs" in data:
        docs = data["docs"]
        if docs:
            lines.append("docs:")
            for d in docs:
                lines.append(f"  - id={d.get('id', '?')} category={d.get('category', '?')} path={d.get('path', '?')}")
                lines.append(f"    {d.get('title', '')} -- {d.get('description', '')}")
        else:
            lines.append("docs: none")

    return "\n".join(lines)


async def handle_update_memory(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle update_memory tool call.

    Supports all sections. For learnings with operation='append', auto-generates
    id, date, and default confidence.
    """
    repo_path = arguments["repo_path"]
    section = arguments["section"]
    content = arguments["content"]
    operation = arguments.get("operation", "set")

    memory = load_memory(repo_path)

    if memory is None:
        return [TextContent(type="text", text=json.dumps({
            "success": False,
            "error": "Memory not found. Run init_repo first.",
        }))]

    try:
        if section == "architecture":
            if operation == "set":
                memory.architecture = str(content)
            else:
                memory.architecture += "\n" + str(content)

        elif section == "stack":
            if isinstance(content, str):
                content = json.loads(content)
            if operation == "set":
                memory.stack = Stack(**content)
            else:
                current = memory.stack.model_dump(exclude_none=True)
                for k, v in content.items():
                    if isinstance(current.get(k), list) and isinstance(v, list):
                        current[k] = list(set(current[k] + v))
                    else:
                        current[k] = v
                memory.stack = Stack(**current)

        elif section == "conventions":
            if operation == "set":
                if isinstance(content, list):
                    memory.conventions = [str(c) for c in content]
                else:
                    memory.conventions = [str(content)]
            else:
                if isinstance(content, list):
                    memory.conventions.extend(str(c) for c in content)
                else:
                    memory.conventions.append(str(content))

        elif section == "context":
            if isinstance(content, str):
                content = json.loads(content)
            if operation == "set":
                from dcp.schemas.memory import Context
                memory.context = Context(**content)
            else:
                notes = content.get("notes", [])
                if isinstance(notes, str):
                    notes = [notes]
                memory.context.notes.extend(notes)

        elif section == "learnings":
            if operation == "append":
                if isinstance(content, str):
                    content = json.loads(content)
                if isinstance(content, list):
                    items = content
                else:
                    items = [content]

                created = []
                for item in items:
                    category = item.get("category", "decisions")
                    learning = Learning(
                        id=_generate_learning_id(category),
                        summary=item["summary"],
                        category=category,
                        confidence=item.get("confidence", 50),
                        date=datetime.now(),
                    )
                    memory.learnings.append(learning)
                    created.append({"id": learning.id, "summary": learning.summary})

                save_memory(repo_path, memory)
                return [TextContent(type="text", text=json.dumps({
                    "success": True,
                    "section": section,
                    "operation": operation,
                    "created": created,
                }))]
            else:
                if isinstance(content, str):
                    content = json.loads(content)
                if isinstance(content, list):
                    memory.learnings = [
                        Learning(**item) if isinstance(item, dict) else item
                        for item in content
                    ]
                else:
                    return [TextContent(type="text", text=json.dumps({
                        "success": False,
                        "error": "For learnings with operation='set', provide a list.",
                    }))]

        elif section == "docs":
            if isinstance(content, str):
                content = json.loads(content)
            if operation == "set":
                if isinstance(content, list):
                    memory.docs = [
                        DocReference(**item) if isinstance(item, dict) else item
                        for item in content
                    ]
                else:
                    return [TextContent(type="text", text=json.dumps({
                        "success": False,
                        "error": "For docs with operation='set', provide a list of doc references.",
                    }))]
            elif operation == "remove":
                doc_id = content if isinstance(content, str) else content.get("id", "")
                original_len = len(memory.docs)
                memory.docs = [d for d in memory.docs if d.id != doc_id]
                if len(memory.docs) == original_len:
                    return [TextContent(type="text", text=json.dumps({
                        "success": False,
                        "error": f"Doc with id '{doc_id}' not found.",
                    }))]
            else:
                return [TextContent(type="text", text=json.dumps({
                    "success": False,
                    "error": "For docs, use save_doc tool to add/update, or operation='set'/'remove' via update_memory.",
                }))]
        else:
            return [TextContent(type="text", text=json.dumps({
                "success": False,
                "error": f"Unknown section: {section}",
            }))]

        save_memory(repo_path, memory)

        return [TextContent(type="text", text=json.dumps({
            "success": True,
            "section": section,
            "operation": operation,
        }))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({
            "success": False,
            "error": str(e),
        }))]


async def handle_init_repo(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle init_repo tool call - initializes memory and cursor rules."""
    repo_path = arguments["repo_path"]
    repo_name = arguments.get("repo_name")
    scan_repo = arguments.get("scan_repo", True)
    scan_git = arguments.get("scan_git", True)
    copy_cursor_rules = arguments.get("copy_cursor_rules", True)
    force = arguments.get("force", False)

    path = Path(repo_path)

    if memory_exists(repo_path):
        if not force:
            existing = load_memory(repo_path)
            return [TextContent(type="text", text=json.dumps({
                "success": False,
                "error": "Memory already exists. Use read_memory or update_memory, "
                         "or pass force=true to overwrite.",
                "existing_memory": existing.model_dump(mode="json") if existing else None,
            }, indent=2, default=str))]
        else:
            memory_path = get_memory_path(repo_path)
            if memory_path.exists():
                memory_path.unlink()

    memory = create_initial_memory(repo_path, repo_name)

    discoveries = {}
    suggestions = []

    if scan_repo:
        tech_stack = detect_tech_stack(repo_path)
        memory.stack = Stack(**tech_stack)
        discoveries["tech_stack"] = tech_stack

        if tech_stack.get("languages"):
            suggestions.append(f"Detected languages: {', '.join(tech_stack['languages'])}")
        if tech_stack.get("frameworks"):
            suggestions.append(f"Detected frameworks: {', '.join(tech_stack['frameworks'])}")

    if scan_git:
        git_notes = _extract_git_notes(repo_path)
        if git_notes:
            memory.context.notes.extend(git_notes)
            discoveries["git_notes"] = git_notes

    file_path = save_memory(repo_path, memory)

    cursor_rules_result = {}
    if copy_cursor_rules:
        cursor_rules_result = _copy_cursor_rules(path, force=force)
        if cursor_rules_result["copied"]:
            suggestions.append(f"Copied cursor rules: {', '.join(cursor_rules_result['copied'])}")

    skills_result = _copy_skills(path, force=force)
    if skills_result["copied"]:
        suggestions.append(f"Copied skills: {', '.join(skills_result['copied'])}")
    if skills_result.get("updated"):
        suggestions.append(f"Updated skills: {', '.join(skills_result['updated'])}")

    gitignore_result = _ensure_gitignore_entries(path)
    if gitignore_result["added"]:
        suggestions.append(f"Added to .gitignore: {', '.join(gitignore_result['added'])}")

    result = {
        "success": True,
        "file_path": str(file_path),
        "memory": memory.model_dump(mode="json", exclude_none=True),
        "discoveries": discoveries,
        "cursor_rules": cursor_rules_result,
        "skills": skills_result,
        "gitignore": gitignore_result,
        "suggestions": suggestions,
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


def _extract_git_notes(repo_path: str) -> list[str]:
    """Extract useful notes from git history for context.notes."""
    try:
        from dcp.memory.git_analyzer import analyze_git_history
        discoveries = analyze_git_history(repo_path)
        if discoveries is None:
            return []

        notes = []
        if discoveries.branch_patterns:
            top = discoveries.branch_patterns[0]
            notes.append(f"Branch pattern: {top.get('pattern', 'unknown')}")
        if discoveries.hot_files:
            names = [f.get("file", "?") for f in discoveries.hot_files[:3]]
            notes.append(f"Hot files: {', '.join(names)}")
        if discoveries.commit_patterns:
            top = discoveries.commit_patterns[0]
            notes.append(f"Commit pattern: {top.get('pattern', 'unknown')}")
        return notes
    except Exception:
        return []
