"""Centralized package data path resolution.

All data paths should go through this module to ensure they work
in both development (editable install) and production (wheel install).
"""

from pathlib import Path

# Package root: the directory containing this file
_PACKAGE_DIR = Path(__file__).parent

# Repo root: only valid in dev/editable mode
_REPO_ROOT = _PACKAGE_DIR.parent.parent


def _resolve(primary: Path, *fallbacks: Path) -> Path:
    """Return the first path that exists, or the primary if none do."""
    if primary.exists():
        return primary
    for fb in fallbacks:
        if fb.exists():
            return fb
    return primary


def get_cursor_rules_dir() -> Path:
    """Get the bundled cursor rules directory (.mdc files).

    Checked locations (in order):
    1. <package>/data/cursor-rules/  (wheel install)
    2. <repo>/examples/cursor-rules/ (editable install / dev)
    """
    return _resolve(
        _PACKAGE_DIR / "data" / "cursor-rules",
        _REPO_ROOT / "examples" / "cursor-rules",
    )


def get_modes_dir() -> Path:
    """Get the built-in mode YAML definitions directory.

    Checked locations (in order):
    1. <package>/config/modes/ (both wheel and editable)
    """
    return _PACKAGE_DIR / "config" / "modes"


def get_skills_dir() -> Path:
    """Get the bundled skills directory (SKILL.md files).

    Checked locations (in order):
    1. <package>/data/skills/  (wheel install)
    2. <repo>/examples/skills/ (editable install / dev)
    """
    return _resolve(
        _PACKAGE_DIR / "data" / "skills",
        _REPO_ROOT / "examples" / "skills",
    )


def get_guidelines_dir() -> Path:
    """Get the bundled guidelines directory.

    Checked locations (in order):
    1. <package>/data/guidelines/ (wheel install via force-include)
    2. <repo>/guidelines/          (editable install / dev)
    """
    return _resolve(
        _PACKAGE_DIR / "data" / "guidelines",
        _REPO_ROOT / "guidelines",
    )
