"""Pydantic schemas for development modes."""

from typing import Any
from pydantic import BaseModel, Field


class ModeChecklist(BaseModel):
    """Checklist items for a mode."""
    
    before: list[str] = Field(default_factory=list, alias="before_coding")
    during: list[str] = Field(default_factory=list, alias="while_coding")
    after: list[str] = Field(default_factory=list, alias="after_coding")
    
    class Config:
        populate_by_name = True


class ModeDefinition(BaseModel):
    """Definition of a development mode."""
    
    id: str = Field(description="Unique mode identifier")
    name: str = Field(description="Display name")
    description: str = Field(description="Short description")
    system_prompt: str = Field(description="System prompt for AI behavior")
    tools_enabled: list[str] = Field(
        default_factory=list,
        description="List of tools available in this mode"
    )
    checklist: dict[str, list[str]] = Field(
        default_factory=dict,
        description="Phase-based checklist items"
    )
    triggers: list[str] = Field(
        default_factory=list,
        description="Keywords that suggest this mode"
    )
    related_modes: list[str] = Field(
        default_factory=list,
        description="Modes to suggest transitioning to"
    )
    variables: dict[str, str] = Field(
        default_factory=dict,
        description="Custom variables for prompts"
    )


class CustomModeDefinition(BaseModel):
    """Definition of a custom mode that can extend built-in modes."""
    
    id: str = Field(description="Unique mode identifier")
    name: str = Field(description="Display name")
    description: str = Field(description="Short description")
    extends: str | None = Field(
        default=None,
        description="Built-in mode to inherit from"
    )
    system_prompt: str | None = Field(
        default=None,
        description="System prompt (overrides parent if set)"
    )
    tools_enabled: list[str] | None = Field(
        default=None,
        description="Override parent's tools"
    )
    tools_disabled: list[str] = Field(
        default_factory=list,
        description="Tools to remove from parent"
    )
    checklist: dict[str, list[str]] = Field(
        default_factory=dict,
        description="Additional checklist items"
    )
    triggers: list[str] = Field(
        default_factory=list,
        description="Keywords that suggest this mode"
    )
    related_modes: list[str] = Field(
        default_factory=list,
        description="Modes to suggest transitioning to"
    )
    variables: dict[str, str] = Field(
        default_factory=dict,
        description="Custom variables for prompts"
    )
    context_injection: list[str] = Field(
        default_factory=list,
        description="Memory paths to always include"
    )
    
    def resolve(self, parent: ModeDefinition | None) -> ModeDefinition:
        """Resolve this custom mode against its parent."""
        if parent is None:
            # No parent, use custom definition directly
            return ModeDefinition(
                id=self.id,
                name=self.name,
                description=self.description,
                system_prompt=self.system_prompt or "",
                tools_enabled=self.tools_enabled or [],
                checklist=self.checklist,
                triggers=self.triggers,
                related_modes=self.related_modes,
                variables=self.variables,
            )
        
        # Merge with parent
        tools = self.tools_enabled if self.tools_enabled is not None else parent.tools_enabled.copy()
        for tool in self.tools_disabled:
            if tool in tools:
                tools.remove(tool)
        
        # Merge checklists
        merged_checklist = parent.checklist.copy()
        for phase, items in self.checklist.items():
            if phase in merged_checklist:
                merged_checklist[phase] = merged_checklist[phase] + items
            else:
                merged_checklist[phase] = items
        
        # Merge variables
        merged_variables = parent.variables.copy()
        merged_variables.update(self.variables)
        
        return ModeDefinition(
            id=self.id,
            name=self.name,
            description=self.description,
            system_prompt=self.system_prompt or parent.system_prompt,
            tools_enabled=tools,
            checklist=merged_checklist,
            triggers=list(set(parent.triggers + self.triggers)),
            related_modes=list(set(parent.related_modes + self.related_modes)),
            variables=merged_variables,
        )


class ModeInfo(BaseModel):
    """Summary information about a mode."""
    
    id: str
    name: str
    description: str
    source: str = Field(description="'builtin' or 'custom'")
    extends: str | None = None
    triggers: list[str] = Field(default_factory=list)
