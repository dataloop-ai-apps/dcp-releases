"""Pydantic schemas for guidelines."""

from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field


class GuidelineMetadata(BaseModel):
    """Metadata for a guideline document."""
    
    id: str = Field(description="Unique guideline identifier")
    title: str = Field(description="Guideline title")
    category: str = Field(description="Category path, e.g., 'security/authentication'")
    subcategory: str | None = None
    languages: list[str] = Field(
        default_factory=list,
        description="Applicable languages: python, typescript, javascript, etc."
    )
    frameworks: list[str] = Field(
        default_factory=list,
        description="Applicable frameworks: react, fastify, django, etc."
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Tags for search boost"
    )
    severity: Literal["required", "recommended", "optional"] = "recommended"
    applies_when: list[str] = Field(
        default_factory=list,
        description="Situations when this applies"
    )
    version: str = "1.0"
    last_updated: datetime = Field(default_factory=datetime.now)


class Guideline(BaseModel):
    """Complete guideline document."""
    
    metadata: GuidelineMetadata
    content: str = Field(description="Full markdown content")
    summary: str | None = Field(default=None, description="Brief summary")
    examples: list[str] = Field(default_factory=list)
    rationale: str | None = None
    related: list[str] = Field(
        default_factory=list,
        description="Related guideline IDs"
    )


class SearchResult(BaseModel):
    """Result from guideline search."""
    
    id: str
    title: str
    content: str
    category: str
    languages: list[str]
    frameworks: list[str]
    relevance_score: float = Field(ge=0, le=1)
    match_reasons: list[str] = Field(default_factory=list)
    repo_specific_notes: str | None = None


class SearchFilters(BaseModel):
    """Filters for guideline search."""
    
    languages: list[str] | None = None
    frameworks: list[str] | None = None
    categories: list[str] | None = None
    severity: list[str] | None = None
    tags: list[str] | None = None
