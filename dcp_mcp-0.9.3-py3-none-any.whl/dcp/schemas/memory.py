"""Pydantic schemas for repo memory (v2 — simplified flat schema)."""

from datetime import datetime
from typing import Any, Literal
from pydantic import BaseModel, Field


class Learning(BaseModel):
    """A single learning entry.

    High-confidence learnings (80+) act as enforced guidelines.
    Low-confidence learnings are informational notes.
    """

    id: str = Field(description="Unique identifier (auto-generated)")
    summary: str = Field(description="Brief summary of the learning")
    category: Literal[
        "review_feedback", "bug_patterns", "edge_cases", "gotchas", "decisions"
    ] = Field(description="Learning category")
    confidence: int = Field(
        default=50, ge=0, le=100,
        description="Confidence score 0-100. 80+ = enforced guideline",
    )
    date: datetime = Field(default_factory=datetime.now)


class DocReference(BaseModel):
    """Reference to a documentation file stored in .dcp/docs/.

    Used for operational docs like release flows, local dev setup,
    running tests, deployment guides, etc.
    """

    id: str = Field(description="Unique identifier (e.g., 'release-flow')")
    title: str = Field(description="Human-readable title")
    description: str = Field(description="Brief description of what this doc covers")
    path: str = Field(description="Relative path from repo root (e.g., .dcp/docs/release-flow.md)")
    category: Literal[
        "flow", "setup", "guide", "runbook", "reference"
    ] = Field(default="guide", description="Documentation category")
    last_updated: datetime = Field(default_factory=datetime.now)


class Stack(BaseModel):
    """Technology stack information."""

    languages: list[str] = Field(default_factory=list)
    runtime: str | None = Field(default=None)
    frameworks: list[str] = Field(default_factory=list)
    database: str | None = Field(default=None)
    testing: str | None = Field(default=None)


class Context(BaseModel):
    """Current context and notes."""

    notes: list[str] = Field(default_factory=list)


class Metadata(BaseModel):
    """Memory metadata."""

    repo_name: str
    created_at: datetime = Field(default_factory=datetime.now)
    last_updated: datetime = Field(default_factory=datetime.now)
    version: str = "2.0"


class RepoMemory(BaseModel):
    """Complete repo memory schema (v2 — flat)."""

    metadata: Metadata
    architecture: str = Field(default="", description="Free-text architecture description")
    stack: Stack = Field(default_factory=Stack)
    conventions: list[str] = Field(default_factory=list)
    context: Context = Field(default_factory=Context)
    learnings: list[Learning] = Field(default_factory=list)
    docs: list[DocReference] = Field(default_factory=list)

    def update_timestamp(self) -> None:
        """Update the last_updated timestamp."""
        self.metadata.last_updated = datetime.now()

    def get_learning_by_id(self, learning_id: str) -> Learning | None:
        """Find a learning by ID."""
        for learning in self.learnings:
            if learning.id == learning_id:
                return learning
        return None

    def get_doc_by_id(self, doc_id: str) -> DocReference | None:
        """Find a doc reference by ID."""
        for doc in self.docs:
            if doc.id == doc_id:
                return doc
        return None
