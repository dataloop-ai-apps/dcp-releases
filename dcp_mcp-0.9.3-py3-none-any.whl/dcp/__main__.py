"""Entry point for running dcp-mcp via uvx."""

from dcp.server import run_server

if __name__ == "__main__":
    run_server()
