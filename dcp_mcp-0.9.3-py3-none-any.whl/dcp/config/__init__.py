"""Configuration for Dev Control Plane."""

from pathlib import Path


def get_config_dir() -> Path:
    """Get the configuration directory path."""
    return Path(__file__).parent


def get_modes_dir() -> Path:
    """Get the built-in modes directory path."""
    from dcp.paths import get_modes_dir as _get_modes_dir
    return _get_modes_dir()
